/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Persistencia;
import java.io.*;
import java.util.*;
import Dominio.Estructuras.UsuarioHidato;
//imports especiales:
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Raúl Ibáñez Pérez
 * Colaborador: Marcel Arroyo
 */
public class ControladorDatosUsuario {
    
    /*   CREADORAS   */
    
    /*  PRE: -
        POST: Inicialización de la clase, que se deja vacía
    */
    public ControladorDatosUsuario() {
        
    }
    
    /*   CONSULTORAS   */
    
    /*  PRE: -
        POST: devuelve true si s es un usuario que ya existe y false si no.
    */
    public boolean nombreUsuarioExistente(String s){
        
        boolean encontrado = false;
        
        File archivo = null;
        FileReader fr = null;
        BufferedReader br = null;
        
        try {
            // Apertura del fichero y creacion de BufferedReader para poder
            // hacer una lectura comoda (disponer del metodo readLine()).
            String ruta = new java.io.File(".").getCanonicalPath();
            archivo = new File (ruta+File.separator+"src"+File.separator+"Persistencia"+File.separator+"BD"+File.separator+"BDUsuarios.txt");
            fr = new FileReader (archivo);
            br = new BufferedReader(fr);
            
            // Lectura del fichero
            String linea;
            while((linea=br.readLine())!=null){
                if (s.equals(linea)) encontrado = true;
                br.readLine();
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }
        finally{
            // En el finally cerramos el fichero, para asegurarnos
            // que se cierra tanto si todo va bien como si salta
            // una excepcion.
            try{                   
                if( null != fr ){  
                    fr.close();    
                }                 
            }
            catch (Exception e2){
                e2.printStackTrace();
            }
        }
        return encontrado;
    }
    
    /*  PRE: n es un nombre de usuario existente.
        POST: devuelve true si c es la contraseña de usuario n y false si no lo es.
    */
    public boolean contrasenaValida(String n, String c){
        
        boolean encontrado = false;
        
        File archivo = null;
        FileReader fr = null;
        BufferedReader br = null;
        
        boolean solucio = false;
        
        try {
            // Apertura del fichero y creacion de BufferedReader para poder
            // hacer una lectura comoda (disponer del metodo readLine()).
            String ruta = new java.io.File(".").getCanonicalPath();
            archivo = new File (ruta+File.separator+"src"+File.separator+"Persistencia"+File.separator+"BD"+File.separator+"BDUsuarios.txt");
            fr = new FileReader (archivo);
            br = new BufferedReader(fr);
            
            // Lectura del fichero
            String linea;
            while(((linea=br.readLine())!=null) && (!encontrado)){
                if (n.equals(linea)) encontrado = true;
            }
            if (encontrado) 
                solucio = (c.equals(linea));
        }
        catch(Exception e){
            e.printStackTrace();
        }
        finally{
            // En el finally cerramos el fichero, para asegurarnos
            // que se cierra tanto si todo va bien como si salta
            // una excepcion.
            try{                   
                if( null != fr ){  
                    fr.close();    
                }                 
            }
            catch (Exception e2){
                e2.printStackTrace();
            }
        }
        
        return solucio;
    }
    
    /*  PRE: u es un usuario existente.
        POST: devuelve los datos del usuario u.
    */
    public UsuarioHidato cargarUsuario(UsuarioHidato u){
        UsuarioHidato auxUsuario = new UsuarioHidato();
        Date f=null;
        String auxFecha;
        int p = 0;
        boolean b = true;
        
        //SimpleDateFormat formateador = new SimpleDateFormat("EEE MMM dd HH:mm:ss z yyyy");
        SimpleDateFormat formateador = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzzz yyyy",Locale.ENGLISH);
                
        File archivo = null;
        FileReader fr = null;
        BufferedReader br = null;
        try {
            // Apertura del fichero y creacion de BufferedReader para poder
            // hacer una lectura comoda (disponer del metodo readLine()).
            String ruta = new java.io.File(".").getCanonicalPath();
            archivo = new File (ruta+File.separator+"src"+File.separator+"Persistencia"+File.separator+"BD"+File.separator+"Usuarios"+File.separator+u.getNombre()+".txt");
            fr = new FileReader (archivo);
            br = new BufferedReader(fr);
            
            p = Integer.parseInt(br.readLine()); //Leo la puntuacion;
            b = Boolean.parseBoolean(br.readLine()); 
            auxFecha = br.readLine();
            try {
                f = formateador.parse(auxFecha);
            }
            catch (ParseException ex) {
                ex.printStackTrace();
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }
        finally{
            // En el finally cerramos el fichero, para asegurarnos
            // que se cierra tanto si todo va bien como si salta
            // una excepcion.
            try{                   
                if( null != fr ){  
                    fr.close();
                }                 
            }
            catch (Exception e2){
                e2.printStackTrace();
            }
        }
        auxUsuario.setNombre(u.getNombre());
        auxUsuario.setContrasena(u.getContrasena());
        auxUsuario.setPuntuacionTotal(p);
        auxUsuario.setApareceRanking(b);
        auxUsuario.setFecha(f);
        return auxUsuario;
    }
    
    /*   MODIFICADORAS   */
    
    /*  PRE: -
        POST: crea un usuario con nombre n y contraseña c.
    */
    public void crearUsuario(String n, String c){
        FileWriter fichero = null;
        PrintWriter pw = null;
        try
        {
            String ruta = new java.io.File(".").getCanonicalPath();
            fichero = new FileWriter (ruta+File.separator+"src"+File.separator+"Persistencia"+File.separator+"BD"+File.separator+"BDUsuarios.txt",true);
            pw = new PrintWriter(fichero);
 
            pw.println(n);
            pw.println(c);
 
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        finally {
           try {
           // Nuevamente aprovechamos el finally para
           // asegurarnos que se cierra el fichero.
           if (null != fichero)
              fichero.close();
           }
           catch (Exception e2) {
              e2.printStackTrace();
           }
        }
    }
    
    /*  PRE: n es un nombre de usuario existente.
        POST: se borran todos los datos del usuario con nombre n.
    */
    private void borrarUsuario2(String n){
        
        //LEO ARCHIVO = BDUsuarios.txt
        //ESCRIBO FICHERO = BDUsuarios2.txt
        
        //LEO BDUsuarios.txt y ESCRIBO EN BDUsuarios2.txt
        
        File archivo = null;
        FileReader fr = null;
        BufferedReader br = null;
      
        
        FileWriter fichero = null;
        
        try {
            // Apertura del fichero y creacion de BufferedReader para poder
            // hacer una lectura comoda (disponer del metodo readLine()).
            String ruta = new java.io.File(".").getCanonicalPath();
            archivo = new File (ruta+File.separator+"src"+File.separator+"Persistencia"+File.separator+"BD"+File.separator+"BDUsuarios.txt");
            fr = new FileReader (archivo);
            br = new BufferedReader(fr);
            
            // Lectura del fichero
            String linea;
            while(((linea=br.readLine())!=null)){
                if (n.equals(linea)) {
                    //Si es l'usuari que busco paso al següent nom d'usuari.
                    br.readLine();
                }
                else{
                    //Si no, guardo l'usuri a la BD auxiliar.
                    
                    PrintWriter pw = null;
                    try
                    {
                        String route = new java.io.File(".").getCanonicalPath();
                        fichero = new FileWriter (route+File.separator+"src"+File.separator+"Persistencia"+File.separator+"BD"+File.separator+"BDUsuarios2.txt");
                        pw = new PrintWriter(fichero);

                        pw.println(linea);
                        linea=br.readLine();
                        pw.println(linea);

                    }
                    catch (Exception e) {
                        e.printStackTrace();
                    }
                    finally {
                       try {
                       // Nuevamente aprovechamos el finally para
                       // asegurarnos que se cierra el fichero.
                       if (null != fichero)
                          fichero.close();
                       }
                       catch (Exception e2) {
                          e2.printStackTrace();
                       }
                    }
                }
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }
        finally{
            // En el finally cerramos el fichero, para asegurarnos
            // que se cierra tanto si todo va bien como si salta
            // una excepcion.
            try{                   
                if( null != fr ){  
                    fr.close();    
                }                 
            }
            catch (Exception e2){
                e2.printStackTrace();
            }
        }
        
        // Borro BDUsuarios.txt
        
        archivo.delete();
        
        //Escric a BDUsuarios.txt el que hi ha a BDUsuarios2.txt
        
        archivo = null;
        fr = null;
        br = null;
     
        
        fichero = null;
        
        try {
            // Apertura del fichero y creacion de BufferedReader para poder
            // hacer una lectura comoda (disponer del metodo readLine()).
            String ruta = new java.io.File(".").getCanonicalPath();
            archivo = new File (ruta+File.separator+"src"+File.separator+"Persistencia"+File.separator+"BD"+File.separator+"BDUsuarios2.txt");
            fr = new FileReader (archivo);
            br = new BufferedReader(fr);
            
            // Lectura del fichero
            String linea;
            while(((linea=br.readLine())!=null)){
                //Guardo l'usuri a la BD.
                PrintWriter pw = null;
                try
                {
                    String route = new java.io.File(".").getCanonicalPath();
                    fichero = new FileWriter (route+File.separator+"src"+File.separator+"Persistencia"+File.separator+"BD"+File.separator+"BDUsuarios.txt",true);
                    pw = new PrintWriter(fichero);

                    pw.println(linea);
                    linea=br.readLine();
                    pw.println(linea);

                }
                catch (Exception e) {
                    e.printStackTrace();
                }
                finally {
                   try {
                   // Nuevamente aprovechamos el finally para
                   // asegurarnos que se cierra el fichero.
                   if (null != fichero)
                      fichero.close();
                   }
                   catch (Exception e2) {
                      e2.printStackTrace();
                   }
                }
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }
        finally{
            // En el finally cerramos el fichero, para asegurarnos
            // que se cierra tanto si todo va bien como si salta
            // una excepcion.
            try{                   
                if( null != fr ){  
                    fr.close();    
                }                 
            }
            catch (Exception e2){
                e2.printStackTrace();
            }
        }
        
        //Elimino BDUsuarios2.txt
        try {
            String route = new java.io.File(".").getCanonicalPath();
            archivo= new File (route+File.separator+"src"+File.separator+"Persistencia"+File.separator+"BD"+File.separator+"BDUsuarios2.txt");
            archivo.delete();
        }
        catch (Exception e){
            e.printStackTrace();
        }
        //Elimino Usuaiors/n.txt
        
        this.borrarBDUsuario(n);
        
    }
    
    public void borrarUsuario(String n){
        
        //Miro si hay más de un usuario en BDUsuarios.txt
        
        int numeroDeUsuarios = 0;
        
        File archivo = null;
        FileReader fr = null;
        BufferedReader br = null;
        
        try {
            String ruta = new java.io.File(".").getCanonicalPath();
            archivo = new File (ruta+File.separator+"src"+File.separator+"Persistencia"+File.separator+"BD"+File.separator+"BDUsuarios.txt");
            fr = new FileReader (archivo);
            br = new BufferedReader(fr);
            
            while(((br.readLine())!=null)) {
                ++numeroDeUsuarios;
                br.readLine();
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }
        finally{
            try{                   
                if( null != fr )fr.close();  
            }
            catch (Exception e2){
                e2.printStackTrace();
            }
        }
        //Si hay más de uno borro el usuario, si hay solo uno reseteo BDUsuarios.txt
        if (numeroDeUsuarios > 1) this.borrarUsuario2(n);
        else this.borrarUsuario3(n);
    }
    
    private void borrarUsuario3(String n){
        // Borro la BD del usuario.
        this.borrarBDUsuario(n);
        //Borro la BD con el nombre y la contraseña y Creo una BD vacía.
        try {
            String ruta = new java.io.File(".").getCanonicalPath();
            File archivo = new File (ruta+File.separator+"src"+File.separator+"Persistencia"+File.separator+"BD"+File.separator+"BDUsuarios.txt");
            archivo.delete();
            String route = new java.io.File(".").getCanonicalPath();
            FileWriter fichero = new FileWriter (route+File.separator+"src"+File.separator+"Persistencia"+File.separator+"BD"+File.separator+"BDUsuarios.txt",true);
            
        } catch (IOException ex) {
            Logger.getLogger(ControladorDatosUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    /*  PRE: u es un usuario existente.
        POST: guarda todos los datos en el usuario con nombre n.
    */
    public void guardarUsuario(UsuarioHidato u){
        
        this.borrarBDUsuario(u.getNombre());
        
        FileWriter fichero = null;
        PrintWriter pw = null;
        try
        {
            String ruta = new java.io.File(".").getCanonicalPath();
            fichero = new FileWriter (ruta+File.separator+"src"+File.separator+"Persistencia"+File.separator+"BD"+File.separator+"Usuarios"+File.separator+u.getNombre()+".txt",true);
            pw = new PrintWriter(fichero);
            pw.println(u.getPuntuacionTotal());
            if(u.getApareceRanking() == true) pw.println("true");
            else pw.println("false");
            String auxFecha = u.getFecha().toString();
            pw.println(auxFecha);
 
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        finally {
           try {
           // Nuevamente aprovechamos el finally para
           // asegurarnos que se cierra el fichero.
           if (null != fichero)
              fichero.close();
           }
           catch (Exception e2) {
              e2.printStackTrace();
           }
        }
    }
    
    /*  PRE: n es un nombre de usuario existente.
        POST: se borra la bae de datos del usuario con nombre n.
    */ 
    private void borrarBDUsuario(String n){
        
        File archivo = null;
        
        try {
        
            String ruta = new java.io.File(".").getCanonicalPath();
            archivo = new File (ruta+File.separator+"src"+File.separator+"Persistencia"+File.separator+"BD"+File.separator+"Usuarios"+File.separator+n+".txt");
            archivo.delete();
        }
        catch(Exception e){
            e.printStackTrace();
        }
        
    }
    
}
