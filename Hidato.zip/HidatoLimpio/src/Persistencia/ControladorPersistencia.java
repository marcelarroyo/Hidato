/**
 *
 * @author RaÃºl IbÃ¡Ã±ez PÃ©rez
 */
package Persistencia;
import java.util.*;
import Dominio.Estructuras.UsuarioHidato;

public class ControladorPersistencia {
    
    ControladorDatosUsuario CDUsuario = new ControladorDatosUsuario();
    
    /*   CREADORAS   */
    
    /*  PRE: -
        POST: InicializaciÃ³n de la clase, que se deja vacÃ­a
    */
    public ControladorPersistencia() {
        
    }
    
    // Partida
    
    public boolean nombreTableroValido(String n) {
        //
        return true;
    }
}
