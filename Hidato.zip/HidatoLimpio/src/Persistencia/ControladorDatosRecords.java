package Persistencia;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import Dominio.Estructuras.ConjuntoRecords;
import Dominio.Estructuras.PairRecord;
import Dominio.Estructuras.RecordTablero;
import java.io.*;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
//imports especiales:
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author marcel.arroyo
 */
public class ControladorDatosRecords {
    
    public ControladorDatosRecords(){ }
    /*
    public boolean nombreTableroExistente(String n){
        boolean encontrado = false;
        
        File archivo;
        FileReader fr = null;
        BufferedReader br;
       
        try {
            String ruta = new java.io.File(".").getCanonicalPath();
            archivo = new File (ruta+File.separator+"src"+File.separator+"Persistencia"+File.separator+"BD"+File.separator+"BDTableros.txt");
            fr = new FileReader (archivo);
        }
        catch(Exception e){
            e.printStackTrace();
        }
        br = new BufferedReader(fr);

        // Lectura del fichero
        String linea;
        try {
            while((linea=br.readLine())!=null){
                if (n.equals(linea)) encontrado = true;
                br.readLine();
            }
        }
        catch (IOException ex) {
            Logger.getLogger(ControladorDatosRecords.class.getName()).log(Level.SEVERE, null, ex);
        }
        
                      
        if( null != fr ){  
            try {    
                fr.close();
            }
            catch (IOException ex) {
                Logger.getLogger(ControladorDatosRecords.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return encontrado;
    }
    
    /*  PRE:
        POST: Carga todos los archivos .txt del directorio RecordsTablero   
        actualizando los datos de la estrctura ConjuntoRecords
    */
    
    public  ConjuntoRecords cargarRecordsTablero(){

            ConjuntoRecords recordsaux = new ConjuntoRecords();

            File archivo;
            FileReader fr = null;
            BufferedReader br;
            try {
                // Apertura del fichero y creacion de BufferedReader para poder
                // hacer una lectura comoda (disponer del metodo readLine()).
                //Es guarda usuari i puntuacio al fitxer
                //FirstPlayer(usuario)....BestTime(usuario,tiempo)...BestPunt(usuario,punt)
                String ruta = new java.io.File(".").getCanonicalPath();
                File directorio = new File (ruta+File.separator+"src"+File.separator+"Persistencia"+File.separator+"BD"+File.separator+"RecordsTablero");
                File[] ficheros = directorio.listFiles();
                for (int x=0;x<ficheros.length;x++){
                    recordsaux.anadirTablero(stripExtension(ficheros[x].getName()));
                    String route = new java.io.File(".").getCanonicalPath();
                    archivo = new File (route+File.separator+"src"+File.separator+"Persistencia"+File.separator+"BD"+File.separator+"RecordsTablero"+File.separator+ficheros[x].getName());
                    fr = new FileReader (archivo);
                    br = new BufferedReader(fr);
                    String usuari = br.readLine();
                    if (usuari != null) {
                        System.out.println(usuari);
                        if (usuari.equals("-2")) usuari = null;
                        recordsaux.setRecordFirstPlayerTablero(stripExtension(ficheros[x].getName()),usuari);
                        usuari = br.readLine();
                        System.out.println(usuari);
                        if (usuari.equals("-2")) usuari = null;
                        int punt = Integer.parseInt(br.readLine());
                        recordsaux.setRecordTimeTablero(stripExtension(ficheros[x].getName()), usuari, punt);
                        usuari = br.readLine();
                        System.out.println(usuari);
                        if (usuari.equals("-2"))  usuari = null;
                        punt = Integer.parseInt(br.readLine());
                        recordsaux.setRecordMaxPuntTablero(stripExtension(ficheros[x].getName()), usuari, punt);
                        fr.close();
                    }
                }
            }
            catch(IOException | NumberFormatException e){
            }
            return recordsaux;
    }
    
    
    public void guardarRecord(String s){
        FileWriter fichero = null;
            PrintWriter pw;
            try {
                File archivoborrar;
                String ruta = new java.io.File(".").getCanonicalPath();
                archivoborrar = new File (ruta +File.separator+"src"+File.separator+"Persistencia"+File.separator+"BD"+File.separator+"RecordsTablero"+File.separator+s+".txt");
                archivoborrar.delete();

                String route = new java.io.File(".").getCanonicalPath();
                fichero = new FileWriter (route+File.separator+"src"+File.separator+"Persistencia"+File.separator+"BD"+File.separator+"RecordsTablero"+File.separator+s+".txt");
                pw = new PrintWriter(fichero);
                pw.println("-2");
                pw.println("-2");
                pw.println("-2");
                pw.println("-2");
                pw.println("-2");
                if (null != fichero) {
                    try {
                        fichero.close();
                    }
                    catch (IOException ex) {
                        Logger.getLogger(ControladorDatosRecords.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }
            catch (IOException ex){
                Logger.getLogger(ControladorDatosRecords.class.getName()).log(Level.SEVERE, null, ex);   
            }
    }
    
    /*  PRE: 
        POST: Guarda la estructura ConjuntoRecords creando un archivo NombreTablero.txt para 
        cada uno de los tableros donde cada archivo contiene los records de ese tablero
    */
    
    public  void guardarRecordsTablero(ConjuntoRecords conj){
            HashMap<String,RecordTablero> aux=new HashMap();
            aux=conj.getRecords();
            FileWriter fichero = null;
            PrintWriter pw;
            try {
                // Apertura del fichero y creacion de BufferedReader para poder
                // hacer una lectura comoda (disponer del metodo readLine()).
                //Es guarda usuari i puntuacio al fitxer
                //FirstPlayer....BestTime...BestPunt
                //Si el jugador es null -> idjugador = -2
                for (Map.Entry<String, RecordTablero> mapEntry : aux.entrySet()) {
                    File archivoborrar;
                    String ruta = new java.io.File(".").getCanonicalPath();
                    archivoborrar = new File (ruta +File.separator+"src"+File.separator+"Persistencia"+File.separator+"BD"+File.separator+"RecordsTablero"+File.separator+mapEntry.getKey()+".txt");
                    archivoborrar.delete();
                    
                    String route = new java.io.File(".").getCanonicalPath();
                    fichero = new FileWriter (route+File.separator+"src"+File.separator+"Persistencia"+File.separator+"BD"+File.separator+"RecordsTablero"+File.separator+mapEntry.getKey()+".txt");
                    pw = new PrintWriter(fichero);
                    RecordTablero rec = new RecordTablero();
                    rec = mapEntry.getValue();
                    PairRecord[] pairs =rec.getAllRecords();
                    if (pairs[1].getIdJugador() == null)  pw.println("-2");
                    else pw.println(pairs[1].getIdJugador());
                    if (pairs[0].getIdJugador() == null) pw.println("-2");
                    else pw.println(pairs[0].getIdJugador());
                    pw.println(pairs[0].getPuntuacion());
                    if (pairs[2].getIdJugador() == null) pw.println("-2");
                    else pw.println(pairs[2].getIdJugador());
                    pw.println(pairs[2].getPuntuacion());
                    if (null != fichero) {
                        try {
                            fichero.close();
                        }
                        catch (IOException ex) {
                            Logger.getLogger(ControladorDatosRecords.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                }
                
                
            }
           
            catch (IOException ex){
                Logger.getLogger(ControladorDatosRecords.class.getName()).log(Level.SEVERE, null, ex);   
            }
    }
    
    public void eliminarRecordsTablero(String s) {
        File archivo = null;
        try {
            String ruta = new java.io.File(".").getCanonicalPath();
            archivo = new File (ruta +File.separator+"src"+File.separator+"Persistencia"+File.separator+"BD"+File.separator+"RecordsTablero"+File.separator+s+".txt");
            archivo.delete();
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }
    
    private static String stripExtension (String str) {
        if (str == null) return null;
        int pos = str.lastIndexOf(".");
        if (pos == -1) return str;
        return str.substring(0, pos);
    }
}
    
 
