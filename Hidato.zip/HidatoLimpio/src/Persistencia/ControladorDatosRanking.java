/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Persistencia;

import java.io.*;
import java.util.*;
import Compartidas.Ranking;
import Compartidas.Fila;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author Marc Barrio
 */
public class ControladorDatosRanking {
    
    
    private void crearFila(Fila f, PrintWriter pw){
        try{
            pw.println(f.getNombre());
            pw.println(f.getPuntuacion());
            pw.println(f.getFecha().toString());
        }
        catch (Exception e){
            e.printStackTrace();
        }
        
    }
    
    public void crearRanking(String dificultat, Ranking rank){
        FileWriter fichero = null;
        PrintWriter pw = null;
        try
        {
            String ruta = new java.io.File(".").getCanonicalPath();
            fichero = new FileWriter (ruta+File.separator+"src"+File.separator+"Persistencia"+File.separator+"BD"+File.separator+"Rankings"+File.separator+"Ranking"+dificultat+".txt");
            pw = new PrintWriter(fichero);
            int n = rank.getSize();
            for(int i = 1; i <= n; ++i){
                crearFila(rank.getFilapos(i), pw);
            }
 
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        finally {
           try {
           // Nuevamente aprovechamos el finally para
           // asegurarnos que se cierra el fichero.
           if (null != fichero)
              fichero.close();
           }
           catch (Exception e2) {
              e2.printStackTrace();
           }
        }
        
    }
    
    private Fila cargarFila(int pos, BufferedReader br){
        Fila f = new Fila();
        int punt = 0;
        String nombre = null;
        Date fecha = null;
        String auxfecha;
        SimpleDateFormat formateador = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzzz yyyy",Locale.ENGLISH);
        
        try{
            nombre = br.readLine();
            punt = Integer.parseInt(br.readLine());
            auxfecha = br.readLine();
            
            
            try {
                fecha = formateador.parse(auxfecha);
            }
            catch (ParseException ex) {
                ex.printStackTrace();
            }
            
        }
        catch (Exception e){
            e.printStackTrace();
        }
        f.setNombre(nombre);
        f.setPuntuacion(punt);
        f.setFecha(fecha);
        
        return f;
    }
    
    public Ranking cargarRanking(String dificultat){
        Ranking rank;
        rank = new Ranking();
        Fila ftmp;
      
        File fichero = null;
        FileReader reader = null;
        BufferedReader br = null;
        
        try{
            String ruta = new java.io.File(".").getCanonicalPath();
            fichero = new File (ruta+File.separator+"src"+File.separator+"Persistencia"+File.separator+"BD"+File.separator+"Rankings"+File.separator+"Ranking"+dificultat+".txt");
            reader = new FileReader(fichero);
            br = new BufferedReader(reader);
            int i = 1;
            while(br.ready()){
                ftmp = cargarFila(i, br);
                rank.insertarFila(ftmp);
                ++i;
            }
            
        }
        catch (Exception e){
            e.printStackTrace();
        }
        
        return rank;
    }
    
    
}
