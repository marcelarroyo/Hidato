/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Persistencia;

import Dominio.Estructuras.TableroHidato;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Hamid Latif
 */
public class ControladorPartidasGuardadas {
    
    //jugador es el nombre del jugador que está jugando
    //tiradas es el contador de tiradas que ha hecho hasta ese momento
    //nombreGuardado es el nombre que se le ha dado al guardado
    public void guardarPartida(TableroHidato t, String nombreJugador, int tiradas, int tiempo, boolean sumara) throws IOException{
        
        /*
        EL TABLERO EN UNA PARTIDA SE GUARDA ASI:
        Dentr0o del fichero Persistencia/BD/Partidas/"nombredeltablero".txt:
            tiempo acumulado    
            numero de tiradas           
            sumara
            tamañoDelTablero
            fila0
            fila1
            ...
            filaN
        */
        crearCarpeta(t.getNombreTablero());
        if (!existePartida(t.getNombreTablero(), nombreJugador)) crearEnReg(t.getNombreTablero(), nombreJugador);
        //else {
            File archivo = null;
            String ruta = new java.io.File(".").getCanonicalPath();
            archivo = new File(ruta+File.separator+"src"+File.separator+"Persistencia"+File.separator+"BD"+File.separator+"Partidas"+File.separator+t.getNombreTablero()+File.separator+nombreJugador+".txt");       
            archivo.delete();
        //}
        
        FileWriter fichero = null;
        PrintWriter pw;
        
        try {
            
            //String ruta = new java.io.File(".").getCanonicalPath();
            fichero = new FileWriter (ruta+File.separator+"src"+File.separator+"Persistencia"+File.separator+"BD"+File.separator+"Partidas"+File.separator+t.getNombreTablero()+File.separator+nombreJugador+".txt",true);
        } catch (IOException ex) {
            Logger.getLogger(ControladorDatosTablero.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        /*pw = new PrintWriter(fichero);
        pw.print("");
        pw.close();*/
        pw = new PrintWriter(fichero);
        pw.println(tiempo);
        pw.println(tiradas);
        if (sumara) pw.println("si");
        else pw.println("no");
        pw.println(t.getN());
        
        for (int i = 0; i < t.getN();++i){
            for (int j = 0; j < t.getN(); ++j){
                if (t.getCasilla(i,j).esUsable() == false){
                    pw.println("-1");
                }
                else if (t.getCasilla(i,j).isPrefijada()) {
                    pw.println(t.getCasilla(i,j).getValor());
                }
                else pw.println(t.getCasilla(i, j).getValor()*(-1));
            }
        }
        /*
        for (int i = 0; i < t.getN();++i){
            for (int j = 0; j < t.getN(); ++j){
                    pw.println(t.getValor(i, j));
            }
        }*/
        
        if (null != fichero) try {
            fichero.close();
        }
        catch (IOException ex) {
            Logger.getLogger(ControladorDatosTablero.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    /*  PRE: -
        POST: Se ha creado el nombre del tablero y jugador en el registro de partidas 
    */
    public void crearEnReg(String nombreTablero, String nombreJugador) {
        FileWriter fichero = null;
        PrintWriter pw = null;
        try
        {
            //File archivo;
            String ruta = new java.io.File(".").getCanonicalPath();
            //archivo = new File (ruta+File.separator+"src"+File.separator+"Persistencia"+File.separator+"BD"+File.separator+"BDTableros.txt");
            fichero = new FileWriter (ruta+File.separator+"src"+File.separator+"Persistencia"+File.separator+"BD"+File.separator+"BDPartidas.txt",true);
            //FileReader fr = new FileReader (archivo);
            //BufferedReader br = new BufferedReader(fr);
            String linea;
            //linea = br.readLine();
            pw = new PrintWriter(fichero);
            //if (!linea.equals(null)) pw.println(); //imprimimos una línea vacía para que no nos aparezcan dos juntas
            pw.println(nombreTablero);
            pw.println(nombreJugador);
 
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        finally {
           try {
           // Nuevamente aprovechamos el finally para
           // asegurarnos que se cierra el fichero.
           if (null != fichero)
              fichero.close();
           }
           catch (Exception e2) {
              e2.printStackTrace();
           }
        }
    }
    
    /*  PRE: Existe el jugador con nombre "nombreJugador"
        POST: Se retornan todos los tableros para los que el jugador tiene partidas guardadas
    */
    public String[] nombresGuardadas(String nombreJugador) {
        ArrayList<String> s = new ArrayList();
        
        File archivo;
        FileReader fr = null;
        BufferedReader br;
        
        try {
            // Apertura del fichero y creacion de BufferedReader para poder
            // hacer una lectura comoda (disponer del metodo readLine()).
            
            String ruta = new java.io.File(".").getCanonicalPath();
            archivo = new File (ruta+File.separator+"src"+File.separator+"Persistencia"+File.separator+"BD"+File.separator+"BDPartidas.txt");
            fr = new FileReader (archivo);
            br = new BufferedReader(fr);
            
            // Lectura del fichero
            String tablero, jugador;
            while((tablero = br.readLine())!=null){
                jugador = br.readLine();
                if (jugador.equals(nombreJugador)) s.add(tablero);
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }
        finally{
            // En el finally cerramos el fichero, para asegurarnos
            // que se cierra tanto si todo va bien como si salta
            // una excepcion.
            try{                   
                if( null != fr ){  
                    fr.close();    
                }                 
            }
            catch (Exception e2){
                e2.printStackTrace();
            }
        }
        String[] nombres = s.toArray(new String[s.size()]);
        return nombres;
    }
    
    
    /*  PRE: Existe el jugador con nombre "nombreJugador"
        POST: Se retornan todos los tableros que tienen partidas guardadas
    */
    public String[] nombresGuardadasTodos() {
        ArrayList<String> s = new ArrayList();
        
        File archivo;
        FileReader fr = null;
        BufferedReader br;
        
        try {
            // Apertura del fichero y creacion de BufferedReader para poder
            // hacer una lectura comoda (disponer del metodo readLine()).
            
            String ruta = new java.io.File(".").getCanonicalPath();
            archivo = new File (ruta+File.separator+"src"+File.separator+"Persistencia"+File.separator+"BD"+File.separator+"BDPartidas.txt");
            fr = new FileReader (archivo);
            br = new BufferedReader(fr);
            
            // Lectura del fichero
            String tablero, jugador;
            while((tablero = br.readLine())!=null){
                jugador = br.readLine();
                s.add(tablero);
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }
        finally{
            // En el finally cerramos el fichero, para asegurarnos
            // que se cierra tanto si todo va bien como si salta
            // una excepcion.
            try{                   
                if( null != fr ){  
                    fr.close();    
                }                 
            }
            catch (Exception e2){
                e2.printStackTrace();
            }
        }
        String[] nombres = s.toArray(new String[s.size()]);
        return nombres;
    }
    
    
    /*  PRE: - 
        POST: Retorna true si el jugador tiene una partida para ese tablero, false en caso contrario
    */
    public boolean existePartida(String nombreTablero, String nombreJugador) throws IOException {
        
        boolean encontrado = false;
        
        File archivo = null;
        FileReader fr = null;
        BufferedReader br = null;
        
        try {
            // Apertura del fichero y creacion de BufferedReader para poder
            // hacer una lectura comoda (disponer del metodo readLine()).
            String ruta = new java.io.File(".").getCanonicalPath();
            archivo = new File (ruta+File.separator+"src"+File.separator+"Persistencia"+File.separator+"BD"+File.separator+"BDPartidas.txt");
            fr = new FileReader (archivo);
            br = new BufferedReader(fr);
            
            // Lectura del fichero
            String linea, jugador;
            while((linea=br.readLine())!=null){
                if (nombreTablero.equals(linea)) {
                    jugador = br.readLine();
                    if (nombreJugador.equals(jugador)) encontrado = true;
                }
            }
        }
        catch(FileNotFoundException e){
            
        }
        finally{
            // En el finally cerramos el fichero, para asegurarnos
            // que se cierra tanto si todo va bien como si salta
            // una excepcion.
            try{                   
                if( null != fr ){  
                    fr.close();    
                }                 
            }
            catch (Exception e2){
                e2.printStackTrace();
            }
        }
        return encontrado;
    }
    
    /*  PRE: Existe la partida con nombre "nombrePartida"
        POST: Se ha cargado el contenido de la partida en el tablero t y borrado la misma de la base de datos
    */
    public TableroHidato cargarPartida(String nombreTablero, String nombreJugador) {
        
        File archivo;
        FileReader fr = null;
        BufferedReader br;
        int tiradas = 0;
        TableroHidato t = null;
        try {
            // Apertura del fichero y creacion de BufferedReader para poder
            // hacer una lectura comoda (disponer del metodo readLine()).
            String ruta = new java.io.File(".").getCanonicalPath();
            archivo = new File (ruta+File.separator+"src"+File.separator+"Persistencia"+File.separator+"BD"+File.separator+"Partidas"+File.separator+nombreTablero+File.separator+nombreJugador+".txt");
            fr = new FileReader (archivo);
            br = new BufferedReader(fr);
            int tiempo = Integer.parseInt(br.readLine());
            tiradas = Integer.parseInt(br.readLine());
            String aparecera = br.readLine();
            int tamano = Integer.parseInt(br.readLine()); //aquí solo retornamos el tablero, estas dos variables las cargamos antes en dos funciones a parte
                                                          //NOTA: HAY QUE CARGARLAS ANTES -> al cargar el tablero se borra de la BD!!!!!
            t = new TableroHidato(nombreTablero, tamano); //se crea el tablero con los parametros leidos
            for (int i = 0; i < t.getN(); ++i) {
                for (int j = 0; j < t.getN(); ++j) {
                    
                    int valorCasilla = Integer.parseInt(br.readLine());
                    if (valorCasilla == -1) { //si tiene valor -1, es no usable
                        t.setValor(-1, i, j);
                    }
                    else if (valorCasilla < -1) { //si tiene valor < -1, es una casilla puesta por el jugador
                        t.setValorUser(valorCasilla*(-1),i,j);
                    }
                    else t.setValor(valorCasilla, i, j); //si tiene valor >= 0 es una casilla prefijada
                }
            }
            
        }
        catch(IOException | NumberFormatException e){
        }
        finally{
            // En el finally cerramos el fichero, para asegurarnos
            // que se cierra tanto si todo va bien como si salta
            // una excepcion.
            try{                   
                if( null != fr ){  
                    fr.close();
                }                 
            }
            catch (Exception e2){
            }
        }
        borrarPartida(nombreTablero, nombreJugador);
        return t;
    }
    
    /*  PRE: Existe la partida con "nombrePartida"
        POST: Se ha borrado esa partida de la base de datos
    */
    public void borrarPartida(String nombreTablero, String nombreJugador) {
        ArrayList<String> s = new ArrayList();
        
        File archivo;
        FileReader fr = null;
        BufferedReader br;
        
        try {
            // Apertura del fichero y creacion de BufferedReader para poder
            // hacer una lectura comoda (disponer del metodo readLine()).
            
            String ruta = new java.io.File(".").getCanonicalPath();
            archivo = new File (ruta+File.separator+"src"+File.separator+"Persistencia"+File.separator+"BD"+File.separator+"BDPartidas.txt");
            fr = new FileReader (archivo);
            br = new BufferedReader(fr);
            
            // Lectura del fichero
            String partida, jugador;
            while((partida = br.readLine())!=null){
                jugador = br.readLine();
                s.add(partida);
                s.add(jugador);
            }
            archivo.delete(); //se borra todo el registro
            
            String[] nombres = s.toArray(new String[s.size()]);
            for (int i = 0; i < nombres.length; i+=2) { //no necesito crear el archivo, lo hace la función "crearEnReg"
                if (!(nombres[i].equals(nombreTablero) && nombres[i+1].equals(nombreJugador)))
                    crearEnReg(nombres[i], nombres[i+1]); //se recupera el registro, pero evitando crear la partida a borrar
            }
            archivo = new File (ruta+File.separator+"src"+File.separator+"Persistencia"+File.separator+"BD"+File.separator+"Partidas"+File.separator+nombreTablero+File.separator+nombreJugador+".txt");
            archivo.delete();
        }
        catch(Exception e){
            e.printStackTrace();
        }
        finally{
            // En el finally cerramos el fichero, para asegurarnos
            // que se cierra tanto si todo va bien como si salta
            // una excepcion.
            try{                   
                if( null != fr ){  
                    fr.close();    
                }                 
            }
            catch (Exception e2){
                e2.printStackTrace();
            }
        }
    }
    
    /*  PRE: Existe la partida guardada con nombre "nombreJugador"
        POST: Se retorna el numero de tiradas que tiene la partida 
    */
    public int getTiradas(String nombreTablero, String nombreJugador) {
        File archivo;
        FileReader fr = null;
        BufferedReader br;
        int tiradas = 0;
        System.out.println("Entro en getTiradas");
        
        try {
            System.out.println("Entro en el try");
            // Apertura del fichero y creacion de BufferedReader para poder
            // hacer una lectura comoda (disponer del metodo readLine()).
            String ruta = new java.io.File(".").getCanonicalPath();
            archivo = new File (ruta+File.separator+"src"+File.separator+"Persistencia"+File.separator+"BD"+File.separator+"Partidas"+File.separator+nombreTablero+File.separator+nombreJugador+".txt");
            fr = new FileReader (archivo);
            br = new BufferedReader(fr);
            int tiempo = Integer.parseInt(br.readLine());
            String tiradasS = br.readLine();
            tiradas = Integer.parseInt(tiradasS);
            System.out.println("Tiradas stirng: " + tiradasS +  " " + "tiradas int " + tiradas);
            
        }
        catch(IOException | NumberFormatException e){
        }
        finally{
            // En el finally cerramos el fichero, para asegurarnos
            // que se cierra tanto si todo va bien como si salta
            // una excepcion.
            try{                   
                if( null != fr ){  
                    fr.close();
                }                 
            }
            catch (Exception e2){
            }
        }
        return tiradas;
    }
    
    /*  PRE: Existe la partida guardada con nombre "nombreJugador"
        POST: Se retorna el tiempo que tiene la partida 
    */
    public int getTiempo(String nombreTablero, String nombreJugador) {
        File archivo;
        FileReader fr = null;
        BufferedReader br;
        int tiempo = 0;
        try {
            // Apertura del fichero y creacion de BufferedReader para poder
            // hacer una lectura comoda (disponer del metodo readLine()).
            String ruta = new java.io.File(".").getCanonicalPath();
            archivo = new File (ruta+File.separator+"src"+File.separator+"Persistencia"+File.separator+"BD"+File.separator+"Partidas"+File.separator+nombreTablero+File.separator+nombreJugador+".txt");
            fr = new FileReader (archivo);
            br = new BufferedReader(fr);
            tiempo = Integer.parseInt(br.readLine());
            
            
        }
        catch(IOException | NumberFormatException e){
        }
        finally{
            // En el finally cerramos el fichero, para asegurarnos
            // que se cierra tanto si todo va bien como si salta
            // una excepcion.
            try{                   
                if( null != fr ){  
                    fr.close();
                }                 
            }
            catch (Exception e2){
            }
        }
        return tiempo;
        
        
    }
    
    
    /*  PRE: Existe la partida guardada con nombre "nombreJugador"
        POST: Retorna true si el jugador sumará puntos esa partida, false en caso contrario
    */
    public boolean getSumara(String nombreTablero, String nombreJugador) {
        File archivo;
        FileReader fr = null;
        BufferedReader br;
        boolean sumara = false;
        try {
            // Apertura del fichero y creacion de BufferedReader para poder
            // hacer una lectura comoda (disponer del metodo readLine()).
            String ruta = new java.io.File(".").getCanonicalPath();
            archivo = new File (ruta+File.separator+"src"+File.separator+"Persistencia"+File.separator+"BD"+File.separator+"Partidas"+File.separator+nombreTablero+File.separator+nombreJugador+".txt");
            fr = new FileReader (archivo);
            br = new BufferedReader(fr);
            int tiempo = Integer.parseInt(br.readLine());
            int tiradas = Integer.parseInt(br.readLine());
            String aparecer = br.readLine();
            if (aparecer.equals("si")) sumara = true;
            else sumara = false;
            
        }
        catch(IOException | NumberFormatException e){
        }
        finally{
            // En el finally cerramos el fichero, para asegurarnos
            // que se cierra tanto si todo va bien como si salta
            // una excepcion.
            try{                   
                if( null != fr ){  
                    fr.close();
                }                 
            }
            catch (Exception e2){
            }
        }
        return sumara;
    }
    
    
    
    private void crearCarpeta(String nombreTablero) throws IOException {
        String ruta = new java.io.File(".").getCanonicalPath();
        File theDir = new File(ruta+File.separator+"src"+File.separator+"Persistencia"+File.separator+"BD"+File.separator+"Partidas"+File.separator+nombreTablero);

        // if the directory does not exist, create it
        if (!theDir.exists()) {

            try{
                new File(ruta+File.separator+"src"+File.separator+"Persistencia"+File.separator+"BD"+File.separator+"Partidas"+File.separator+nombreTablero).mkdirs();
            } 
            catch(SecurityException se){
                //handle it
            }
        }
    }
}
