/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Persistencia;

import Dominio.Estructuras.Pair;
import Dominio.Estructuras.PairString;
import java.io.*;
import Dominio.Estructuras.TableroHidato;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;
//imports especiales:
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author raul.ibanez.perez
 */
public class ControladorDatosTablero {
    
    public HashMap<String,String> nombresTab = new HashMap<>();
    
    public ControladorDatosTablero(){ }
    
    public PairString[] nombreTableros(){
        Vector<PairString> nombres = new Vector<PairString>();
        File archivo = null;
        FileReader fr = null;
        BufferedReader br = null;
        try {
            String ruta = new java.io.File(".").getCanonicalPath();
            archivo = new File (ruta+File.separator+"src"+File.separator+"Persistencia"+File.separator+"BD"+File.separator+"BDTableros.txt");
            fr = new FileReader (archivo);
            br = new BufferedReader(fr);
            
            // Lectura del fichero
            String linea;
            while((linea=br.readLine())!=null){
                PairString p = new PairString();
                p.setFirst(linea);
                linea = br.readLine();
                p.setSecond(linea);
                nombres.add(p);
                br.readLine();
            }
            
        }
        catch(IOException e) {
            e.printStackTrace();
        }
        finally{
            // En el finally cerramos el fichero, para asegurarnos
            // que se cierra tanto si todo va bien como si salta
            // una excepcion.
            try{                   
                if( null != fr ){  
                    fr.close();
                }                 
            }
            catch (Exception e2){
                e2.printStackTrace();
            }
        }
        PairString[] s = new PairString[nombres.size()];
        nombres.copyInto(s);
        return s;
    }
    
    public boolean nombreTableroExistente(String n){
        boolean encontrado = false;
        
        File archivo;
        FileReader fr = null;
        BufferedReader br;
        
        
        try {
            String ruta = new java.io.File(".").getCanonicalPath();
            archivo = new File (ruta+File.separator+"src"+File.separator+"Persistencia"+File.separator+"BD"+File.separator+"BDTableros.txt");
            fr = new FileReader (archivo);
        } catch (IOException ex) {
            Logger.getLogger(ControladorDatosTablero.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        br = new BufferedReader(fr);

        // Lectura del fichero
        String linea;
        try {
            while((linea=br.readLine())!=null){
                if (n.equals(linea)) encontrado = true;
                br.readLine();
                br.readLine();
            }
        }
        catch (IOException ex) {
            Logger.getLogger(ControladorDatosTablero.class.getName()).log(Level.SEVERE, null, ex);
        }
        
                      
        if( null != fr ){  
            try {    
                fr.close();
            }
            catch (IOException ex) {
                Logger.getLogger(ControladorDatosTablero.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return encontrado;
    }
    
    public TableroHidato cargarTablero(String n){
        
        TableroHidato auxTablero = new TableroHidato(n,0);
        
        File archivo;
        FileReader fr = null;
        BufferedReader br;
        try {
            // Apertura del fichero y creacion de BufferedReader para poder
            // hacer una lectura comoda (disponer del metodo readLine()).
            String ruta = new java.io.File(".").getCanonicalPath();
            archivo = new File (ruta+File.separator+"src"+File.separator+"Persistencia"+File.separator+"BD"+File.separator+"Tableros"+File.separator+n+".txt");
            fr = new FileReader (archivo);
            br = new BufferedReader(fr);
            String auxNombreCreador = br.readLine();
            int dif = Integer.parseInt(br.readLine());
            int auxTamany = Integer.parseInt(br.readLine());
            auxTablero = new TableroHidato(n,auxTamany);
            auxTablero.setNombreCreador(auxNombreCreador);
            for (int i = 0; i < auxTablero.getN(); ++i) {
                for (int j = 0; j < auxTablero.getN(); ++j) {
                    
                    int valorCasilla = Integer.parseInt(br.readLine());
                    if (valorCasilla == -1) {
                        auxTablero.setValor(-1, i, j);
                    }
                    else {
                        auxTablero.setValor(valorCasilla,i,j);
                    }
                }
            }
            for (int i = 0; i < auxTablero.getN(); ++i) {
                for (int j = 0; j < auxTablero.getN(); ++j) {
                    
                    int valorCasilla = Integer.parseInt(br.readLine());
                    auxTablero.setSolucion(-1, i, j);
                    
                }
            }
            auxTablero.setDificultad(dif);
            auxTablero.setNombreTablero(n);
        }
        catch(IOException | NumberFormatException e){
        }
        finally{
            // En el finally cerramos el fichero, para asegurarnos
            // que se cierra tanto si todo va bien como si salta
            // una excepcion.
            try{                   
                if( null != fr ){  
                    fr.close();
                }                 
            }
            catch (Exception e2){
            }
        }
        
        return auxTablero;
    }
    
    public void guardarTablero(TableroHidato t){
        
        /*
        EL TABLERO SE GUARDA ASI:
        Dentr0o del fichero Persistencia/BD/Tableros/"nombredeltablero".txt:
            nombreUsuarioCreador
            dificultad
            tamañoDelTablero
            fila0
            fila1
            ...
            filaN
        */
        
        borrarBDTablero(t.getNombreTablero());
        
        FileWriter fichero = null;
        PrintWriter pw;
        
        try {
            String ruta = new java.io.File(".").getCanonicalPath();
            fichero = new FileWriter (ruta+File.separator+"src"+File.separator+"Persistencia"+File.separator+"BD"+File.separator+"Tableros"+File.separator+t.getNombreTablero()+".txt",true);
        } catch (IOException ex) {
            Logger.getLogger(ControladorDatosTablero.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        pw = new PrintWriter(fichero);
        
        pw.println(t.getNombreCreador());
        pw.println(t.getDificultad());
        pw.println(t.getN());
        
        for (int i = 0; i < t.getN();++i){
            for (int j = 0; j < t.getN(); ++j){
                if (t.getCasilla(i,j).esUsable() == false){
                    pw.println("-1");
                }
                else {
                    pw.println(t.getCasilla(i,j).getValor());
                }
            }
        }
        for (int i = 0; i < t.getN();++i){
            for (int j = 0; j < t.getN(); ++j){
                    pw.println(t.getSolucion(i, j));
            }
        }
        
        if (null != fichero) try {
            fichero.close();
        }
        catch (IOException ex) {
            Logger.getLogger(ControladorDatosTablero.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
   /* public PairString[] getNombres() {
        int i = 0;
        PairString vect[] = new PairString[nombresTab.size()];
        for (Map.Entry<String, String> mapEntry : nombresTab.entrySet()) {
            vect[i].setFirst(mapEntry.getKey());
            vect[i].setSecond(mapEntry.getValue());
        }
        return vect;
    }
    */
   
    
    public void crearTablero(TableroHidato t) {
        FileWriter fichero = null;
        PrintWriter pw;
        System.out.println(t.getNombreTablero());
        System.out.println(t.getNombreCreador());
        try {
            String ruta = new java.io.File(".").getCanonicalPath();
            fichero = new FileWriter (ruta+File.separator+"src"+File.separator+"Persistencia"+File.separator+"BD"+File.separator+"BDTableros.txt",true);       
        } catch (IOException ex) {
            Logger.getLogger(ControladorDatosTablero.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        pw = new PrintWriter(fichero);

        pw.println(t.getNombreTablero());
        pw.println(t.getNombreCreador());
        pw.println(t.getDificultad());
        
        if (null != fichero)
           try {
               fichero.close();
        } catch (IOException ex) {
            Logger.getLogger(ControladorDatosTablero.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void borrarTablero(String n){
        
        //Miro si hay más de un usuario en BDUsuarios.txt
        
        int numeroDeTableros = 0;
        
        File archivo;
        FileReader fr = null;
        BufferedReader br;
        
        try {
            String ruta = new java.io.File(".").getCanonicalPath();
            archivo = new File(ruta+File.separator+"src"+File.separator+"Persistencia"+File.separator+"BD"+File.separator+"BDTableros.txt");       
            fr = new FileReader (archivo);
            br = new BufferedReader(fr);
            
            while(((br.readLine())!=null)) {
                ++numeroDeTableros;
                br.readLine();
                br.readLine();
            }
        }
        catch(Exception e){
        }
        finally{
            try{                   
                if( null != fr )fr.close();  
            }
            catch (Exception e2){
            }
        }
        //Si hay más de uno borro el usuario, si hay solo uno reseteo BDUsuarios.txt
        if (numeroDeTableros > 1) this.borrarTablero2(n);
        else this.borrarTablero3(n);
    }
    
    private void borrarTablero2(String n){
        
        //LEO ARCHIVO = BDUsuarios.txt
        //ESCRIBO FICHERO = BDUsuarios2.txt
        
        //LEO BDUsuarios.txt y ESCRIBO EN BDUsuarios2.txt
        
        File archivo = null;
        FileReader fr = null;
        BufferedReader br; 
        FileWriter fichero = null;
        
        try {
            // Apertura del fichero y creacion de BufferedReader para poder
            // hacer una lectura comoda (disponer del metodo readLine()).
            String ruta = new java.io.File(".").getCanonicalPath();
            archivo = new File(ruta+File.separator+"src"+File.separator+"Persistencia"+File.separator+"BD"+File.separator+"BDTableros.txt");       
            fr = new FileReader (archivo);
            br = new BufferedReader(fr);
            
            // Lectura del fichero
            String linea;
            while(((linea=br.readLine())!=null)){
                if (n.equals(linea)) {
                    //Si es l'usuari que busco paso al següent nom d'usuari.//buscam
                    br.readLine();
                    br.readLine();
                }
                else{
                    //Si no, guardo l'usuri a la BD auxiliar.
                    
                    PrintWriter pw;
                    try
                    {   
                        String route = new java.io.File(".").getCanonicalPath();
                        fichero = new FileWriter(route+File.separator+"src"+File.separator+"Persistencia"+File.separator+"BD"+File.separator+"BDTableros2.txt",true);       
                        pw = new PrintWriter(fichero);
                        //guardamos nombretab nombrecreador dificultad
                        pw.println(linea);
                        linea=br.readLine();
                        pw.println(linea);
                        linea=br.readLine();
                        pw.println(linea);

                    }
                    catch (Exception e) {
                    }
                    finally {
                       try {
                       // Nuevamente aprovechamos el finally para
                       // asegurarnos que se cierra el fichero.
                       if (null != fichero)
                          fichero.close();
                       }
                       catch (Exception e2) {
                       }
                    }
                }
            }
        }
        catch(Exception e){
        }
        finally{
            // En el finally cerramos el fichero, para asegurarnos
            // que se cierra tanto si todo va bien como si salta
            // una excepcion.
            try{                   
                if( null != fr ){  
                    fr.close();    
                }                 
            }
            catch (Exception e2){
            }
        }
        
        // Borro BDUsuarios.txt
        
        archivo.delete();
        
        //Escric a BDUsuarios.txt el que hi ha a BDUsuarios2.txt
        
        try {
            // Apertura del fichero y creacion de BufferedReader para poder
            // hacer una lectura comoda (disponer del metodo readLine()).
            String ruta = new java.io.File(".").getCanonicalPath();
            archivo = new File(ruta+File.separator+"src"+File.separator+"Persistencia"+File.separator+"BD"+File.separator+"BDTableros2.txt");       
            fichero = null;
            fr = new FileReader (archivo);
            br = new BufferedReader(fr);
            
            // Lectura del fichero
            String linea;
            while(((linea=br.readLine())!=null)){
                //Guardo l'usuri a la BD.
                PrintWriter pw;
                try
                {
                    String route = new java.io.File(".").getCanonicalPath();
                    fichero = new FileWriter(route+File.separator+"src"+File.separator+"Persistencia"+File.separator+"BD"+File.separator+"BDTableros.txt",true);       
                    pw = new PrintWriter(fichero);
                    //copiamos nombretablero nombre creador y dificultad
                    pw.println(linea);
                    linea=br.readLine();
                    pw.println(linea);
                    linea=br.readLine();
                    pw.println(linea);

                }
                catch (Exception e) {
                }
                finally {
                   try {
                   // Nuevamente aprovechamos el finally para
                   // asegurarnos que se cierra el fichero.
                   if (null != fichero)
                      fichero.close();
                   }
                   catch (Exception e2) {
                   }
                }
            }
        }
        catch(Exception e){
        }
        finally{
            // En el finally cerramos el fichero, para asegurarnos
            // que se cierra tanto si todo va bien como si salta
            // una excepcion.
            try{                   
                if( null != fr ){  
                    fr.close();    
                }                 
            }
            catch (Exception e2){
            }
        }
        
        //Elimino BDUsuarios2.txt
        try {
            String ruta = new java.io.File(".").getCanonicalPath();
            archivo = new File(ruta+File.separator+"src"+File.separator+"Persistencia"+File.separator+"BD"+File.separator+"BDTableros2.txt");       
        }
        catch(IOException e) {
            
        }
        
        archivo.delete();
        
        //Elimino Usuaiors/n.txt
        
        this.borrarBDTablero(n);
        
    }
    
    private void borrarTablero3(String n){
        // Borro la BD del usuario.
        File archivo = null;
        this.borrarBDTablero(n);
        //Borro la BD con el nombre y la contraseña.
        try {
            String ruta = new java.io.File(".").getCanonicalPath();
            archivo = new File(ruta+File.separator+"src"+File.separator+"Persistencia"+File.separator+"BD"+File.separator+"BDTableros.txt");       
            archivo.delete();
        }
        catch (IOException e) {
            
        }
       
        //Creo una BD vacía.
        try {
            String ruta = new java.io.File(".").getCanonicalPath();
            FileWriter fichero = new FileWriter(ruta+File.separator+"src"+File.separator+"Persistencia"+File.separator+"BD"+File.separator+"BDTableros.txt");       
        } catch (IOException ex) {
            Logger.getLogger(ControladorDatosUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void borrarBDTablero(String n){
        File archivo;
        try {
            String ruta = new java.io.File(".").getCanonicalPath();
            archivo = new File(ruta+File.separator+"src"+File.separator+"Persistencia"+File.separator+"BD"+File.separator+"Tableros"+File.separator+n+".txt");       
            archivo.delete();
        }
        catch (IOException e){
            
        }
    }
    
}
