/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tests;
/**
 *
 * @author Hamid Latif
 */

import Dominio.Estructuras.CasillaHidato;
import Dominio.Algoritmos2;
import Dominio.Estructuras.Pair;
import Dominio.Estructuras.TableroHidato;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.Vector;
public class TestAlgoritmos {
    
    private static int opcion = 0;
    private static Algoritmos2 a = new Algoritmos2();
    
    public static void main(String[] args) {
        while (opcion != 3) {
            try {
                System.out.println();
                System.out.println("    #########################################");
                System.out.println("    #            TEST ALGORITMOS            #");
                System.out.println("    #########################################");
                System.out.println("    #                                       #");
                System.out.println("    #    Escoje opcion:                     #");
                System.out.println("    #                                       #");
                System.out.println("    #    1) Resolver(TableroHidato, boolean)#");
                System.out.println("    #    2) Generar(TableroHidato)          #");
                System.out.println("    #    3) Salir                           #");
                System.out.println("    #########################################");

                Scanner in = new Scanner(System.in);
                System.out.print("\n    Opción: ");
                opcion = in.nextInt();
                System.out.print("\n");
                if (opcion == 1) {

                    System.out.println("Introduce tu tablero para que sea resuelto");
                    in = new Scanner(System.in);
                    System.out.println("Introduce el nombre del tablero");
                    String nombre = in.nextLine();
                    System.out.println("Introduce el tamaño del tablero");
                    in = new Scanner(System.in);
                    int tamano = in.nextInt();
                    TableroHidato t = new TableroHidato(nombre, tamano);
                    System.out.println("Introduce el valor de cada casilla");
                    int valor;
                    for (int i = 0; i < tamano; ++i) {
                        for (int j = 0; j < tamano; ++j) {
                            in = new Scanner(System.in);
                            System.out.println("Valor de la casilla ["+i+"]["+j+"]");
                            valor = in.nextInt();
                            t.setValor(valor, i, j);
                        }
                    }
                    System.out.println("El tablero resultante es:");
                    a.resolver(t, true);
                    t.getSolucion();System.out.println("\nSolucion del tablero generado:");
                    dibujarSolucionDelTablero(t.retornaSolucion(),t.getTamano());
                    System.out.println("");
                }
                else if (opcion == 2) {
                    System.out.print(" > Tamaño del tablero random (entre 2 y 6): ");
                    in = new Scanner(System.in);
                    TableroHidato t = new TableroHidato("test",in.nextInt());
                    t = a.generadorTableroRandomRecursivo(t);
                    System.out.println("\nTablero generado:");
                    t.dibujarTablero();
                    System.out.println("\nSolucion del tablero generado:");
                    dibujarSolucionDelTablero(t.retornaSolucion(),t.getTamano());
                    System.out.println("");
                }
            }
            catch (InputMismatchException e) {
                System.out.println("@ Has introducido un valor inválido @");
            }
        }
    }
    
    private static void dibujarSolucionDelTablero(int[][] sol, int t) {
        System.out.print("\n");
        for (int i = 0; i < t; ++i) {
            System.out.print("    ");
            for (int j = 0; j < t; ++j) {
                int auxMaxCol = maxDecCol(j, sol);
                int auxCalcul = calculEspais(sol[i][j],auxMaxCol);
                if (sol[i][j] > 0) System.out.print(sol[i][j]);
                else System.out.print("X");
                for (int e = 0; e < auxCalcul;++e){
                    System.out.print(" ");
                }
            }
            System.out.print("\n");
        }
    }
    
    private static int calculEspais (int i, int max){
        int aux = 0;
        if (i < 10) aux = 1;
        else if (i < 100) aux = 2;
        else aux = 3;
        //System.out.println("i = "+i+" max = "+max+" aux = "+aux);
        return (2 + (max - aux));
    }
    
    private static int maxDecCol (int i, int[][] sol) {
        int max = 1;
        int auxTamano = sol.length;
        for (int j = 0; j < auxTamano; ++j) {
            if (sol[j][i] > 9 && sol[j][i] < 99 && max < 2) max = 2;
            else if (sol[j][i] > 99) max = 3;
        }
        return max;
    }
    
}
