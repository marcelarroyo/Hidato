/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tests;
import Dominio.Estructuras.CasillaHidato;
import java.util.Scanner;

/**
 *
 * @author raul.ibanez.perez
 */

public class TestCasillaHidato {
    
    private static int opcion = 0;
    private static CasillaHidato casilla;
    
    public static void main(String[] args) {
        System.out.println();
        while (opcion != 4) {
            System.out.println("    #######################################");
            System.out.println("    #         TEST CASILLA HIDATO         #");
            System.out.println("    #######################################");
            System.out.println("    #                                     #");
            System.out.println("    #    Escoje opcion:                   #");
            System.out.println("    #                                     #");
            System.out.println("    #    1) CasillaHidato(x, y)           #");
            System.out.println("    #    2) esUsable()                    #");
            System.out.println("    #    3) setUsabilidadCasilla(boolean) #");
            System.out.println("    #                                     #");
            System.out.println("    #    4) Salir                         #");
            System.out.println("     #                                   # ");
            System.out.println("      ###################################  ");
            
            Scanner in = new Scanner(System.in);
            System.out.print("\n    Opción: ");
            opcion = in.nextInt();
            System.out.print("\n");
            
            if (opcion == 1) {
                System.out.print("    X: ");
                in = new Scanner(System.in);
                int xAux = in.nextInt();
                System.out.print("\n");
                System.out.print("    Y: ");
                in = new Scanner(System.in);
                int yAux = in.nextInt();
                System.out.print("\n");
                casilla = new CasillaHidato(xAux, yAux);
            }
            
            else if (opcion == 2) System.out.println("    "
                    +Boolean.toString(casilla.esUsable()));
            
            else if (opcion == 3) {
                System.out.println("    (Para simplificar solo puedes escribir 'true' o 'false')");
                System.out.print("    > ");
                in = new Scanner(System.in);
                casilla.setUsabilidadCasilla(Boolean.parseBoolean(in.nextLine()));
                System.out.print("\n");
            }
        }
    }
}

