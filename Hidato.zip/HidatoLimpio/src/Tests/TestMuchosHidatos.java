/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tests;

import Dominio.Algoritmos2;
import Dominio.Estructuras.Pair;
import Dominio.Estructuras.TableroHidato;
import java.util.InputMismatchException;
import java.util.Random;

public class TestMuchosHidatos {
    
    private static Algoritmos2 a = new Algoritmos2();
    private static int nH = 1;
    private static TableroHidato TH;
    
    public static void main(String[] args) {
        
        System.out.println("\n");
        System.out.println("    ##########################################");
        System.out.println("    ## TESTS QUE SOLUCIONA DIVERSOS HIDATOS ##");
        System.out.println("    ##########################################");
        
        System.out.println("\n    Hidato ("+nH+"):");
        TH = new TableroHidato("test",9);
        TH.setValor(60,0,2);TH.setValor(69,0,7);TH.setValor(70,0,8);
        TH.setValor(52,1,0);TH.setValor(61,1,2);TH.setValor(66,1,6);
        TH.setValor(56,2,2);TH.setValor(62,2,3);TH.setValor(76,2,6);
        TH.setValor(49,3,0);TH.setValor(12,3,1);TH.setValor(14,3,3);TH.setValor(79,3,4);TH.setValor(17,3,6);TH.setValor(74,3,8);
        TH.setValor(10,4,1);TH.setValor(18,4,6);
        TH.setValor(81,5,3);TH.setValor(23,5,7);TH.setValor(24,5,8);
        TH.setValor(44,6,1);TH.setValor(4,6,4);TH.setValor(1,6,5);TH.setValor(33,6,6);
        TH.setValor(43,7,1);TH.setValor(7,7,2);TH.setValor(27,7,6);TH.setValor(31,7,8);
        TH.setValor(42,8,0);TH.setValor(35,8,5);TH.setValor(30,8,8);
        TH.dibujarTablero();
        System.out.println("\n    Solucion ("+nH+"):");
        a.resolver(TH, true);
        dibujarSolucionDelTablero(TH.retornaSolucion(),TH.getTamano());
        
        ++nH;
        
        
        System.out.println("\n    Hidato ("+nH+"):");
        TH = new TableroHidato("test",7);
        TH.setValor(-1,0,0);TH.setValor(-1,0,1);TH.setValor(26,0,2);TH.setValor(23,0,4);TH.setValor(-1,0,5);TH.setValor(-1,0,6);
        TH.setValor(27,1,1);TH.setValor(-1,1,3);TH.setValor(20,1,5);TH.setValor(1,1,6);
        TH.setValor(30,2,1);TH.setValor(6,2,2);TH.setValor(-1,2,3);TH.setValor(21,2,4);
        TH.setValor(31,3,0);TH.setValor(-1,3,2);TH.setValor(-1,3,4);TH.setValor(3,3,5);TH.setValor(18,3,6);
        TH.setValor(8,4,1);TH.setValor(9,4,2);TH.setValor(-1,4,3);TH.setValor(15,4,5);
        TH.setValor(33,5,0);TH.setValor(-1,5,3);TH.setValor(14,5,4);TH.setValor(16,5,6);
        TH.setValor(-1,6,0);TH.setValor(-1,6,1);TH.setValor(35,6,2);TH.setValor(11,6,3);TH.setValor(-1,6,5);TH.setValor(-1,6,6);
        TH.dibujarTablero();
        System.out.println("\n    Solucion ("+nH+"):");
        a.resolver(TH, true);
        dibujarSolucionDelTablero(TH.retornaSolucion(),TH.getTamano());
        
        ++nH;
        
        System.out.println("\n    Hidato ("+nH+"):");
        TH = new TableroHidato("tablero", 6);
        TH.setValor(24, 0, 4);
        TH.setValor(18, 1, 0);
        TH.setValor(16, 1, 1);
        TH.setValor(20, 1, 2);
        TH.setValor(23, 1, 3);
        TH.setValor(12, 2, 2);
        TH.setValor(29, 2, 3);
        TH.setValor(30, 2, 4);
        TH.setValor(27, 2, 5);
        TH.setValor(14, 3, 0);
        TH.setValor(5, 3, 3);
        TH.setValor(31, 3, 5);
        TH.setValor(7, 4, 1);
        TH.setValor(36, 4, 2);
        TH.setValor(3, 4, 5);
        TH.setValor(9, 5, 0);
        TH.setValor(34, 5, 3);
        TH.setValor(1, 5, 4);
        TH.dibujarTablero();
        System.out.println("\n    Solucion ("+nH+"):");
        a.resolver(TH, true);
        dibujarSolucionDelTablero(TH.retornaSolucion(),TH.getTamano());
        
        System.out.println("");
        
        ++nH;
        
        while (nH < 100) {
            
            // PARTE RANDOM //
            
            System.out.println("\n    Hidato ("+nH+"):");
            
            Random r = new Random();
            
            int numRand = r.nextInt(3) + 3;
            
            TH = new TableroHidato("TEST", numRand);
            
            TH = a.generadorTableroRandomRecursivo(TH);
            
            TH.dibujarTablero();
            
            System.out.println("\n    Solucion ("+nH+"):");
            
            a.resolver(TH, true);
            
            dibujarSolucionDelTablero(TH.retornaSolucion(),TH.getTamano());
            System.out.println("");
            
            

            ++nH;
        
        }
    }
    
    private static void dibujarSolucionDelTablero(int[][] sol, int t) {
        System.out.print("\n");
        for (int i = 0; i < t; ++i) {
            System.out.print("    ");
            for (int j = 0; j < t; ++j) {
                int auxMaxCol = maxDecCol(j, sol);
                int auxCalcul = calculEspais(sol[i][j],auxMaxCol);
                if (sol[i][j] > 0) System.out.print(sol[i][j]);
                else System.out.print("X");
                for (int e = 0; e < auxCalcul;++e){
                    System.out.print(" ");
                }
            }
            System.out.print("\n");
        }
    }
    
    private static int calculEspais (int i, int max){
        int aux = 0;
        if (i < 10) aux = 1;
        else if (i < 100) aux = 2;
        else aux = 3;
        //System.out.println("i = "+i+" max = "+max+" aux = "+aux);
        return (2 + (max - aux));
    }
    
    private static int maxDecCol (int i, int[][] sol) {
        int max = 1;
        int auxTamano = sol.length;
        for (int j = 0; j < auxTamano; ++j) {
            if (sol[j][i] > 9 && sol[j][i] < 99 && max < 2) max = 2;
            else if (sol[j][i] > 99) max = 3;
        }
        return max;
    }
    
}
