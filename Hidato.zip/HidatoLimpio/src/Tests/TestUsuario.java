/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tests;
import Compartidas.Usuario;
import java.util.Scanner;
import java.util.*;

/**
 *
 * @author raul.ibanez.perez
 */

public class TestUsuario {
    
    private static int opcion = 0;
    private static Usuario user;
    private static String nombreAux;
    private static String contrasenaAux;
    
    public static void main(String[] args) {
        System.out.println();
        while (opcion != 12) {
            System.out.println("    ###################################");
            System.out.println("    #          TEST USUARIO           #");
            System.out.println("    ###################################");
            System.out.println("    #                                 #");
            System.out.println("    #    Escoje opcion:               #");
            System.out.println("    #                                 #");
            System.out.println("    #    1) Usuario()                 #");
            System.out.println("    #    2) Usuario(nombre,contraseña)#");
            System.out.println("    #    3) getNombre()               #");
            System.out.println("    #    4) getContrasena()           #");
            System.out.println("    #    5) getFecha()                #");
            System.out.println("    #    6) getApareceRanking()       #");
            System.out.println("    #    7) setNombre(nombre)         #");
            System.out.println("    #    8) setContrasena(contrasena) #");
            System.out.println("    #    9) toggleApareceRanking()    #");
            System.out.println("    #   10) setFecha()                #");
            System.out.println("    #   11) setApareceRanking(boolean)#");
            System.out.println("    #                                 #");
            System.out.println("    #   12) Salir                     #");
            System.out.println("     #                               # ");
            System.out.println("      ###############################  ");
            
            Scanner in = new Scanner(System.in);
            System.out.print("\n    Opción: ");
            opcion = in.nextInt();
            System.out.print("\n");
            
            if (opcion == 1) user = new Usuario();
            
            else if (opcion == 2) {
                System.out.print("    Nombre: ");
                in = new Scanner(System.in);
                nombreAux = in.nextLine();
                System.out.print("\n");
                System.out.print("    Contraseña: ");
                in = new Scanner(System.in);
                contrasenaAux = in.nextLine();
                System.out.print("\n");
                user = new Usuario(nombreAux,contrasenaAux);
            }
            
            else if (opcion == 3) System.out.println("    Nombre: "+user.getNombre()+"\n");
            
            else if (opcion == 4) System.out.println("    Contraseña: "+user.getContrasena()+"\n");
            
            else if (opcion == 5) System.out.println("    Fecha: "+user.getFecha().toString()+"\n");
            
            else if (opcion == 6) System.out.println("    ApareceRanking: "+Boolean.toString(user.getApareceRanking())+"\n");
                        
            else if (opcion == 7) {
                System.out.print("    Nombre: ");
                in = new Scanner(System.in);
                nombreAux = in.nextLine();
                System.out.print("\n");
                user.setNombre(nombreAux);
                //System.out.print("\n");
            }
            
            else if (opcion == 8) {
                System.out.print("    Contrasena: ");
                in = new Scanner(System.in);
                contrasenaAux = in.nextLine();
                System.out.print("\n");
                user.setContrasena(contrasenaAux);
                //System.out.print("\n");
            }
            
            else if (opcion == 9) {
                user.toggleApareceRanking();
            }
            
            else if (opcion == 10) {
                System.out.println("    (Para simplificar se pondra a la fecha actual)");
                user.setFecha(new Date());
            }
            else if (opcion == 11) {
                System.out.println("    (Para simplificar solo puedes escribir 'true' o 'false')");
                System.out.print("    > ");
                in = new Scanner(System.in);
                user.setApareceRanking(Boolean.parseBoolean(in.nextLine()));
                System.out.print("\n");
            }
        }
    }
}
