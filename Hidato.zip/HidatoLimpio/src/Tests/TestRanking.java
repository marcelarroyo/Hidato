/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tests;

import Compartidas.Fila;
import Compartidas.Ranking;
import java.util.Date;
import java.util.Scanner;

/**
 *
 * @author Marc Barrio Ruiz
 */
public class TestRanking {
    private static int opcion = 0;
    private static Fila fila;
    private static String nombreAux;
    private static Ranking ranking;
    private static int puntAux;
    
    public static void main(String[] args) {
        System.out.println();
        while (opcion != 10) {
            System.out.println("    ########################################");
            System.out.println("    #          TEST Ranking                #");
            System.out.println("    ########################################");
            System.out.println("    #                                      #");
            System.out.println("    #    Escoje opcion:                    #");
            System.out.println("    #                                      #");
            System.out.println("    #    1) Ranking()                      #");
            System.out.println("    #    2) getFila(nombreUsuario)         #");
            System.out.println("    #    3) getSize()                      #");
            System.out.println("    #    4) insertarFila(Fila)             #");
            System.out.println("    #    5) borrarFila(nombreUsuario)      #");
            System.out.println("    #    6) actualizarUsuario(Fila)        #");
            System.out.println("    #    7) getFilapos(posicio)            #");  
            System.out.println("    #    8) Imprimir Ranking ordenado      #");            
            System.out.println("    #    9) existeUsuario()                #");
            System.out.println("    #    10) Salir                         #");
            System.out.println("     #                                    # ");
            System.out.println("      ####################################  ");
            
            Scanner in = new Scanner(System.in);
            System.out.print("\n    Opción: ");
            opcion = in.nextInt();
            System.out.print("\n");
            
            if (opcion == 1) {
                ranking = new Ranking();
            }
            
            else if (opcion == 2) {
                System.out.print("  NombreUsuario: ");
                in = new Scanner(System.in);
                nombreAux = in.nextLine();
                System.out.print("\n");
                fila = ranking.getFila(nombreAux);
                System.out.println("    Nombre usuario de la fila escogida, cogiendolo desde el objeto fila "+fila.getNombre()+"\n");
            }
            
            else if (opcion == 3) {
                System.out.print("  Tamano del ranking: "+ranking.getSize()+"\n");
            }
            
            else if (opcion == 4) {
                System.out.println("    Puntuacion de la fila a insertar: ");
                in = new Scanner(System.in);
                puntAux = in.nextInt();
                System.out.println("\n");
                System.out.println("    Nombre del usuario a insertar: ");
                in = new Scanner(System.in);
                nombreAux = in.nextLine();
                System.out.println("\n");
                fila = new Fila(puntAux, nombreAux);
                ranking.insertarFila(fila);
            }
            
            else if (opcion == 5) {
                System.out.println("    Nombre usuario a borrar: ");
                in = new Scanner(System.in);
                nombreAux = in.nextLine();
                System.out.println("\n");
                ranking.borrarFila(nombreAux);
            }
            
            else if (opcion == 6) {
                System.out.println("    Nombre usuario a actualizar (debe existir en el ranking: ");
                in = new Scanner(System.in);
                nombreAux = in.nextLine();
                System.out.println("\n");
                System.out.println("    Nueva puntuacion del usuario: ");
                in = new Scanner(System.in);
                puntAux = in.nextInt();
                fila = new Fila(puntAux, nombreAux);
                ranking.actualizarUsuario(fila);
            }
            else if(opcion == 7){
                System.out.println("Posicio del ranking: ");
                in = new Scanner(System.in);
                puntAux = in.nextInt();
                fila = ranking.getFilapos(puntAux);
                System.out.println("Nombre usuario: "+fila.getNombre()+" puntuacion"+fila.getPuntuacion()+"\n");
            }
            else if(opcion == 8){
                System.out.print("Ranking ordenado : \n");
                int n = ranking.getSize();
                for(int i = 1; i <= n; ++i){
                    fila = ranking.getFilapos(i);
                    System.out.println("Posicio "+i+"\n");
                    System.out.println("Nombre usuario: "+fila.getNombre()+" puntuacion"+fila.getPuntuacion()+"\n");
                }
            }
            else if(opcion == 9){
                System.out.print("Insertar nombre usuario");
                in = new Scanner(System.in);
                nombreAux = in.nextLine();
                if(ranking.existeUsuario(nombreAux)){
                    System.out.print("Existe");
                }
                else{
                    System.out.print("No Existe");
                }
            }
        }
    }
}
