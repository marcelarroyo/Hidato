/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tests;
import Dominio.Estructuras.TableroHidato;
import Dominio.Estructuras.CasillaHidato;
import java.util.Scanner;

/**
 *
 * @author raul.ibanez.perez
 * Colaboradores: Marcel Arroyo
 */

public class TestTableroHidato {
    
    private static int opcion = 0;
    private static TableroHidato tablero;
    private static CasillaHidato casilla;
    private static String nombreAux;
    private static int tamanoAux;
    private static int xAux;
    private static int yAux;
    private static String usabilidad;
    private static String prefijada;
    private static int valor;
    
    public static void main(String[] args) {
        
        while (opcion != 17) {
            System.out.println();
            System.out.println("    #######################################");
            System.out.println("    #         TEST TABLERO HIDATO         #");
            System.out.println("    #######################################");
            System.out.println("    #                                     #");
            System.out.println("    #    Escoje opcion:                   #");
            System.out.println("    #                                     #");
            System.out.println("    #    1) TableroHidato()               #");
            System.out.println("    #    2) TableroHidato(nombre, tamaño) #");
            System.out.println("    #    3) getUsabilidad(x, y)           #");
            System.out.println("    #    4) getNombreCreador()            #");
            System.out.println("    #    5) getCasilla(x, y)              #");
            System.out.println("    #    6) getValor(x, y)                #");
            System.out.println("    #    7) getPrefijada(x, y)            #");
            System.out.println("    #    8) getNombreTablero()            #");
            System.out.println("    #    9) setNombreCreador(nombre)      #");
            System.out.println("    #   10) setUsabilidad(boolean, x, y)  #");
            System.out.println("    #   11) setValor(valor, x, y)         #");
            System.out.println("    #   12) setPrefijada(x, y, boolean)   #");
            System.out.println("    #   13) setNombreTablero(nombre)      #");
            System.out.println("    #   14) dibujarTablero()              #");
            System.out.println("    #   15) copia(TableroHidato t)        #");
            System.out.println("    #   16) dar un tablero rapido (no existe)");
            System.out.println("    #                                     #");
            System.out.println("    #   17) Salir                         #");
            System.out.println("     #                                   # ");
            System.out.println("      ###################################  ");
            
            Scanner in = new Scanner(System.in);
            System.out.print("\n    Opción: ");
            opcion = in.nextInt();
            System.out.print("\n");
            
            if (opcion == 1) tablero = new TableroHidato();
            
            else if (opcion == 2) {
                System.out.print("    Nombre: ");
                in = new Scanner(System.in);
                nombreAux = in.nextLine();
                System.out.print("\n");
                System.out.print("    Tamaño: ");
                in = new Scanner(System.in);
                tamanoAux= in.nextInt();
                System.out.print("\n");
                tablero = new TableroHidato(nombreAux,tamanoAux);
            }
            
            else if (opcion == 3) {
                System.out.print("    posición x: ");
                in = new Scanner(System.in);
                xAux = in.nextInt();
                System.out.print("\n");
                System.out.print("    posición y: ");
                in = new Scanner(System.in);
                yAux = in.nextInt();
                System.out.print("\n");
                System.out.println("    "+Boolean.toString(tablero.getUsabilidad(xAux, yAux)));
            }
            
            else if (opcion == 4) tablero.getNombreCreador();
            
            else if (opcion == 5) {
                System.out.print("    posición x: ");
                in = new Scanner(System.in);
                xAux = in.nextInt();
                System.out.print("\n");
                System.out.print("    posición y: ");
                in = new Scanner(System.in);
                yAux = in.nextInt();
                System.out.print("\n");
                casilla = tablero.getCasilla(xAux, yAux);
                System.out.println("    Casilla con valor: "+casilla.getValor()+", con esPrefijada = "+String.valueOf(casilla.isPrefijada())+" y con esUsable = "+String.valueOf(casilla.esUsable()));
            }
            
            else if (opcion == 6) {
                System.out.print("    posición x: ");
                in = new Scanner(System.in);
                xAux = in.nextInt();
                System.out.print("\n");
                System.out.print("    posición y: ");
                in = new Scanner(System.in);
                yAux = in.nextInt();
                System.out.print("\n");
                System.out.println("    Valor: "+tablero.getValor(xAux, yAux));
            }
            
            else if (opcion == 7) {
                System.out.print("    posición x: ");
                in = new Scanner(System.in);
                xAux = in.nextInt();
                System.out.print("\n");
                System.out.print("    posición y: ");
                in = new Scanner(System.in);
                yAux = in.nextInt();
                System.out.print("\n");
                System.out.println("    Prefijada: "+String.valueOf(tablero.getPrefijada(xAux, yAux)));
            }
            
            else if (opcion == 8) System.out.println("    Nombre del Tablero: "+tablero.getNombreTablero());
            
            else if (opcion == 9) {
                System.out.print("    Nombre del creador: ");
                in = new Scanner(System.in);
                tablero.setNombreCreador(in.nextLine());
            }
            
            else if (opcion == 10) {
                System.out.print("    posición x: ");
                in = new Scanner(System.in);
                xAux = in.nextInt();
                System.out.print("\n");
                System.out.print("    posición y: ");
                in = new Scanner(System.in);
                yAux = in.nextInt();
                System.out.print("\n");
                System.out.println("    (Para simplificar solo puedes escribir 'true' o 'false')");
                System.out.print("    usabilidad: ");
                in = new Scanner(System.in);
                usabilidad = in.nextLine();
                System.out.print("\n");
                tablero.setUsabilidad(Boolean.getBoolean(usabilidad), xAux, yAux);
            }
            
            else if (opcion == 11) {
                System.out.print("    posición x: ");
                in = new Scanner(System.in);
                xAux = in.nextInt();
                System.out.print("\n");
                System.out.print("    posición y: ");
                in = new Scanner(System.in);
                yAux = in.nextInt();
                System.out.print("\n");
                System.out.print("    valor: ");
                in = new Scanner(System.in);
                valor = in.nextInt();
                System.out.print("\n");
                tablero.setValor(valor, xAux, yAux);
            }
            
            else if (opcion == 12){
                System.out.print("    posición x: ");
                in = new Scanner(System.in);
                xAux = in.nextInt();
                System.out.print("\n");
                System.out.print("    posición y: ");
                in = new Scanner(System.in);
                yAux = in.nextInt();
                System.out.print("\n");
                //tablero.setPrefijada(xAux, yAux);
            }
            
            else if (opcion == 13) {
                System.out.print("    Nombre: ");
                in = new Scanner(System.in);
                nombreAux = in.nextLine();
                System.out.print("\n");
                tablero.setNombreTablero(nombreAux);
            }
            
            else if (opcion == 14) tablero.dibujarTablero();
            else if (opcion == 15) {
                System.out.println("Introduce nombre del tablero y tamaño");
                Scanner sc = new Scanner(System.in);
                TableroHidato t = new TableroHidato(sc.next(), sc.nextInt());
                System.out.println("Introduce nombre del creador del tablero");
                t.setNombreCreador(sc.next());
                System.out.println("Introduce el numero de casillas prefijadas");
                int numPref = sc.nextInt();
                System.out.println("Introduce las casillas prefijadas (coordX, coordy, valor)");
                for (int k = 0; k < numPref; ++k) t.anadirMarcarPrefijada(sc.nextInt(), sc.nextInt(), sc.nextInt());
                System.out.println("Introduce el valor de las casillas del tablero hidato (valor = 0 -> casillausable i no prefijada"
                        + "valor = -1 -> casillaNoUsable valor > 0 -> casilla prefijada)");
                for (int i = 0; i < t.getTamano(); ++i) {
                    for (int j = 0; j < t.getTamano(); ++j) {
                        t.setValor(sc.nextInt(), i, j);
                    }
                }
                System.out.print("Nombre tablero: ");
                System.out.println(t.getNombreTablero());
                System.out.print("Nombre creador: ");
                System.out.println(t.getNombreCreador());
                System.out.print("Tamano tablero: ");
                System.out.println(t.getTamano());
                System.out.print("Casillas prefijadas: ");
                int [] claus = t.getKeys();
                for (int r = 0; r < t.PrefSize(); ++r) {
                    System.out.print("valor: ");
                    System.out.print(claus[r]);
                    System.out.print("   coordX: ");
                    System.out.print(t.getCoorXPref(claus[r]));
                    System.out.print("   coordY: ");
                    System.out.print(t.getCoorYPref(claus[r]));
                }
                System.out.println("");
                System.out.println("Candidatos: ");
                for (int w = 0; w < t.getTamano(); ++w) {
                    for (int x = 0; x < t.getTamano(); ++x) {
                        System.out.print("Candidatos casilla" + w + " " + x + ": ");
                        int [] cand = t.consultarCandidatosCasilla(w, x);
                        for (int q = 0; q < t.getNumCan(w, x); ++q) {
                            System.out.print(cand[q]);
                            System.out.print(" ");
                        }
                        System.out.println("");
                        System.out.print("Condiciones casilla ");
                        System.out.print(w);
                        System.out.print(" ");
                        System.out.println(x);
                        if(t.getPrefijada(w, x)) System.out.println("Es prefijada");
                        else System.out.println("No es prefijada");
                        if (t.getUsabilidad(w, x)) System.out.println("Es usable");
                        else System.out.println("No es usable");
                    }
                }
                System.out.println("");
                t.dibujarTablero();
                System.out.println("Creamos la copia del tablero hidato");
                TableroHidato tcopia = new TableroHidato();
                tcopia.copia(t);
                
                //Consultamos valores de tablerocopia
                
                System.out.print("Nombre tablero: ");
                System.out.println(tcopia.getNombreTablero());
                System.out.print("Nombre creador: ");
                System.out.println(tcopia.getNombreCreador());
                System.out.print("Tamano tablero: ");
                System.out.println(tcopia.getTamano());
                System.out.print("Casillas prefijadas: ");
                int [] claus1 = tcopia.getKeys();
                for (int r = 0; r < tcopia.PrefSize(); ++r) {
                    System.out.print("valor: ");
                    System.out.print(claus1[r]);
                    System.out.print("   coordX: ");
                    System.out.print(tcopia.getCoorXPref(claus1[r]));
                    System.out.print("   coordY: ");
                    System.out.print(tcopia.getCoorYPref(claus1[r]));
                }
                System.out.println("");
                System.out.println("Candidatos: ");
                for (int w = 0; w < tcopia.getTamano(); ++w) {
                    for (int x = 0; x < tcopia.getTamano(); ++x) {
                        System.out.print("Candidatos casilla" + w + " " + x + ": ");
                        int [] cand = tcopia.consultarCandidatosCasilla(w, x);
                        for (int q = 0; q < tcopia.getNumCan(w, x); ++q) {
                            System.out.print(cand[q]);
                            System.out.print(" ");
                        }
                        System.out.println("");
                        System.out.print("Condiciones casilla ");
                        System.out.print(w);
                        System.out.print(" ");
                        System.out.println(x);
                        if(t.getPrefijada(w, x)) System.out.println("Es prefijada");
                        else System.out.println("No es prefijada");
                        if (t.getUsabilidad(w, x)) System.out.println("Es usable");
                        else System.out.println("No es usable");
                    }
                }
                System.out.println("Empezamos a modificar el tablero copia");
                System.out.println("Introduce el nuevo nombre del tablero copia");
                tcopia.setNombreTablero(sc.next());
                System.out.println("Introduce el nuevo nombre del creador del tablero copia");
                tcopia.setNombreCreador(sc.next());
                System.out.println ("Introduce la casilla prefijada que se desea anadir(esa casilla ha de ser usable) ---> x, y, valor");
                tcopia.anadirMarcarPrefijada(sc.nextInt(), sc.nextInt(), sc.nextInt());
                System.out.println("Introduce la casilla prefijada que se desea borrar (esa casilla ha de ser prefijada) ---> valor");
                tcopia.borrarDesmarcarPref(sc.nextInt());
                System.out.println("Borro candidato de la casilla x y valor");
                tcopia.eliminarCandidatoCasilla(sc.nextInt(), sc.nextInt(), sc.nextInt());
                System.out.println("Dibujo tablero original");
                
                //Dibujo tablero original
                
                 System.out.print("Nombre tablero: ");
                System.out.println(t.getNombreTablero());
                System.out.print("Nombre creador: ");
                System.out.println(t.getNombreCreador());
                System.out.print("Tamano tablero: ");
                System.out.println(t.getTamano());
                System.out.print("Casillas prefijadas: ");
                claus = t.getKeys();
                for (int r = 0; r < t.PrefSize(); ++r) {
                    System.out.print("valor: ");
                    System.out.print(claus[r]);
                    System.out.print("   coordX: ");
                    System.out.print(t.getCoorXPref(claus[r]));
                    System.out.print("   coordY: ");
                    System.out.print(t.getCoorYPref(claus[r]));
                }
                System.out.println("");
                System.out.println("Candidatos: ");
                for (int w = 0; w < t.getTamano(); ++w) {
                    for (int x = 0; x < t.getTamano(); ++x) {
                        System.out.print("Candidatos casilla" + w + " " + x + ": ");
                        int [] cand = t.consultarCandidatosCasilla(w, x);
                        for (int q = 0; q < t.getNumCan(w, x); ++q) {
                            System.out.print(cand[q]);
                            System.out.print(" ");
                        }
                        System.out.println("");
                        System.out.print("Condiciones casilla ");
                        System.out.print(w);
                        System.out.print(" ");
                        System.out.println(x);
                        if(t.getPrefijada(w, x)) System.out.println("Es prefijada");
                        else System.out.println("No es prefijada");
                        if (t.getUsabilidad(w, x)) System.out.println("Es usable");
                        else System.out.println("No es usable");
                    }
                }
                t.dibujarTablero();
                
                
                
                
                
                
                
                
                //Dibujo tablero copia
                System.out.print("Nombre tablero: ");
                System.out.println(tcopia.getNombreTablero());
                System.out.print("Nombre creador: ");
                System.out.println(tcopia.getNombreCreador());
                System.out.print("Tamano tablero: ");
                System.out.println(tcopia.getTamano());
                System.out.print("Casillas prefijadas: ");
                claus1 = tcopia.getKeys();
                for (int r = 0; r < tcopia.PrefSize(); ++r) {
                    System.out.print("valor: ");
                    System.out.print(claus1[r]);
                    System.out.print("   coordX: ");
                    System.out.print(tcopia.getCoorXPref(claus1[r]));
                    System.out.print("   coordY: ");
                    System.out.print(tcopia.getCoorYPref(claus1[r]));
                }
                System.out.println("");
                System.out.println("Candidatos: ");
                for (int w = 0; w < tcopia.getTamano(); ++w) {
                    for (int x = 0; x < tcopia.getTamano(); ++x) {
                        System.out.print("Candidatos casilla" + w + " " + x + ": ");
                        int [] cand = tcopia.consultarCandidatosCasilla(w, x);
                        for (int q = 0; q < tcopia.getNumCan(w, x); ++q) {
                            System.out.print(cand[q]);
                            System.out.print(" ");
                        }
                        System.out.println("");
                        System.out.print("Condiciones casilla ");
                        System.out.print(w);
                        System.out.print(" ");
                        System.out.println(x);
                        if(tcopia.getPrefijada(w, x)) System.out.println("Es prefijada");
                        else System.out.println("No es prefijada");
                        if (tcopia.getUsabilidad(w, x)) System.out.println("Es usable");
                        else System.out.println("No es usable");
                    }
                }
                tcopia.dibujarTablero();
            
            }
            else if (opcion == 16) {
                System.out.println("    ###################################");
                System.out.println("    #              INDICE             #");
                System.out.println("    ###################################");
                System.out.println("    # > -1 = Casilla no usable        #");
                System.out.println("    # >  0 = CASILLA USABLE           #");
                System.out.println("    # >  OTRO VALOR = Valor (fijo)    #");
                System.out.println("    ###################################");
                
                int casillaLeida;
                
                for (int i = 0; i < tablero.getTamano(); ++i){
                    for (int j = 0; j < tablero.getTamano(); ++j) {
                        System.out.print("\n    > Valor de la casilla ["+i+"]["+j+"]: ");
                        casillaLeida = in.nextInt();
                        if (casillaLeida != 0) tablero.setValor(casillaLeida, i, j);
                    }
                }
            }
        }
    }
}
