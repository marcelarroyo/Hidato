/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tests;
/**
 *
 * @author Hamid Latif
 */

import Dominio.Estructuras.CasillaHidato;
import Dominio.Algoritmos2;
import Dominio.Estructuras.Pair;
import Dominio.Estructuras.TableroHidato;
import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;
import java.util.Vector;
public class GeneradorInfinitosHidatos {
    
    private static int opcion = 2;
    private static Algoritmos2 a = new Algoritmos2();
    private static int nT = 1;
    
    public static void main(String[] args) {
        while (opcion != 3) {
            try {
                if (opcion == 2) {
                    
                    Random rn = new Random();
                    
                    int tamanoAux = rn.nextInt(4) + 2;
                    
                    TableroHidato t = new TableroHidato("test",tamanoAux);
                    t = a.generadorTableroRandomRecursivo(t);
                    System.out.println("tablero: "+nT);
                    ++nT;
                }
            }
            catch (InputMismatchException e) {
                System.out.println("@ Has introducido un valor inválido @");
            }
        }
    }
    
    private static void dibujarSolucionDelTablero(int[][] sol, int t) {
        System.out.print("\n");
        for (int i = 0; i < t; ++i) {
            System.out.print("    ");
            for (int j = 0; j < t; ++j) {
                int auxMaxCol = maxDecCol(j, sol);
                int auxCalcul = calculEspais(sol[i][j],auxMaxCol);
                if (sol[i][j] > 0) System.out.print(sol[i][j]);
                else System.out.print("X");
                for (int e = 0; e < auxCalcul;++e){
                    System.out.print(" ");
                }
            }
            System.out.print("\n");
        }
    }
    
    private static int calculEspais (int i, int max){
        int aux = 0;
        if (i < 10) aux = 1;
        else if (i < 100) aux = 2;
        else aux = 3;
        //System.out.println("i = "+i+" max = "+max+" aux = "+aux);
        return (2 + (max - aux));
    }
    
    private static int maxDecCol (int i, int[][] sol) {
        int max = 1;
        int auxTamano = sol.length;
        for (int j = 0; j < auxTamano; ++j) {
            if (sol[j][i] > 9 && sol[j][i] < 99 && max < 2) max = 2;
            else if (sol[j][i] > 99) max = 3;
        }
        return max;
    }
    
}
