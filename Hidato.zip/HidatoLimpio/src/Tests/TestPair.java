/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tests;

import Dominio.Estructuras.Pair;
import java.util.Scanner;

/**
 *
 * @author Marc Barrio Ruiz
 */
public class TestPair {
    private static int opcion = 0;
    private static Pair pair;
    private static int intAux;
    private static int intAux2;
    
    public static void main(String[] args) {
        System.out.println();
        while (opcion != 7) {
            System.out.println("    ########################################");
            System.out.println("    #          TEST Pair                   #");
            System.out.println("    ########################################");
            System.out.println("    #                                      #");
            System.out.println("    #    Escoje opcion:                    #");
            System.out.println("    #                                      #");
            System.out.println("    #    1) Pair()                         #");
            System.out.println("    #    2) Pair(first, second)            #");
            System.out.println("    #    3) getFirst()                     #");
            System.out.println("    #    4) getSecond()                    #");
            System.out.println("    #    5) setFirst()                     #");
            System.out.println("    #    6) setSecond()                    #");           
            System.out.println("    #    7) Salir                          #");
            System.out.println("     #                                    # ");
            System.out.println("      ####################################  ");
            
            Scanner in = new Scanner(System.in);
            System.out.print("\n    Opción: ");
            opcion = in.nextInt();
            System.out.print("\n");
            
            if (opcion == 1) {
                pair = new Pair();
            }
            
            else if (opcion == 2) {
                System.out.println("    Primer elemento pair: ");
                in = new Scanner(System.in);
                intAux = in.nextInt();
                System.out.println("\n");
                System.out.println("    Segundo elemento pair: ");
                in = new Scanner(System.in);
                intAux2 = in.nextInt();
                System.out.println("\n");
                pair = new Pair(intAux, intAux2);
            }
            
            else if (opcion == 3) {
                System.out.println("    Primer elemento del pair: "+pair.getFirst()+"\n");
            }
            
            else if (opcion == 4) {
                System.out.println("    Segundo elemento del pair: "+pair.getSecond()+"\n");
            }
            
            else if (opcion == 5) {
                System.out.println("    Primer elemento del pair: ");
                in = new Scanner(System.in);
                intAux = in.nextInt();
                pair.setFirst(intAux);
                System.out.println("\n");
            }
            
            else if (opcion == 6) {
                System.out.println("    Segundo elemento del pair: ");
                in = new Scanner(System.in);
                intAux = in.nextInt();
                pair.setSecond(intAux);
                System.out.println("\n");
            }
        }
    }
}
