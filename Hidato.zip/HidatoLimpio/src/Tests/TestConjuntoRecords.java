/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tests;
import java.util.*;
import Dominio.Estructuras.ConjuntoRecords;
import Dominio.Estructuras.PairRecord;
import Dominio.Estructuras.RecordTablero;


/**
 *
 * @author Marcel
 */
public class TestConjuntoRecords {
    private static int opcion = 0;
    private static  ConjuntoRecords records;
    
    public static void main(String[] args) {
        while (opcion != 14) {
            System.out.println("    #################################################################");
            System.out.println("    #                       TEST RECORD TABLERO                     #");
            System.out.println("    #################################################################");
            System.out.println("    #                                                               #");
            System.out.println("    #    Escoje opcion:                                             #");
            System.out.println("    #    1) ConjuntoRecords()                                       #");
            System.out.println("    #    2) existeTablero(String s)                                 #");
            System.out.println("    #    3) isEmpty()                                               #");
            System.out.println("    #    4) getTamano()                                             #");
            System.out.println("    #    5) consultarRecordTimeTablero(String s)                    #");
            System.out.println("    #    6) consultarRecordFirstPlayerTablero(String s)             #");
            System.out.println("    #    7) consultarRecordMaxPuntuacionTablero(String s)           #");
            System.out.println("    #    8) consultarTodosRecordsTablero (String s)                 #");
            System.out.println("    #    9) anadirTablero(String s)                                 #");
            System.out.println("    #    10)setRecordTimeTablero(String s, String id, int punt)     #");
            System.out.println("    #    11)setRecordFirstPlayerTablero(String s, String id)        #");
            System.out.println("    #    12)setRecordMaxPuntTablero(String s, String id, int punt)  #");
            System.out.println("    #    13)eliminarTablero                                         #");
            System.out.println("    #                                                               #");
            System.out.println("    #    14) Salir                                                  #");
            System.out.println("    #                                                               #");
            System.out.println("    #################################################################");
    
            Scanner in = new Scanner(System.in);
            System.out.print("\n    Opción: ");
            opcion = in.nextInt();
            System.out.print("\n");
            
            
            if (opcion == 1) {
                System.out.println("Creamos un ConjuntoRecords vacio");
                records = new ConjuntoRecords();
            }
            
            else if (opcion == 2) {
                System.out.println("Introduce el tablero a consultar: (nombretablero)");
                if (records.existeTablero(in.next())) System.out.println("Existe el tablero");
                else System.out.println("No existe el tablero");
            }
            
            else if (opcion == 3) {
                if(records.isEmpty()) System.out.println("No existe ningun tablero");
                else System.out.println("Existe algun tablero");
            }
            
            else if (opcion == 4) {
                System.out.println("Tamano del hashmap: " + records.getTamano());
            }
            else if (opcion == 5) {
                System.out.println("Introduce el tablero del qual quieres consultar el record: (nombretablero)");
                PairRecord r = new PairRecord();
                r = records.consultarRecordTimeTablero(in.next());
                System.out.println("IdJugador: " + r.getIdJugador() + " Puntuacion: " + r.getPuntuacion());
            }
            else if (opcion == 6) {
                System.out.println("Introduce el tablero del qual quieres consultar el record: (nombretablero)");
                PairRecord r = new PairRecord();
                r = records.consultarRecordFirstPlayerTablero(in.next());
                System.out.println("IdJugador: " + r.getIdJugador());
            }
            else if (opcion == 7) {
                System.out.println("Introduce el tablero del qual quieres consultar el record: (nombretablero)");
                PairRecord r = new PairRecord();
                r = records.consultarRecordFirstPlayerTablero(in.next());
                System.out.println("IdJugador: " + r.getIdJugador() + " Puntuacion: " + r.getPuntuacion());
            }
            else if (opcion == 8) {
                System.out.println("Introduce el tablero del qual quieres consultar el record: (nombreTablero)");
                RecordTablero r = records.consultarTodosRecordsTablero(in.next());
                PairRecord [] rec = r.getAllRecords();
                for(int i = 0; i < 3; ++i) {
                    if (i != 1)System.out.println("IdJugador: " + rec[i].getIdJugador() 
                        + " Puntuacion: " + rec[i].getPuntuacion());
                    else System.out.println("IdJugador: " + rec[i].getIdJugador());
                }
            }
            else if (opcion == 9) {
                System.out.println("Introduce el tablero que quieres anadir al hashset: (nombreTablero)");
                records.anadirTablero(in.next());
            }
            else if (opcion == 10) {
                System.out.println("Introduce el tablero sobre el cual quieres actualizar los datos del record: (nombreTablero, jugador, tiempo)");
                records.setRecordTimeTablero(in.next(), in.next(), in.nextInt());
            }
            else if (opcion == 11) {
                System.out.println("Introduce el tablero sobre el cual quieres actualizar los datos del record: (nombreTablero, jugador)");
                records.setRecordFirstPlayerTablero(in.next(), in.next());
            }
            else if (opcion == 12) {
                System.out.println("Introduce el tablero sobre el cual quieres actualizar los datos del record: (nombreTablero, jugador, puntuacion)");
                records.setRecordMaxPuntTablero(in.next(), in.next(), in.nextInt());
            }
            else if (opcion == 13) {
            System.out.println("Introduce el tablero que quieres eliminar: (nombreTablero)");
                records.eliminarTablero(in.next());
            }
        }
    }
}
