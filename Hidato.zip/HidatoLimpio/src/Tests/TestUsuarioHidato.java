/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tests;
import Dominio.Estructuras.UsuarioHidato;
import java.util.Scanner;

/**
 *
 * @author raul.ibanez.perez
 */

public class TestUsuarioHidato {
    
    private static int opcion = 0;
    private static UsuarioHidato user;
    private static String nombreAux;
    private static String contrasenaAux;
    
    public static void main(String[] args) {
        System.out.println();
        while (opcion != 5) {
            System.out.println("    ##########################################");
            System.out.println("    #           TEST USUARIO HIDATO          #");
            System.out.println("    ##########################################");
            System.out.println("    #                                        #");
            System.out.println("    #    Escoje opcion:                      #");
            System.out.println("    #                                        #");
            System.out.println("    #    1) UsuarioHidato()                  #");
            System.out.println("    #    2) UsuarioHidato(nombre,contraseña) #");
            System.out.println("    #    3) getPuntuacionTotal()             #");
            System.out.println("    #    4) setPuntuacionTotal(puntuacion)   #");
            System.out.println("    #                                        #");
            System.out.println("    #    5) Salir                            #");
            System.out.println("     #                                      # ");
            System.out.println("      ######################################  ");
            
            Scanner in = new Scanner(System.in);
            System.out.print("\n    Opción: ");
            opcion = in.nextInt();
            System.out.print("\n");
            
            if (opcion == 1) user = new UsuarioHidato();
            
            else if (opcion == 2) {
                System.out.print("    Nombre: ");
                in = new Scanner(System.in);
                nombreAux = in.nextLine();
                System.out.print("\n");
                System.out.print("    Contraseña: ");
                in = new Scanner(System.in);
                contrasenaAux = in.nextLine();
                System.out.print("\n");
                user = new UsuarioHidato(nombreAux,contrasenaAux);
            }
            
            else if (opcion == 3) System.out.println("    PuntuaciónTotal: "
                    +user.getPuntuacionTotal()+"\n");
            
            else if (opcion == 4) {
                System.out.print("    Nueva Puntuación Total: ");
                in = new Scanner(System.in);
                user.setPuntuacionTotal(in.nextInt());
                System.out.print("\n");
            }
        }
    }
}

