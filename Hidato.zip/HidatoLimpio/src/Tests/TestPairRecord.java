/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tests;

import Dominio.Estructuras.PairRecord;
import java.util.Scanner;

/**
 *
 * @author marc.barrio
 */
public class TestPairRecord {
    private static int opcion = 0;
    private static PairRecord pair;
    private static String stringAux;
    private static int intAux;
    private static int intAux2;
    
    public static void main(String[] args) {
        System.out.println();
        while (opcion != 8) {
            System.out.println("    ##############################################");
            System.out.println("    #          TEST Pair                         #");
            System.out.println("    ##############################################");
            System.out.println("    #                                            #");
            System.out.println("    #    Escoje opcion:                          #");
            System.out.println("    #                                            #");
            System.out.println("    #    1) PairRecord()                         #");
            System.out.println("    #    2) PairRecord(idjugador, puntuacion)    #");
            System.out.println("    #    3) getIdJugador()                       #");
            System.out.println("    #    4) getPuntuacion()                      #");
            System.out.println("    #    5) exists()                             #");
            System.out.println("    #    6) setIdJugador(IdJugador)              #"); 
            System.out.println("    #    7) setPuntuacion(puntuacion)            #");
            System.out.println("    #    8) Salir                                #");
            System.out.println("     #                                          # ");
            System.out.println("      ##########################################  ");
            
            Scanner in = new Scanner(System.in);
            System.out.print("\n    Opción: ");
            opcion = in.nextInt();
            System.out.print("\n");
            
            if (opcion == 1) {
                pair = new PairRecord();
            }
            
            else if (opcion == 2) {
                System.out.println("    Id del jugador: ");
                in = new Scanner(System.in);
                stringAux = in.nextLine();
                System.out.println("\n");
                System.out.println("    Puntuacion: ");
                in = new Scanner(System.in);
                intAux = in.nextInt();
                System.out.println("\n");
                pair = new PairRecord(stringAux, intAux);
            }
            
            else if (opcion == 3) {
                System.out.println("    Id del jugador: "+pair.getIdJugador()+"\n");
            }
            
            else if (opcion == 4) {
                System.out.println("    Puntuacion del jugador: "+pair.getPuntuacion()+"\n");
            }
            
            else if (opcion == 5) {
                if(pair.exists()){
                    System.out.println("    Existe. \n");
                }
                else{
                    System.out.println("    No existe. \n");
                }
            }
            
            else if (opcion == 6) {
                System.out.println("    Id del jugador: ");
                in = new Scanner(System.in);
                stringAux = in.nextLine();
                pair.setIdJugador(stringAux);
                System.out.println("\n");
            }
            else if (opcion == 7){
                System.out.println("    Puntuacion del jugador: ");
                in = new Scanner(System.in);
                intAux = in.nextInt();
                pair.setPuntuacion(intAux);
                System.out.println("\n");
            }
        }
    }
    
}
