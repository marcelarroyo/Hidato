/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tests;
import Dominio.Estructuras.PairRecord;
import Dominio.Estructuras.RecordTablero;
import java.util.Scanner;

/**
 *
 * @author Marcel
 */
public class TestRecordTablero {
    private static int opcion = 0;
    private static  RecordTablero record;
    
    public static void main(String[] args) {
        while (opcion != 12) {
            System.out.println("    ################################################");
            System.out.println("    #              TEST RECORD TABLERO             #");
            System.out.println("    ################################################");
            System.out.println("    #                                              #");
            System.out.println("    #    Escoje opcion:                            #");
            System.out.println("    #    1) RecordTablero()                        #");
            System.out.println("    #    2) existRecordTime()                      #");
            System.out.println("    #    3) existRecordFirstPlayer()               #");
            System.out.println("    #    4) existRecordPoints()                    #");
            System.out.println("    #    5) getRecordTiempo()                      #");
            System.out.println("    #    6) getRecordFirstPlayer()                 #");
            System.out.println("    #    7) getRecordPuntuacion()                  #");
            System.out.println("    #    8) getAllRecords ()                       #");
            System.out.println("    #    9) setRecordTiempo(String id, int t)      #");
            System.out.println("    #    10)setRecordJugador(String id)            #");
            System.out.println("    #    11)setRecordPuntuacion(String id, int t)  #");
            System.out.println("    #                                              #");
            System.out.println("    #    12) Salir                                 #");
            System.out.println("    #                                              #");
            System.out.println("    ################################################");
    
            Scanner in = new Scanner(System.in);
            System.out.print("\n    Opción: ");
            opcion = in.nextInt();
            System.out.print("\n");
            
            
            if (opcion == 1) {
                record = new RecordTablero();
                System.out.println("Creamos un recordTablero vacio");
            }
            else if (opcion == 2) {
                if (record.existRecordTime()) System.out.println("Existe recordTime");
                else System.out.println("No existe recordTime");
            }
            else if (opcion == 3) {
                if (record.existRecordFirstPlayer()) System.out.println("Existe recordFirstPlayer");
                else System.out.println("No existe recordFirstPlayer");
            }
            else if (opcion == 4) {
                if (record.existRecordTime()) System.out.println("Existe recordTime");
                else System.out.println("No existe recordTime");
            }
            else if (opcion == 5) {
                PairRecord r = new PairRecord();
                r = record.getRecordTiempo();
                System.out.println("IdJugador: " + r.getIdJugador() + " Puntuacion: " + r.getPuntuacion());
            }
            else if (opcion == 6) {
                PairRecord r = new PairRecord();
                r = record.getRecordFirstPlayer();
                System.out.println("IdJugador: " + r.getIdJugador());
            }
            else if (opcion == 7) {
                PairRecord r = new PairRecord();
                r = record.getRecordPuntuacion();
                System.out.println("IdJugador: " + r.getIdJugador() + " Puntuacion: " + r.getPuntuacion());
            }
            else if (opcion == 8) {
                PairRecord[] r = record.getAllRecords();
                for(int i = 0; i < 3; ++i) {
                    if (i != 1)System.out.println("IdJugador: " + r[i].getIdJugador() 
                        + " Puntuacion: " + r[i].getPuntuacion());
                    else System.out.println("IdJugador: " + r[i].getIdJugador());
                }
            }
            else if (opcion == 9) {
                System.out.println("Introduce el recordTiempo: (idJugador, tiempo)");
                record.setRecordTiempo(in.next(), in.nextInt());
            }
            else if (opcion == 10) {
                System.out.println("Introduce el recordFirstPlayer: (idJugador)");
                record.setRecordJugador(in.next());
            }
            else if (opcion == 11) {
                System.out.println("Introduce el recordMaxPuntuacion: (idJugador, puntuacion)");
                record.setRecordPuntuacion(in.next(),in.nextInt());
            }
        }    
    }
}

