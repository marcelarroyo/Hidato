/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tests;

import Compartidas.Fila;
import java.util.Date;
import java.util.Scanner;

/**
 *
 * @author Marc Barrio Ruiz
 */
public class TestFila {
    private static int opcion = 0;
    private static Fila fila;
    private static String nombreAux;
    private static int puntAux;
    
    public static void main(String[] args) {
        System.out.println();
        while (opcion != 10) {
            System.out.println("    ########################################");
            System.out.println("    #          TEST Fila                   #");
            System.out.println("    ########################################");
            System.out.println("    #                                      #");
            System.out.println("    #    Escoje opcion:                    #");
            System.out.println("    #                                      #");
            System.out.println("    #    1) Fila()                         #");
            System.out.println("    #    2) Fila(puntuacion,usuario)       #");
            System.out.println("    #    3) getPuntuacion()                #");
            System.out.println("    #    4) getNombre()                    #");
            System.out.println("    #    5) getFecha()                     #");
            System.out.println("    #    6) setPuntuacion(puntuacion)      #");
            System.out.println("    #    7) addPuntuacion(puntuacion)      #");
            System.out.println("    #    8) setNombre(nombre)              #");
            System.out.println("    #    9) setFecha(fecha)                #");
            System.out.println("    #   10) Salir                          #");
            System.out.println("     #                                    # ");
            System.out.println("      ####################################  ");
            
            Scanner in = new Scanner(System.in);
            System.out.print("\n    Opción: ");
            opcion = in.nextInt();
            System.out.print("\n");
            
            if (opcion == 1) {
                fila = new Fila();
            }
            
            else if (opcion == 2) {
                System.out.print("  puntuacion: ");
                in = new Scanner(System.in);
                puntAux = in.nextInt();
                System.out.print("\n");
                System.out.print("  NombreUsuario: ");
                in = new Scanner(System.in);
                nombreAux = in.nextLine();
                System.out.print("\n");
                fila = new Fila(puntAux, nombreAux);
            }
            
            else if (opcion == 3) {
                System.out.println("    Puntuacion: "+fila.getPuntuacion()+"\n");
            }
            
            else if (opcion == 4) {
                System.out.println("    Nombre: "+fila.getNombre()+"\n");
            }
            
            else if (opcion == 5) {
                System.out.println("    Fecha: "+fila.getFecha().toString()+"\n");
            }
            
            else if (opcion == 6) {
                System.out.print("  Puntuacion: ");
                in = new Scanner(System.in);
                puntAux = in.nextInt();
                System.out.print("\n");
                fila.setPuntuacion(puntAux);
            }
                        
            else if (opcion == 7) {
                System.out.print("  Puntuacion: ");
                in = new Scanner(System.in);
                puntAux = in.nextInt();
                System.out.print("\n");
                fila.addPuntuacion(puntAux);
            }
            
            else if (opcion == 8) {
                System.out.print("  Nombre: ");
                in = new Scanner(System.in);
                nombreAux = in.nextLine();
                fila.setNombre(nombreAux);
                
            }
            
            else if (opcion == 9) {
                fila.setFecha(new Date());
            }
            
        }
    }
}
