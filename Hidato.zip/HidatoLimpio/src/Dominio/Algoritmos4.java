/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dominio;
import Dominio.Estructuras.TableroHidato;
import Dominio.Estructuras.Pair;
import static java.util.Arrays.sort;
import java.util.*;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Queue;

/**
 *
 * @author Hamid Latif
 * Colaborador: Marcel Arroyo Pinar
 * Colaborador: RaÃºl IbÃ¡Ã±ez
 */

public class Algoritmos4 {
    
    private static int casillaMin,casillaMax,numNoUsables, tamano;
    private static final TableroHidato tableroOriginal = new TableroHidato();
    private static TableroHidato tableroSolucionado;
    private int mapaAux[][];
    private static boolean BFS;
    private static int nIt = 0;
    
    /*  PRE: El tablero es correcto y tiene solución
        POST: Se calcula la solución del tablero en función del número de casillas usables 
            y del número de casillas prefijadas
    */
    public void calcularDificultad(TableroHidato t) {
        double casillasTotales = t.getTamanoReal();
        double prefijadas = t.PrefSize();
        double porcentaje = prefijadas/casillasTotales;
        if (t.getTamanoReal() < 37) { //posible tamaño fácil
            if (porcentaje > (double) 1/3) { //bastantes casillas prefijadas, ver su posición
                if (posicionDificultad(t.getKeys())) {
                    t.setDificultad(2);
                }
                else {
                    t.setDificultad(1);
                }
            }
            else {
                t.setDificultad(2);
            } //pocas casillas prefijadas -> aumenta dificultad
        }
        else if (t.getTamanoReal() < 65) { //posible tamaño medio
            if (porcentaje > (double) 1/3) {
                t.setDificultad(2);
            }
            else {
                t.setDificultad(3);
            } //pocas casillas prefijadas -> aumenta dificultad
        }
        else { //posible tamaño difícil
            if (porcentaje < (double) 1/3) {
                t.setDificultad(3);
            }
            else if (porcentaje > (double) 1/2) {
                t.setDificultad(2);
            }
        } 
    }
    
    /*  PRE: -
        POST: Comprueba si la posición de las casillas afecta a la dificultad. Si más de la mitad de las 
            casillas son consecutivas, no nos aportarán información, y afectarán a la dificultad (haciendo
            que tener muchas prefijadas no la disminuya)
    */
    private boolean posicionDificultad(int[] prefijadas) {
        int contador = 0;
        for (int i = 1; i < prefijadas.length; ++i) {
            if (prefijadas[i] == prefijadas[i-1]+1) ++contador;
        }
        double porcentaje = contador/prefijadas.length;
        return (porcentaje > (double) 1/2);
    }
    
    
    public void generarSinRestricciones() {
        Random rn = new Random();
        int n = rn.nextInt(7);
        ++n;
        int mapa[][] = new int[n][n];
        int i, j;
        i = rn.nextInt(10);
        i %= n;
        j = rn.nextInt(10);
        j %= n;
        System.out.println("Valor de n: " + n);
        System.out.println("Valores de i y j: " + i + " " + j);
        CaminoHamiltoniano(mapa, i, j, 1, mapa.length*mapa.length);
    }
    
    private boolean CaminoHamiltoniano(int[][] mapa, int i, int j, int contador, int tamanoMax) {
        Random rn = new Random();
        if (tamanoMax == contador) {
            mapa[i][j] = contador;
            for (int ii = 0; ii < mapa.length; ++ii) {
                for (int jj = 0; jj < mapa.length; ++jj) {
                    System.out.printf(mapa[ii][jj] + "  ");
                }
            System.out.println();
            }
            return true;
        }
        
        ArrayList<Pair> adys = adyacencias(mapa, i, j);
        mapa[i][j] = contador;
        while (!adys.isEmpty()) {
            int index = rn.nextInt(adys.size());
            Pair p = new Pair();
            p = adys.get(index);
            adys.remove(index);
            if (CaminoHamiltoniano(mapa, p.getFirst(), p.getSecond(), contador+1, tamanoMax)) return true;
        }
        mapa[i][j] = 0;
        return false;
    }
    
    private ArrayList<Pair> adyacencias(int[][] mapa, int i, int j) {
        ArrayList<Pair> a = new ArrayList();
        for (int ii = -1; ii < 2; ++ii) {
            for (int jj = -1; jj < 2; ++jj) {
                if (ii != 0 || jj != 0) { //cogemos todas menos la actual
                    if (i + ii >= 0 && i + ii < mapa.length) {
                        if (j + jj >= 0 && j + jj < mapa.length && mapa[i+ii][j+jj] == 0) {
                            Pair p = new Pair();
                            p.setFirst(i+ii);
                            p.setSecond(j+jj);
                            a.add(p);
                        }
                    }
                }
            }
        }
        return a;
    }
    
    
    public boolean resolver(TableroHidato t, boolean solucionBfs) {
        BFS = solucionBfs;
        //System.out.println(" # Iniciamos resolver #");
        
        tableroOriginal.copia(t);
        
        //System.out.println(" # Miro que el tablero sea valido #");
        
        if (this.validarTablero(t) == false) {
            //System.out.println(" # El tablero no es valido #");
            return false;
        }
        
        //System.out.println(" # El tablero si es valido #");
        
        // Empieza la resolucion.
        
        int[] llaves = t.getKeys();
        sort(llaves);
        
        if (solucionBfs == false) {
            //System.out.println(" # No se ha entrado en el solucionador por BFS #");
            return false;
        }
        
        else {
            //System.out.println(" # Se ha entrado en el solucionador por BFS #");
            calcularMapaAux(t);
            for (int i = 0; i < llaves.length; ++i) {
                Pair casilla = new Pair();
                casilla.setFirst(t.getCoorXPref(llaves[i]));
                casilla.setSecond(t.getCoorYPref(llaves[i]));
                //System.out.println("Entro en calcular candidatos bfs antes del backtracking");
                
                calcularCandidatosBFS(t, casilla, i, llaves);
                // Aqui ya tengo todos los candidatos;
                boolean b =  backtrack(t);
                if (b == true) {
                    return true;
                }
                else {
                    t.copia(tableroOriginal);
                    return false;
                }
            }
        }
        return false;
    }
    
    private void calcularCandidatosBFS(TableroHidato tAux, Pair cas, int posicion, int[] llaves) {
        
        for (int i = 0; i < tamano; ++i) {
            for (int j = 0; j < tamano; ++j) {
                tAux.getCasilla(i, j).setCan(1);
                tAux.getCasilla(i,j).delCan(1);
            }
        }
        
        for(int i = 0; i < (llaves.length - 1); ++i) {
            calcularCandidatosPalante(llaves[i],llaves[i+1],tAux);
            calcularCandidatosPatras(llaves[i+1],llaves[i],tAux);
        }
        HashSet<Integer> auxSetCandidatos = new HashSet<>();
        for (int i = 1; i <= casillaMax; ++i) {
            auxSetCandidatos.add(i);
        }
        
        for (int i = 0; i < tamano; ++i) {
            for (int j = 0; j < tamano; ++j) {
                if (tAux.getValor(i, j) != 0) {
                    tAux.getCasilla(i,j).delCan(1);
                    tAux.getCasilla(i, j).setCandidatos(auxSetCandidatos);
                }
            }
        }
        //dibujarCandidatos(tAux);
    }
    
    private void calcularCandidatosPalante (int x, int x2, TableroHidato t) {
        
        int distMax = x2 - (x + 1);
        int dists[][] = new int[tamano][tamano];
        
        distanciaCasillas(x,distMax,t,dists);
        
        for (int i = 0; i < tamano; ++i) {
            for (int j = 0; j < tamano; ++j) {
                
                if (dists[i][j] == 0) {
                    // Si no llego le quito los candidatos que no puede tener
                    // segun estas distancias.
                    for (int e = x+1; e < x2; ++e) t.getCasilla(i,j).delCan(e);
                    
                }
                
                if (dists[i][j] > 0) {
                    // Si llego le pongo los candidatos que puede tener
                    // segun las distancias
                    for (int k = dists[i][j]; k < x2-x; ++k) {
                        
                        HashSet<Integer> sAux = new HashSet<>();
                        Iterator<Integer> itAux = t.getCasilla(i,j).getCandidatos().iterator();
                        for (int aux = 0; aux < t.getCasilla(i,j).getNumCan();++aux) sAux.add(itAux.next());
                        sAux.add(x+k);
                        t.getCasilla(i, j).setCandidatos(sAux);
                        
                    }
                }
            }
        }
    }
    
    private void distanciaCasillas(int n, int d, TableroHidato t, int dists[][]) {
        
        Pair posInit = new Pair();
        posInit.setFirst(t.getCoorXPref(n));
        posInit.setSecond(t.getCoorYPref(n));
        
        Queue<Pair> qPos = new LinkedList<>();
        qPos.add(posInit);
        
        int dist = 1;
        boolean vecRecorridas[][] = new boolean[tamano][tamano];
        for (int i = 0; i < tamano; ++i) {
            for (int j = 0; j < tamano; ++j) {
                dists[i][j] = -1;
            }
        }
        
        while(qPos.isEmpty() == false) {

            Pair posActual = qPos.remove();

            boolean arriba = (posActual.getFirst() - 1 >= 0);
            boolean abajo = (posActual.getFirst() + 1 < tamano);
            boolean izquierda = (posActual.getSecond() - 1 >= 0);
            boolean derecha = (posActual.getSecond() + 1 < tamano);

            if (arriba) {
                if (t.getCasilla(posActual.getFirst()-1,
                        posActual.getSecond()).esUsable() &&
                        t.getCasilla(posActual.getFirst()-1,
                        posActual.getSecond()).isPrefijada() == false) {
                    
                        Pair posAux = new Pair();
                        posAux.setFirst(posActual.getFirst()-1);
                        posAux.setSecond(posActual.getSecond());
                        distImmersiva(posAux,dist,d,t,vecRecorridas,dists);
                }

                if (derecha) {
                    if (t.getCasilla(posActual.getFirst()-1,
                        posActual.getSecond()+1).esUsable() &&
                        t.getCasilla(posActual.getFirst()-1,
                        posActual.getSecond()+1).isPrefijada() == false) {

                        Pair posAux = new Pair();
                        posAux.setFirst(posActual.getFirst()-1);
                        posAux.setSecond(posActual.getSecond()+1);
                        distImmersiva(posAux,dist,d,t,vecRecorridas,dists);
                    }
                }
                if (izquierda) {
                    if (t.getCasilla(posActual.getFirst()-1,
                        posActual.getSecond()-1).esUsable() &&
                        t.getCasilla(posActual.getFirst()-1,
                        posActual.getSecond()-1).isPrefijada() == false) {

                        Pair posAux = new Pair();
                        posAux.setFirst(posActual.getFirst()-1);
                        posAux.setSecond(posActual.getSecond()-1);
                        distImmersiva(posAux,dist,d,t,vecRecorridas,dists);;

                    }
                }
            }

            if (abajo) {
                if (t.getCasilla(posActual.getFirst()+1,
                        posActual.getSecond()).esUsable() &&
                        t.getCasilla(posActual.getFirst()+1,
                        posActual.getSecond()).isPrefijada() == false) {

                        Pair posAux = new Pair();
                        posAux.setFirst(posActual.getFirst()+1);
                        posAux.setSecond(posActual.getSecond());
                        distImmersiva(posAux,dist,d,t,vecRecorridas,dists);

                }

                if (derecha) {

                    if (t.getCasilla(posActual.getFirst()+1,
                        posActual.getSecond()+1).esUsable() &&
                        t.getCasilla(posActual.getFirst()+1,
                        posActual.getSecond()+1).isPrefijada() == false) {

                        Pair posAux = new Pair();
                        posAux.setFirst(posActual.getFirst()+1);
                        posAux.setSecond(posActual.getSecond()+1);
                        distImmersiva(posAux,dist,d,t,vecRecorridas,dists);

                    }
                }
                if (izquierda) {
                    if (t.getCasilla(posActual.getFirst()+1,
                        posActual.getSecond()-1).esUsable() &&
                        t.getCasilla(posActual.getFirst()+1,
                        posActual.getSecond()-1).isPrefijada() == false) {

                        Pair posAux = new Pair();
                        posAux.setFirst(posActual.getFirst()+1);
                        posAux.setSecond(posActual.getSecond()-1);
                        distImmersiva(posAux,dist,d,t,vecRecorridas,dists);

                    }
                }
            }

            if (derecha) {
                if (t.getCasilla(posActual.getFirst(),
                        posActual.getSecond()+1).esUsable() &&
                        t.getCasilla(posActual.getFirst(),
                        posActual.getSecond()+1).isPrefijada() == false) {

                        Pair posAux = new Pair();
                        posAux.setFirst(posActual.getFirst());
                        posAux.setSecond(posActual.getSecond()+1);
                        distImmersiva(posAux,dist,d,t,vecRecorridas,dists);

                }
            }

            if (izquierda) {
                if (t.getCasilla(posActual.getFirst(),
                        posActual.getSecond()-1).esUsable() &&
                        t.getCasilla(posActual.getFirst(),
                        posActual.getSecond()-1).isPrefijada() == false) {

                        Pair posAux = new Pair();
                        posAux.setFirst(posActual.getFirst());
                        posAux.setSecond(posActual.getSecond()-1);
                        distImmersiva(posAux,dist,d,t,vecRecorridas,dists);

                }
            }
        }
    }
    
    private void distImmersiva(Pair p, int d, int max, TableroHidato t, boolean rec[][], int dists[][]) {
        
        if (d <= max) {
            
            dists[p.getFirst()][p.getSecond()] = d;
            rec[p.getFirst()][p.getSecond()] = true;
            
            Queue<Pair> qPos = new LinkedList<>();
            qPos.add(p);
            
            while(qPos.isEmpty() == false) {

                Pair posActual = qPos.remove();
                
                boolean arriba = (posActual.getFirst() - 1 >= 0);
                boolean abajo = (posActual.getFirst() + 1 < tamano);
                boolean izquierda = (posActual.getSecond() - 1 >= 0);
                boolean derecha = (posActual.getSecond() + 1 < tamano);
                
                if (arriba) {
                    
                    if (t.getCasilla(posActual.getFirst()-1,
                            posActual.getSecond()).esUsable() &&
                            t.getCasilla(posActual.getFirst()-1,
                            posActual.getSecond()).isPrefijada() == false) {

                        Pair posAux = new Pair();
                        posAux.setFirst(posActual.getFirst()-1);
                        posAux.setSecond(posActual.getSecond());

                        if (dists[posAux.getFirst()][posAux.getSecond()] > d+1 ||
                                dists[posAux.getFirst()][posAux.getSecond()] == -1){

                            distImmersiva(posAux,d+1,max,t,rec,dists);
                        }
                    }

                    if (derecha) {
                        if (t.getCasilla(posActual.getFirst()-1,
                            posActual.getSecond()+1).esUsable() &&
                            t.getCasilla(posActual.getFirst()-1,
                            posActual.getSecond()+1).isPrefijada() == false) {

                            Pair posAux = new Pair();
                            posAux.setFirst(posActual.getFirst()-1);
                            posAux.setSecond(posActual.getSecond()+1);

                            if (dists[posAux.getFirst()][posAux.getSecond()] > d+1 ||
                                    dists[posAux.getFirst()][posAux.getSecond()] == -1){

                                distImmersiva(posAux,d+1,max,t,rec,dists);
                            }
                        }
                    }
                    if (izquierda) {
                        if (t.getCasilla(posActual.getFirst()-1,
                            posActual.getSecond()-1).esUsable() &&
                            t.getCasilla(posActual.getFirst()-1,
                            posActual.getSecond()-1).isPrefijada() == false) {

                            Pair posAux = new Pair();
                            posAux.setFirst(posActual.getFirst()-1);
                            posAux.setSecond(posActual.getSecond()-1);

                            if (dists[posAux.getFirst()][posAux.getSecond()] > d+1 ||
                                    dists[posAux.getFirst()][posAux.getSecond()] == -1) {

                                distImmersiva(posAux,d+1,max,t,rec,dists);
                            }
                        }
                    }
                }

                if (abajo) {
                    
                    if (t.getCasilla(posActual.getFirst()+1,
                            posActual.getSecond()).esUsable() &&
                            t.getCasilla(posActual.getFirst()+1,
                            posActual.getSecond()).isPrefijada() == false) {

                        Pair posAux = new Pair();
                        posAux.setFirst(posActual.getFirst()+1);
                        posAux.setSecond(posActual.getSecond());

                        if (dists[posAux.getFirst()][posAux.getSecond()] > d+1 ||
                                dists[posAux.getFirst()][posAux.getSecond()] == -1){

                            distImmersiva(posAux,d+1,max,t,rec,dists);
                        }

                    }

                    if (derecha) {
                        if (t.getCasilla(posActual.getFirst()+1,
                            posActual.getSecond()+1).esUsable() &&
                            t.getCasilla(posActual.getFirst()+1,
                            posActual.getSecond()+1).isPrefijada() == false) {

                            Pair posAux = new Pair();
                            posAux.setFirst(posActual.getFirst()+1);
                            posAux.setSecond(posActual.getSecond()+1);

                            if (dists[posAux.getFirst()][posAux.getSecond()] > d+1 ||
                                    dists[posAux.getFirst()][posAux.getSecond()] == -1){

                                distImmersiva(posAux,d+1,max,t,rec,dists);
                            }

                        }
                    }
                    if (izquierda) {
                        if (t.getCasilla(posActual.getFirst()+1,
                            posActual.getSecond()-1).esUsable() &&
                            t.getCasilla(posActual.getFirst()+1,
                            posActual.getSecond()-1).isPrefijada() == false) {

                            Pair posAux = new Pair();
                            posAux.setFirst(posActual.getFirst()+1);
                            posAux.setSecond(posActual.getSecond()-1);

                            if (dists[posAux.getFirst()][posAux.getSecond()] > d+1 ||
                                    dists[posAux.getFirst()][posAux.getSecond()] == -1){

                                distImmersiva(posAux,d+1,max,t,rec,dists);
                            }

                        }
                    }
                }

                if (derecha) {
                    if (t.getCasilla(posActual.getFirst(),
                            posActual.getSecond()+1).esUsable() &&
                            t.getCasilla(posActual.getFirst(),
                            posActual.getSecond()+1).isPrefijada() == false) {
                        
                        Pair posAux = new Pair();
                        posAux.setFirst(posActual.getFirst());
                        posAux.setSecond(posActual.getSecond()+1);

                        if (dists[posAux.getFirst()][posAux.getSecond()] > d+1 ||
                                dists[posAux.getFirst()][posAux.getSecond()] == -1){

                            distImmersiva(posAux,d+1,max,t,rec,dists);
                        }
                    }
                }

                if (izquierda) {
                    if (t.getCasilla(posActual.getFirst(),
                            posActual.getSecond()-1).esUsable() &&
                            t.getCasilla(posActual.getFirst(),
                            posActual.getSecond()-1).isPrefijada() == false) {

                        Pair posAux = new Pair();
                        posAux.setFirst(posActual.getFirst());
                        posAux.setSecond(posActual.getSecond()-1);

                        if (dists[posAux.getFirst()][posAux.getSecond()] > d+1 ||
                                dists[posAux.getFirst()][posAux.getSecond()] == -1){

                            distImmersiva(posAux,d+1,max,t,rec,dists);
                        }
                    }
                }
            }
        }
    }
    
    private void calcularCandidatosPatras (int x, int x2, TableroHidato t) {
        
        int distMax = x - (x2 + 1);
        int dists[][] = new int[tamano][tamano];
                
        distanciaCasillas(x,distMax,t,dists);
        
        for (int i = 0; i < tamano; ++i) {
            for (int j = 0; j < tamano; ++j) {
                if (dists[i][j] < 1) {
                    // Quito los candidatos que no llego por distancia, es decir
                    // Todos ente x y x2.
                    for (int e = x-1; e > x2; --e){
                        t.getCasilla(i,j).delCan(e);
                    }
                }
                if (dists[i][j] > 0) {
                    // Quito los candidatos que no llegue por distancia.
                    if (dists[i][j] > 1) {
                        for (int y = 0; y <= (x - (x - dists[i][j] +1));++y) {
                            t.getCasilla(i, j).delCan(x-y);
                        }
                    }
                    
                    Set<Integer> sAux = new HashSet<>();
                    for (int k = dists[i][j]; k > x-(x2+1); ++k) {
                        sAux.add(x-k);
                    }
                    
                    Iterator<Integer> itAux1 = sAux.iterator();
                    Iterator<Integer> itAux2 = t.getCasilla(i,j).getCandidatos().iterator();
                    
                    for (int z = 0; z < t.getCasilla(i,j).getNumCan();++z) {
                        
                        int aux = itAux2.next(); // candidatos de la casilla
                        
                        if (aux > x2 && aux < x) {
                            
                            boolean encontrado = false;
                            
                            for (int m = 0; m < sAux.size(); ++m) {
                                int aux2 = itAux1.next();
                                if (aux == aux2) {
                                    encontrado = true;
                                }
                            }
                            
                            if (encontrado = false) {
                                t.getCasilla(i,j).delCan(aux);
                            }
                        }
                    }
                }
            }
        }
    }
    
    private boolean validarTablero(TableroHidato t){
        
        //long TInicio;
        //TInicio = System.nanoTime();
        //System.out.println(" @Tiempo inicial: "+TInicio+" nanosegundos.");
        
        tamano = t.getTamano();
        
        casillaMin = 2;
        
        casillaMax = 2;
        
        numNoUsables = 0;
                
        for (int i = 0; i < t.getTamano();++i) {
            for (int j = 0; j < t.getTamano();++j) {
                if (t.getPrefijada(i, j)) {
                    if (t.getValor(i, j) > casillaMax) casillaMax = t.getValor(i,j);
                    else if (t.getValor(i,j) < casillaMin) casillaMin = t.getValor(i,j);
                }
                else if (t.getUsabilidad(i, j) == false) numNoUsables++;
            }
        }
        
        //System.out.println(" casillaMin = "+casillaMin+" #");
        //System.out.println(" casillaMax = "+casillaMax+" #");
        //System.out.println(" numNoUsables = "+numNoUsables+" #");
        //System.out.println(" # Miro que los valores de casillas sean correctos #");
        // Si la casilla prefijada minima no es 1 esta mal.
        if (casillaMin != 1) {
            //System.out.println(" # No lo son #");
            //System.out.println(" @Calculado en "+(System.nanoTime() - TInicio)+" nanosegundos.");
            return false;
        }
        
        // Si la casilla prefijada maxima no es el numero de casillas
        // usables esta mal.
        if (casillaMax != ((t.getTamano() * t.getTamano()) - numNoUsables)) {
            //System.out.println(" # No lo son #");
            //System.out.println(" @Calculado en "+(System.nanoTime() - TInicio)+" nanosegundos.");
            return false;
        }
        
        //System.out.println(" # Lo son #");
        
        // Miro que una casilla no estÃ© rodeada por casillas no usables y
        // miro que si una casilla solo tiene una casilla usable cercana
        // que esa casilla sea la inicial o la final.
        
        //System.out.println(" # Miro que una casilla no estÃ© aislada #");
        
        for (int i = 0; i < tamano; ++i) {
            for (int j = 0; j < tamano; ++j) {
                if (this.mirarCercanas(i,j,tableroOriginal) == 0) {
                    //System.out.println(" # Lo estÃ¡ (tiene 0) #");
                    //System.out.println(" @Calculado en "+(System.nanoTime() - TInicio)+" nanosegundos.");
                    return false;
                }
                else if ((this.mirarCercanas(i,j,tableroOriginal) == 1) &&
                        (t.getCasilla(i, j).isPrefijada() == true && 
                        (t.getValor(i,j) != casillaMin &&
                        (t.getValor(i,j) != casillaMax)))) {
                    //System.out.println(" # Lo estÃ¡ (pero tiene 1) #");
                    //System.out.println(" @Calculado en "+(System.nanoTime() - TInicio)+" nanosegundos.");
                    return false;
                }
            }
        }
        
        //System.out.println(" # No lo estÃ¡ #");
        
        //System.out.println(" # Miro que se pueda llegar a todas las casillas usables #");
        
        if (calcularTodosLosCaminos() == false) {
            //System.out.println(" # No se puede #");
            //System.out.println(" @Calculado en "+(System.nanoTime() - TInicio)+" nanosegundos.");
            return false;
        }
        
        //System.out.println(" # Se puede #");
        //System.out.println(" @Calculado en "+(System.nanoTime() - TInicio)+" nanosegundos.");
        return prefijadasNoRepetidas(tableroOriginal);
        
    }
    
    private int mirarCercanas(int x, int y, TableroHidato t) {
        /*if (t.getUsabilidad(x, y) == true) {
            
            int aux = 0;
            boolean arriba = (x-1 >= 0);
            boolean abajo = (x+1 < t.getTamano());
            boolean izquierda = (y-1 >= 0);
            boolean derecha = (y+1 < t.getTamano());

            if (arriba) {

                if (t.getCasilla(x-1,y).esUsable()) 
                    ++aux;
                if (derecha) if (t.getCasilla(x-1,y+1).esUsable()) 
                    ++aux;
                if (izquierda) if (t.getCasilla(x-1,y-1).esUsable()) 
                    ++aux;
                
            }
            if (abajo) {
                
                if (t.getCasilla(x+1,y).esUsable()) 
                    ++aux;
                if (derecha) if (t.getCasilla(x+1,y+1).esUsable()) 
                    ++aux;
                if (izquierda) if (t.getCasilla(x+1,y-1).esUsable())
                    ++aux;
                
            }
            if (izquierda) if (t.getCasilla(x,y-1).esUsable()) ++aux;
            if (derecha) if (t.getCasilla(x,y+1).esUsable()) ++aux;
            return aux;
        }*/
        return 8;
    }
    
    private void calcularMapaAux(TableroHidato t) {
        mapaAux = new int[t.getTamano()][t.getTamano()];
        for (int i = 0; i < t.getTamano(); ++i) {
            for (int j = 0; j < t.getTamano(); ++j) {
                if (t.getUsabilidad(i, j) && t.getValor(i, j) == 0)  mapaAux[i][j] = -1;
                else mapaAux[i][j] = 0; 
            }
        }
    }
    
    private boolean calcularTodosLosCaminos() {
        
        boolean encontrado = false;
        
        Pair posicion = new Pair();
        posicion.setFirst(tableroOriginal.getCoorXPref(1));
        posicion.setSecond(tableroOriginal.getCoorYPref(1));
        
        Queue<Pair> qPos = new LinkedList<>();
        qPos.add(posicion);
        int tableroDist[][] = new int[tamano][tamano];
        for (int i = 0; i < tamano; ++i) {
            for (int j = 0; j < tamano; ++j) {
                if (i == posicion.getFirst() && j == posicion.getSecond()) 
                    tableroDist[i][j] = 1;
                else if (tableroOriginal.getCasilla(i, j).esUsable() == false) 
                    tableroDist[i][j] = -1;
                else tableroDist[i][j] = 0;
            }
        }
                
        while(qPos.isEmpty() == false) {
            
            Pair posActual = new Pair();
            posActual = qPos.remove();
            
            boolean arriba = (posActual.getFirst() - 1 >= 0);
            boolean abajo = (posActual.getFirst() + 1 < tamano);
            boolean izquierda = (posActual.getSecond() - 1 >= 0);
            boolean derecha = (posActual.getSecond() + 1 < tamano);
            
            Pair posAux = new Pair();
            
            if (arriba) {
                posAux.setFirst(posActual.getFirst() - 1);
                posAux.setSecond(posActual.getSecond());
                if (tableroOriginal.getCasilla(posAux.getFirst(),
                        posAux.getSecond()).esUsable()) {
                    if (tableroDist[posAux.getFirst()][posAux.getSecond()] == 0) {
                        qPos.add(posAux);
                        ++tableroDist[posAux.getFirst()][posAux.getSecond()];
                    }
                }
            }
            posAux = new Pair();
            if (arriba && derecha) {
                posAux.setFirst(posActual.getFirst() - 1);
                posAux.setSecond(posActual.getSecond() +1);
                if (tableroOriginal.getCasilla(posAux.getFirst(),
                        posAux.getSecond()).esUsable()) {
                    if (tableroDist[posAux.getFirst()][posAux.getSecond()] == 0) {
                        qPos.add(posAux);
                        ++tableroDist[posAux.getFirst()][posAux.getSecond()];
                    }
                }
            }
            posAux = new Pair();
            if (arriba && izquierda) {
                posAux.setFirst(posActual.getFirst() - 1);
                posAux.setSecond(posActual.getSecond() - 1);
                if (tableroOriginal.getCasilla(posAux.getFirst(),
                        posAux.getSecond()).esUsable()) {
                    if (tableroDist[posAux.getFirst()][posAux.getSecond()] == 0) {
                        qPos.add(posAux);
                        ++tableroDist[posAux.getFirst()][posAux.getSecond()];
                    }
                }
            }
            posAux = new Pair();
            if (abajo) {
                posAux.setFirst(posActual.getFirst() + 1);
                posAux.setSecond(posActual.getSecond());
                if (tableroOriginal.getCasilla(posAux.getFirst(),
                        posAux.getSecond()).esUsable()) {
                    if (tableroDist[posAux.getFirst()][posAux.getSecond()] == 0) {
                        qPos.add(posAux);
                        ++tableroDist[posAux.getFirst()][posAux.getSecond()];
                    }
                }
            }
            posAux = new Pair();
            if (abajo && derecha) {
                posAux.setFirst(posActual.getFirst() + 1);
                posAux.setSecond(posActual.getSecond() + 1);
                if (tableroOriginal.getCasilla(posAux.getFirst(),
                        posAux.getSecond()).esUsable()) {
                    if (tableroDist[posAux.getFirst()][posAux.getSecond()] == 0) {
                        qPos.add(posAux);
                        ++tableroDist[posAux.getFirst()][posAux.getSecond()];
                    }
                }
            }
            posAux = new Pair();
            if (abajo && izquierda) {
                posAux.setFirst(posActual.getFirst() + 1);
                posAux.setSecond(posActual.getSecond() - 1);
                if (tableroOriginal.getCasilla(posAux.getFirst(),
                        posAux.getSecond()).esUsable()) {
                    if (tableroDist[posAux.getFirst()][posAux.getSecond()] == 0) {
                        qPos.add(posAux);
                        ++tableroDist[posAux.getFirst()][posAux.getSecond()];
                    }
                }
            }
            posAux = new Pair();
            if (derecha) {
                posAux.setFirst(posActual.getFirst());
                posAux.setSecond(posActual.getSecond() + 1);
                if (tableroOriginal.getCasilla(posAux.getFirst(),
                        posAux.getSecond()).esUsable()) {
                    if (tableroDist[posAux.getFirst()][posAux.getSecond()] == 0) {
                        qPos.add(posAux);
                        ++tableroDist[posAux.getFirst()][posAux.getSecond()];
                    }
                }
            }
            posAux = new Pair();
            if (izquierda) {
                posAux.setFirst(posActual.getFirst());
                posAux.setSecond(posActual.getSecond() - 1);
                if (tableroOriginal.getCasilla(posAux.getFirst(),
                        posAux.getSecond()).esUsable()) {
                    if (tableroDist[posAux.getFirst()][posAux.getSecond()] == 0) {
                        qPos.add(posAux);
                        ++tableroDist[posAux.getFirst()][posAux.getSecond()];
                    }
                }
            }
            
        }
        return !encontrado;
    }
    
    private boolean backtrack(TableroHidato t) {
        int candidatosMin = t.getN()*t.getN();
        int contador = 0;
        //miramos el menor nº de candidatos para todas las casillas del mapa (!= 0)
        for (int i = 0; i < t.getN(); ++i) {
            for (int j = 0; j< t.getN(); ++j) {
                if (t.getUsabilidad(i, j) && t.getPrefijada(i, j) == false && t.getNumCan(i, j) < candidatosMin && t.getValor(i, j) == 0) {
                    candidatosMin = t.getNumCan(i, j);
                    contador = 1;
                }
                else if (t.getNumCan(i, j) == candidatosMin) ++contador;
            }
        }
        //para guardarnos las casillas con menor numero de candidatos en un vector
        if (candidatosMin != 0) {
            //vector de pairs para guardar las pos de las casillas
            Pair[] casillasAProbar = new Pair[contador];
            //System.out.println("Tamaño casillasaprobar:" + casillasAProbar.length);
            int k = 0;
            for (int i = 0; i < t.getN(); ++i) {
                for (int j = 0; j < t.getN(); ++j) {
                    if (t.getUsabilidad(i, j) && t.getNumCan(i, j) == candidatosMin && t.getValor(i, j) == 0) {
                        casillasAProbar[k] = new Pair();
                        casillasAProbar[k].setFirst(i);
                        casillasAProbar[k].setSecond(j);
                        ++k;
                    }
                }
            }
            //escogemos una casilla al alzar para empezar el backtracking
            Random rn = new Random();
            int elegido = 0;
            if (contador > 1) elegido = rn.nextInt(contador-1);
            int x = casillasAProbar[elegido].getFirst();
            int y = casillasAProbar[elegido].getSecond();
           // System.out.println("La casilla con menos candidatos para empezar el backtracking es: " + x + " " + y);
            //System.out.println("Empiezo el backtracking con: " + x + " " + y);
            if(backtracking(t, x, y, t, false, 0)) return true;
            return false;
        }
        return false;
    }
    
    /*  PRE: 0 <= i <= t.getTam(), 0 <= j <= t.getTam()
        POST: Se calcula una solución válida del tablero t
    */
    
    // HAY QUE HACER QUE PRIMERO MIRE DE PONER LOS VALORES QUE SOLO ESTEN EN
    // UNA CASILLA
    
    private boolean backtracking(TableroHidato t, int i, int j, TableroHidato orig, boolean candidatoUnico, int valorCanUnico) {
        
        // Miro todos los valores que quedan por prefijar esten en mínimo una casilla
        // Miro que todas las casillas tengan candidatos.
        // Miro que no hayan casillas aisladas.
        if (validacionDuranteBacktracking(t) == false) {
            return false;
        }
        Pair act = new Pair();
        act.setFirst(i);
        act.setSecond(j);
        mapaAux[i][j] = 0;
        int[] candidatos = t.consultarCandidatosCasilla(i, j);
        int valCandidato = 0; //siempre valdrá 0 excepto cuando tengamos un candidato único
                              //momento en el que valdra la pos en el array candidatos de dicho candidato único
        
        for (int x = 0; x < candidatos.length; ++x) {
            boolean canUnico = false; //lo usaremos para la llamada recursiva, si encontramos algún can único
                                  //lo activaremos a true 
            boolean iteracionacabada = false;
            TableroHidato copy = new TableroHidato();
            copy.copia(t);
            if (!candidatoUnico) {
                copy.setValor(candidatos[x], i, j);
                System.out.println("No tengo un candidato único para este paso");
                System.out.println("Tengo " + candidatos.length + " en total");
                System.out.println("Estoy probando el " + x);
                System.out.println("Pongo el valor " + candidatos[x] + " en " + i + " " + j);
            }
            else {
                copy.setValor(valorCanUnico, i, j);
                System.out.println("Pongo el valor " + valorCanUnico + " en " + i + " " + j);
            }
            copy.dibujarTablero();
            //calcularMapaAux(copy);
            int[] prefijadas = copy.getKeys();
            sort(prefijadas);

            int k = 1;
            boolean acabado = false;
            //System.out.println("prefijadas.length = "+prefijadas.length);
            while (k < prefijadas.length && !acabado) {
                if (prefijadas[k] ==  candidatos[x]) {
                    /*Pair sig = new Pair();
                    sig.setFirst(copy.getCoorXPref(prefijadas[k+1]));
                    sig.setSecond(copy.getCoorYPref(prefijadas[k+1]));*/
                    acabado = true;
                }
                else ++k;
            }

            if (BFS) {
                calcularCandidatosBFS(copy, act, k, prefijadas);
            }

            else {
                //todas las casillas prefijadas
                //Pair sig = new Pair();
                //sig.setFirst(t.getCoorXPref(prefijadas[k+1]));
                //sig.setSecond(t.getCoorYPref(prefijadas[k+1]));
                //calcularCandidatos(copy, act, sig);
            }

            
            int candidatosMin = copy.getN()*copy.getN();
            int contador = 0;
            //miramos el menor nº de candidatos para todas las casillas del mapa (!= 0)
            
            int tam = copy.getTamano()*copy.getTamano(); //usado para solventar problemas al declarar el array
            int[] contadorCandids = new int[tam]; //contador de aparición de candidatos en cada casilla
            Pair[] posicionCandids = new Pair[tam]; //array de pairs para guardar la posición de la casilla no rellenada con un candidato único
            for (int pos = 0; pos < posicionCandids.length; ++pos) posicionCandids[pos] = new Pair(); //Inicialización del array de posiciones
            
            for (int ii = 0; ii < copy.getN(); ++ii) {
                for (int jj = 0; jj< copy.getN(); ++jj) {
                    if (copy.getUsabilidad(ii, jj) && copy.getNumCan(ii, jj) < candidatosMin && copy.getValor(ii, jj) == 0) {
                        candidatosMin = copy.getNumCan(ii, jj);
                        contador = 1;
                        if (copy.getValor(ii, jj) == 0 && copy.getNumCan(ii, jj) == 0) iteracionacabada = true;
                    }
                    else if (copy.getNumCan(ii, jj) == candidatosMin && copy.getValor(ii, jj) == 0 && copy.getUsabilidad(ii, jj)) ++contador;
                    
                    
                    //CONTAMOS LOS CANDIDATOS QUE TIENE CADA CASILLA USABLE Y NO RELLENADA AÚN 
                    if (copy.getUsabilidad(ii, jj) && copy.getValor(ii, jj) == 0) {
                        int[] candids = copy.consultarCandidatosCasilla(ii, jj);
                        for (int can = 0; can < candids.length; ++can) {
                            ++contadorCandids[candids[can]]; //candidato con valor cancids[can] encontrado
                            if (contadorCandids[candids[can]] == 1) {
                                //posición de la primera casilla con el candidato candids[can]
                                //la utilidad reside en que, si al final de recorrernos la matriz entera sólo encontramos 1
                                //sabremos que la posición de la casilla que lo tiene es esta
                                posicionCandids[candids[can]].setFirst(ii);
                                posicionCandids[candids[can]].setSecond(jj);
                            }
                        }
                    }
                    
                    
                }
            }
            Pair sig = new Pair();
            //System.out.println("minAntes: "+candidatosMin);
            //para guardarnos las casillas con menor numero de candidatos en un vector
            
            if (contador != 0) { //no he encontrado ninguna casilla sin rellenar
                
                for (int can = 0; can < contadorCandids.length && !canUnico; ++can) {
                    if (contadorCandids[can] == 1) {
                        canUnico = true;
                        sig.setFirst(posicionCandids[can].getFirst());
                        sig.setSecond(posicionCandids[can].getSecond());
                        valCandidato = can;
                        //la posición de la siguiente casilla a probar será la de la casilla con un candidato único
                    }
                }
                
                
                if (candidatosMin == 0) return false;
                
                if (!canUnico) {
                    //vector de pairs para guardar las pos de las casillas
                    Pair[] casillasAProbar = new Pair[contador];
                    k = 0;
                    //System.out.println("min: "+candidatosMin);
                    for (int ii = 0; ii < t.getN(); ++ii) {
                        for (int jj = 0; jj < t.getN(); ++jj) {
                            if (copy.getUsabilidad(ii, jj) && copy.getNumCan(ii, jj) == candidatosMin && copy.getValor(ii, jj) == 0) {
                                casillasAProbar[k] = new Pair();
                                casillasAProbar[k].setFirst(ii);
                                casillasAProbar[k].setSecond(jj);
                                ++k;
                            }
                        }
                    }
                    Random rn = new Random();
                    int elegido = 0;
                    if (contador > 1) elegido = rn.nextInt(contador-1);
                    //escogemos una casilla al alzar para empezar el backtracking
                    int xeleg = casillasAProbar[elegido].getFirst();
                    int yeleg = casillasAProbar[elegido].getSecond();
                    sig.setFirst(xeleg);
                    sig.setSecond(yeleg);
                }
            }
            else {
                //nos guardamos la solución en el tablero original (que es el tablero en su estado inicial antes de probar valores)
                for (int iii = 0; iii < orig.getN(); ++iii) {
                    for (int jjj = 0; jjj < orig.getN(); ++jjj) {
                        orig.setSolucion(copy.getValor(iii, jjj), iii, jjj);
                    }
                }
                return true;
            }
            if (!iteracionacabada) {
                if (backtracking(copy, sig.getFirst(), sig.getSecond(), orig, canUnico, valCandidato)) return true;
                //ponemos el pair sig y el int sig.getFirst() para los dos ultimos parametros porque nos dan igual, no los usaremos
                //pero tenemos que seguir poniendo atributos de esos tipos en la cabecera para que compile
            }
            
            if (candidatoUnico) x += candidatos.length; //si solo tenemos un candidato sumamos 
            //la condición de fin al bucle for para forzar que no haga más iteraciones
        }
            return false;
    }
        
    // INTENTO DE GENERADOR RECURSIVO //
    
    public TableroHidato generadorTableroRandomRecursivo(TableroHidato t) {
        boolean solucionable = false;    
        TableroHidato copiadoT = new TableroHidato();
        while (solucionable == false) {
            try {
                while (solucionable == false) {
                    
                    copiadoT.copia(t);
                    int tam = copiadoT.getN();
                    Random rand = new Random();
                    int anadirPorc1 = 0;
                    int anadirPorc2 = 10;
                    if (tam > 6) {
                        anadirPorc1 = 5;
                        anadirPorc2 = 25;
                    }
                    
                    double porc1 = (double) rand.nextInt(20) + anadirPorc1;
                    double porc2 = ((double) rand.nextInt(10)) + anadirPorc2;
                    
                    
                    int nNoUsables = (int) ((porc1/(double)100) * (tam*tam));
                    
                    for (int i = 0; i < nNoUsables; ++i) {
                        int fila = rand.nextInt(tam - 1);
                        int col = rand.nextInt(tam - 1);
                        copiadoT.setUsabilidad(false, fila, col);
                    }
                    
                    nNoUsables = 0;
                    for (int i = 0; i < tam; ++i) {
                        for (int j = 0; j < tam; ++j) {
                            if (copiadoT.getUsabilidad(i, j) == false) ++nNoUsables;
                        }
                    }
                    boolean todoCorrecto = false;
                    
                    casillaMin = 1;
                    casillaMax = (tam*tam) - nNoUsables;
                    
                    
                    Queue<Integer> qCas = new LinkedList<>();
                    
                    calcularCasillasUsables(tam,porc2,nNoUsables,qCas);
                    
                    System.out.println("Esta es la base");
                    copiadoT.dibujarTablero();
                    
                    todoCorrecto = ponerCasillasRecursivo(qCas,copiadoT,1,null,nNoUsables);
                    
                    if (todoCorrecto == true) {
                        System.out.println("El tablero se ha podido solucionar.");
                        System.out.println("it: "+nIt);
                        nIt = 0;
                        solucionable = true;
                        //solucionable = resolver(copiadoT,true);
                    }
                    else {
                        System.out.println("El tablero no se podia resolver.");
                        System.out.println("nIt: "+nIt);
                    }
                    
                }
            }
            
            catch(ArrayIndexOutOfBoundsException | NoSuchElementException | NullPointerException e) {
                System.out.println("ha habido una excepcion");
                solucionable = false;
                e.printStackTrace();
            }
        }
        return copiadoT;
    }
    
    public TableroHidato generadorTableroRandom(TableroHidato t) {
        int nError = 1;
        boolean solucionable = false;    
        TableroHidato copiadoT = new TableroHidato();
        while (solucionable == false) {
            try {
                while (solucionable == false) {
                    
                    copiadoT.copia(t);
                    int tam = copiadoT.getN();
                    Random rand = new Random();
                    int anadirPorc = 10;
                    if (tam > 6) anadirPorc = 50;
                    
                    double porc1 = (double) rand.nextInt(10);
                    double porc2 = ((double) rand.nextInt(10)) + anadirPorc;
                    
                    
                    int nNoUsables = (int) ((porc1/(double)100) * (tam*tam));
                    
                    for (int i = 0; i < nNoUsables; ++i) {
                        int fila = rand.nextInt(tam - 1);
                        int col = rand.nextInt(tam - 1);
                        copiadoT.setUsabilidad(false, fila, col);
                    }
                    
                    int fila = rand.nextInt(tam - 1);
                    int col = rand.nextInt(tam - 1);
                    
                    copiadoT.setValor(1, fila, col);
                    
                    nNoUsables = 0;
                    for (int i = 0; i < tam; ++i) {
                        for (int j = 0; j < tam; ++j) {
                            if (copiadoT.getUsabilidad(i, j) == false) ++nNoUsables;
                        }
                    }
                    
                    Queue<Integer> qCas = new LinkedList<>();
                    //calcularRestoCasillasUsables(tam,porc2,nNoUsables,qCas);
                    ponerCasillas(qCas,copiadoT,tam,nNoUsables);
                    //System.out.println("Intento solucionar:");
                    //copiadoT.dibujarTablero();
                    solucionable = resolver(copiadoT,true);
                    //if (solucionable == false) System.out.println("Este tablero no se puede resolver.");
                }
            }
            
            catch(ArrayIndexOutOfBoundsException | NoSuchElementException | NullPointerException e) {
                //System.out.println("Excepcion ("+nError+")");
                //System.out.println(e.getMessage());
                //System.out.println("El tablero del error es:");
                //copiadoT.dibujarTablero();
                try{
                    //System.out.println("Lo intento volver a resolver:");
                    solucionable = resolver(copiadoT,true);
                    //System.out.println("puedo, la solucion es:");
                    //dibujarSolucionDelTablero(copiadoT.retornaSolucion(),copiadoT.getTamano());
                }
                catch(ArrayIndexOutOfBoundsException | NoSuchElementException | NullPointerException e2) {
                    //System.out.println("y no puedo");
                }
                ++nError;
                solucionable = false;
            }
        }
        return copiadoT;
    }
    
    private void calcularCasillasUsables(int tam, double porc2,
            int nNoUsables, Queue<Integer> qCas) {
        qCas.add(1);
        
        Random rand = new Random();
        for (int i = 2; i < (tam*tam)-nNoUsables; ++i) {
            /*
            int aux = rand.nextInt(100);
            if (aux <= (int) porc2) {
                qCas.add(i);
                //System.out.println("@Se añade la casilla "+i+" @");
            }*/
            qCas.add(i);
        }
        qCas.add((tam*tam)-nNoUsables);
        //Queue<Integer> qCasCopia = new LinkedList<>(qCas);
        //System.out.println("Casillas para prefijar:");
        //for (int i = 0; i < qCas.size(); ++i) System.out.println(qCasCopia.poll()+" ");
        
    }
    
    private boolean ponerCasillasRecursivo(Queue<Integer> qCas, TableroHidato t,
            int casAnt, Pair posAnt, int nNoUsables) {
        
        // En qCas tengo los valores de las casillas que seran prefijadas.
        
        // La primera casilla que hay es la siguiente al 1.
        
        // La ultima casilla de qCas es la casilla maxima.
        
        // Tengo que calcular (excepto para el 1) todas las posiciones 
        // que puede tener la siguiente prefijada y elegir una al azar.
        // Una vez hecho y sin quitar el resto de posiciones, tengo que hacer
        // lo mismo para el resto de casillas y una vez puesta la ultima.
        // Si es solucionable devuelvo el tablero y en el caso contrario
        // lo intento con la siguiente posicion.
        
        
            /*
            for (int x = 0; x < t.getTamano(); ++x) {
                for (int y = 0; y < t.getTamano(); ++y) {
                    if (mirarCercanas(x,y,t) == 0) {
                        System.out.println("fallo 1");
                        return false;
                    }
                    else if (mirarCercanas(x,y,t) == 1 &&
                            (t.getValor(x, y) != casillaMax &&
                            t.getValor(x, y) != casillaMin)) {
                        System.out.println("fallo 2");
                        return false;
                    }
                }
            }*/
            
        if (mirarConexo(t,casAnt) == false) {
            //System.out.println("fallo 3");
            return false;
        }
        
        if (qCas.isEmpty()) {
            //System.out.println("qCas esta vacio asi que voy  resolver este tablero:");
            //t.dibujarTablero();
            ++nIt;
            System.out.println("FINAL");
            //System.out.println(nIt);
            return true;
        }
        else {
            //System.out.println("Entro en la recursividad y soy la casilla con valor: "+qCas.element());
            int casillaActual = qCas.poll();

            Queue<Pair> qPos = new LinkedList<>();

            // Si es la casilla 1 le pongo todas las posiciones posibles.
            if (casillaActual == 1) {
                for (int i = 0; i < t.getTamano(); ++i) {
                    for (int j = 0; j < t.getTamano(); ++j) {
                        if ((t.getUsabilidad(i, j)) && (t.getPrefijada(i, j) == false)) {
                            Pair aux = new Pair();
                            aux.setFirst(i);
                            aux.setSecond(j);
                            qPos.add(aux);
                        }
                    }
                }
                //System.out.println("Como soy el 1 me he puesto todas las pocisiciones.");
            }
            // Si es otra casilla tengo que calcular que posiciones puede tener.
            else {
                //System.out.println("Soy el "+casillaActual+" y mi anterior es "+casAnt);
                int distMax = (casillaActual - casAnt);
                calcularPorBFS(posAnt,distMax,t,qPos);
            }

            // Ahora en qPos tengo todas las posiciones posibles para
            // 'casillaActual', asi que tengo que elegir un valor
            // al azar y probar suerte.
            
            boolean acabado = false;
            while (qPos.isEmpty() == false && acabado == false) {

                //t.dibujarTablero();
                
                Pair posicionCasilla = new Pair();
                Random rand = new Random();
                int index = 0;
                
                if (qPos.size() > 1) {

                    index = rand.nextInt(qPos.size() - 1);
                    // 0 <= index <= (qPos.size() - 1)
                    // index tiene la posicion de qPos que contiene la posicion
                    // que vamos a probar.

                    for (int i = 0; i < index; ++i) qPos.add(qPos.poll());
                    // Hemos quitado 'index' posiciones de la cola que hemos movido
                    // al final de esta.

                    posicionCasilla = qPos.poll();

                }
                else posicionCasilla = qPos.poll();

                // ahora qPos tiene un elemento menos que tenemos en
                // posicionCasilla
                
                TableroHidato tCopia = new TableroHidato();
                tCopia.copia(t);
                tCopia.setValor(casillaActual, posicionCasilla.getFirst(), posicionCasilla.getSecond());
                
                /*
                for (int x = 0; x < tCopia.getTamano(); ++x) {
                    for (int y = 0; y < tCopia.getTamano(); ++y) {
                        if (mirarCercanas(x,y,tCopia) == 0) return false;
                        else if (mirarCercanas(x,y,tCopia) == 1 &&
                                (t.getValor(x, y) != casillaMax &&
                                t.getValor(x, y) != casillaMin)) return false;
                    }
                }*/
                
                Queue<Integer> qCasCopia = new LinkedList<>(qCas);
                
                acabado = ponerCasillasRecursivo(qCasCopia, tCopia,
                        casillaActual, posicionCasilla, nNoUsables);
                
                if (acabado == true) {
                    //System.out.println("La iteracion ha sido correcta.");
                    //System.out.println("Este es t");
                    //t.dibujarTablero();
                    //System.out.println("Esta es su copia");
                    //tCopia.dibujarTablero();
                    //System.out.println("Ahora t es la copia");
                    t.copia(tCopia);
                    return true;
                }
                
            }
        }
        return false;
    }
    
    private void ponerCasillas(Queue<Integer> qCas, TableroHidato t, int tam,
            int nNoUsables) {
        //System.out.println("tamaño en poner casilal : "+t.getN());
        //System.out.println(" y tam = "+tam);
        Pair posAnt = new Pair();
        Random rand = new Random();
        Queue<Pair> qPosAux = new LinkedList<>();
        posAnt.setFirst(t.getCoorXPref(1));
        posAnt.setSecond(t.getCoorYPref(1));
        int casAct = 1;
        int casAnt = 1;
        //Pair posAct = new Pair();
        while (qCas.isEmpty() == false) {
            casAct = qCas.poll();
            int distMax = (casAct - casAnt);
            calcularPorBFS(posAnt,distMax,t,qPosAux);
            int indexPos;
            //System.out.println("qPosAux.size = "+qPosAux.size());
            Iterator<Pair> itAux= qPosAux.iterator();
            for (int i = 0; i < qPosAux.size(); ++i) {
                Pair aux = itAux.next();
                //System.out.println(" >> "+aux.getFirst()+" "+aux.getSecond());
            }
            if (qPosAux.size() > 1)
                indexPos = rand.nextInt(qPosAux.size() -1);
            else indexPos = 0;
            //System.out.println("indexPos = "+indexPos);
            for (int i = 0; i<indexPos;++i) qPosAux.remove();
            t.setValor(casAct, qPosAux.element().getFirst(), qPosAux.element().getSecond());
            casAnt = casAct;
            posAnt = qPosAux.element();
            qPosAux = new LinkedList<>();
        }
        casAct = (tam*tam)-nNoUsables;
        //System.out.println(" la ultima casilla es: "+casAct);
        int distancia = ((tam * tam) - nNoUsables)-casAnt;
        qPosAux = new LinkedList<>();
        calcularPorBFS(posAnt,distancia,t,qPosAux);
        int indexPos;
        if (qPosAux.size() > 1)
            indexPos = rand.nextInt(qPosAux.size() -1);
        else indexPos = 0;
        for (int i = 0; i<indexPos;++i) qPosAux.remove();
        t.setValor(casAct, qPosAux.element().getFirst(), qPosAux.element().getSecond());
    }
    
    private void calcularPorBFS(Pair posAnt, int d, TableroHidato t,
            Queue<Pair>qPosAux) {
        
        ////System.out.println(" # Entro en calcularPorBFS #");
        ////System.out.println(" # la posicion inicial es ("+posAnt.getFirst()+","+posAnt.getSecond()+") #");
        //t.dibujarTablero();
        int dists[][] = new int[t.getN()][t.getN()];
        
        Pair posInit = new Pair();
        posInit.setFirst(posAnt.getFirst());
        posInit.setSecond(posAnt.getSecond());
        
        Queue<Pair> qPos = new LinkedList<>();
        qPos.add(posInit);
        ////System.out.println(" # la posicion actual es ("+posInit.getFirst()+","+posInit.getSecond()+") #");
        ////System.out.println(" # t.getN() = "+t.getN()+" #");
        int dist = 1;
        boolean vecRecorridas[][] = new boolean[t.getN()][t.getN()];
        for (int i = 0; i < t.getN(); ++i) {
            for (int j = 0; j < t.getN(); ++j) {
                if (i == posInit.getFirst() && j == posInit.getSecond()) vecRecorridas[i][j] = true;
                else vecRecorridas[i][j] = false;
            }
        }
        for (int i = 0; i < t.getN(); ++i) {
            for (int j = 0; j < t.getN(); ++j) {
                dists[i][j] = -1;
            }
        }
        
        ////System.out.println(" # matriz de booleanos #");
        for (int i = 0; i < t.getN(); ++i) {
            ////System.out.print(" # ");
            for (int j = 0; j < t.getN(); ++j) {
                ////System.out.print(vecRecorridas[i][j]+" ");
            }
            ////System.out.print("\n");
        }
        
        while(qPos.isEmpty() == false) {
            
            //////System.out.println(" > qPos no estÃ¡ vacÃ­a.");

            Pair posActual = qPos.remove();

            boolean arriba = (posActual.getFirst() - 1 >= 0);
            boolean abajo = (posActual.getFirst() + 1 < t.getN());
            boolean izquierda = (posActual.getSecond() - 1 >= 0);
            boolean derecha = (posActual.getSecond() + 1 < t.getN());

            if (arriba) {
                // Si la casilla de arriba es un 0 le pongo la distancia.
                if (t.getCasilla(posActual.getFirst()-1,
                        posActual.getSecond()).esUsable() &&
                        t.getCasilla(posActual.getFirst()-1,
                        posActual.getSecond()).isPrefijada() == false) {
                    
                        Pair posAux = new Pair();
                        posAux.setFirst(posActual.getFirst()-1);
                        posAux.setSecond(posActual.getSecond());
                        //////System.out.println(" > EntrarÃ© en immersiva por arriba");
                        distImmersiva(qPosAux,posAux,dist,d,t,vecRecorridas,dists);
                        //distImmersiva(Pair p, int d, int max, TableroHidato t, boolean rec[][], int dists[][])
                }

                if (derecha) {
                    if (t.getCasilla(posActual.getFirst()-1,
                        posActual.getSecond()+1).esUsable() &&
                        t.getCasilla(posActual.getFirst()-1,
                        posActual.getSecond()+1).isPrefijada() == false) {

                        Pair posAux = new Pair();
                        posAux.setFirst(posActual.getFirst()-1);
                        posAux.setSecond(posActual.getSecond()+1);
                        //////System.out.println(" > EntrarÃ© en immersiva por arriba a la derecha");
                        distImmersiva(qPosAux,posAux,dist,d,t,vecRecorridas,dists);

                    }
                }
                if (izquierda) {
                    if (t.getCasilla(posActual.getFirst()-1,
                        posActual.getSecond()-1).esUsable() &&
                        t.getCasilla(posActual.getFirst()-1,
                        posActual.getSecond()-1).isPrefijada() == false) {

                        Pair posAux = new Pair();
                        posAux.setFirst(posActual.getFirst()-1);
                        posAux.setSecond(posActual.getSecond()-1);
                        //////System.out.println(" > EntrarÃ© en immersiva por arriba a la izquierda");
                        distImmersiva(qPosAux,posAux,dist,d,t,vecRecorridas,dists);;

                    }
                }
            }

            if (abajo) {
                if (t.getCasilla(posActual.getFirst()+1,
                        posActual.getSecond()).esUsable() &&
                        t.getCasilla(posActual.getFirst()+1,
                        posActual.getSecond()).isPrefijada() == false) {

                        Pair posAux = new Pair();
                        posAux.setFirst(posActual.getFirst()+1);
                        posAux.setSecond(posActual.getSecond());
                        //////System.out.println(" > EntrarÃ© en immersiva por abajo");
                        distImmersiva(qPosAux,posAux,dist,d,t,vecRecorridas,dists);

                }

                if (derecha) {

                    if (t.getCasilla(posActual.getFirst()+1,
                        posActual.getSecond()+1).esUsable() &&
                        t.getCasilla(posActual.getFirst()+1,
                        posActual.getSecond()+1).isPrefijada() == false) {

                        Pair posAux = new Pair();
                        posAux.setFirst(posActual.getFirst()+1);
                        posAux.setSecond(posActual.getSecond()+1);
                        //////System.out.println(" > EntrarÃ© en immersiva por abajo a la derecha");
                        distImmersiva(qPosAux,posAux,dist,d,t,vecRecorridas,dists);

                    }
                }
                if (izquierda) {
                    if (t.getCasilla(posActual.getFirst()+1,
                        posActual.getSecond()-1).esUsable() &&
                        t.getCasilla(posActual.getFirst()+1,
                        posActual.getSecond()-1).isPrefijada() == false) {

                        Pair posAux = new Pair();
                        posAux.setFirst(posActual.getFirst()+1);
                        posAux.setSecond(posActual.getSecond()-1);
                        //////System.out.println(" > EntrarÃ© en immersiva por abajo a la izquierda");
                        distImmersiva(qPosAux,posAux,dist,d,t,vecRecorridas,dists);

                    }
                }
            }

            if (derecha) {
                if (t.getCasilla(posActual.getFirst(),
                        posActual.getSecond()+1).esUsable() &&
                        t.getCasilla(posActual.getFirst(),
                        posActual.getSecond()+1).isPrefijada() == false) {

                        Pair posAux = new Pair();
                        posAux.setFirst(posActual.getFirst());
                        posAux.setSecond(posActual.getSecond()+1);
                        //////System.out.println(" > EntrarÃ© en immersiva por la derecha");
                        distImmersiva(qPosAux,posAux,dist,d,t,vecRecorridas,dists);

                }
            }

            if (izquierda) {
                if (t.getCasilla(posActual.getFirst(),
                        posActual.getSecond()-1).esUsable() &&
                        t.getCasilla(posActual.getFirst(),
                        posActual.getSecond()-1).isPrefijada() == false) {

                        Pair posAux = new Pair();
                        posAux.setFirst(posActual.getFirst());
                        posAux.setSecond(posActual.getSecond()-1);
                        //////System.out.println(" > EntrarÃ© en immersiva por la izquierda");
                        distImmersiva(qPosAux,posAux,dist,d,t,vecRecorridas,dists);

                }
            }
        }
        
        ////System.out.println(" poicion inicial = ("+posAnt.getFirst()+","+posAnt.getSecond()+") #");
        
        //System.out.println(" # casilla ("+posAnt.getFirst()+","+posAnt.getSecond()+") #");
        //System.out.println(" # la distancia es "+d+" #");
        //System.out.println(" # matriz de distancias #");
        for (int i = 0; i < t.getN(); ++i) {
            //System.out.print(" # ");
            for (int j = 0; j < t.getN(); ++j) {
                //System.out.print(dists[i][j]+" ");
            }
            //System.out.print("\n");
        }
        
    }
    
    private void distImmersiva(Queue<Pair> qPosAux,Pair p, int d, int max,
            TableroHidato t, boolean rec[][], int dists[][]) {
        
        ////System.out.println(" # Entro en distanciaImmersiva con los valores siguientes #");
        ////System.out.println(" # p = ("+p.getFirst()+","+p.getSecond()+") #");
        ////System.out.println(" # d = "+d+" #");
        ////System.out.println(" # max = "+max+" #");
        
        ////System.out.println(" # matriz de booleanos #");
        for (int i = 0; i < t.getN(); ++i) {
            ////System.out.print(" # ");
            for (int j = 0; j < t.getN(); ++j) {
                ////System.out.print(rec[i][j]+" ");
            }
            ////System.out.print("\n");
        }
        ////System.out.println(" # matriz de distancias #");
        for (int i = 0; i < t.getN(); ++i) {
            ////System.out.print(" # ");
            for (int j = 0; j < t.getN(); ++j) {
                ////System.out.print(dists[i][j]+" ");
            }
            ////System.out.print("\n");
        }
        
        ////System.out.println(" # Esta es toda la informacion inicial");
        
        if (d <= max) {
            //System.out.println("encuentro la pos ("+p.getFirst()+","+p.getSecond()+")");
            //System.out.println("y rec = "+rec[p.getFirst()][p.getSecond()]);
            if (rec[p.getFirst()][p.getSecond()] == false) {
                //System.out.println("Lo añado");
                qPosAux.add(p);
            }
            ////System.out.println(" # Como la distancia aun no es la maxima, le pongo la distancia #");
            dists[p.getFirst()][p.getSecond()] = d;
            rec[p.getFirst()][p.getSecond()] = true;
            
            ////System.out.println(" # Y las matrizes quedan asÃ­ #");
            
            ////System.out.println(" # matriz de booleanos #");
            for (int i = 0; i < t.getN(); ++i) {
                ////System.out.print(" # ");
                for (int j = 0; j < t.getN(); ++j) {
                    ////System.out.print(rec[i][j]+" ");
                }
                ////System.out.print("\n");
            }
            ////System.out.println(" # matriz de distancias #");
            for (int i = 0; i < t.getN(); ++i) {
                ////System.out.print(" # ");
                for (int j = 0; j < t.getN(); ++j) {
                    ////System.out.print(dists[i][j]+" ");
                }
                ////System.out.print("\n");
            }
            
            Queue<Pair> qPos = new LinkedList<>();
            qPos.add(p);
            
            while(qPos.isEmpty() == false) {

                Pair posActual = qPos.remove();
                
                ////System.out.println(" >> la pos actual es: ("+posActual.getFirst()+","+posActual.getSecond()+") <<");
                
                ////System.out.println(" En el tablero distancias: ");
                ////System.out.println(" # matriz de distancias #");
                /*
                for (int i = 0; i < t.getN(); ++i) {
                    ////System.out.print(" # ");
                    for (int j = 0; j < t.getN(); ++j) {
                        if (i == posActual.getFirst() &&
                                j == posActual.getSecond())
                            //System.out.print("-5 ");
                        else if (dists[i][j] > 0) //System.out.print("+"+dists[i][j]+" ");
                        else //System.out.print(+dists[i][j]+" ");
                    }
                    ////System.out.print("\n");
                }
                */
                
                boolean arriba = (posActual.getFirst() - 1 >= 0);
                boolean abajo = (posActual.getFirst() + 1 < t.getN());
                boolean izquierda = (posActual.getSecond() - 1 >= 0);
                boolean derecha = (posActual.getSecond() + 1 < t.getN());
                
                ////System.out.println("> pos("+posActual.getFirst()+","+posActual.getSecond()+") <");
                ////System.out.println(" > arriba = "+arriba);
                ////System.out.println(" > abajo = "+abajo);
                ////System.out.println(" > derecha = "+derecha);
                ////System.out.println(" > izquierda = "+izquierda);
                
                if (arriba) {
                    ////System.out.println(" >>> y arriba = true <<<");
                    //Si la casilla de arriba es un 0 le pongo la distancia.
                    if (t.getCasilla(posActual.getFirst()-1,
                            posActual.getSecond()).esUsable() &&
                            t.getCasilla(posActual.getFirst()-1,
                            posActual.getSecond()).isPrefijada() == false) {

                            Pair posAux = new Pair();
                            posAux.setFirst(posActual.getFirst()-1);
                            posAux.setSecond(posActual.getSecond());
                            
                            /*//System.out.println(" >>> por arriba dist = "+dists
                                    [posAux.getFirst()][posAux.getSecond()]+
                                    " <<<");*/
                            
                            if (dists[posAux.getFirst()][posAux.getSecond()] > d+1 ||
                                    dists[posAux.getFirst()][posAux.getSecond()] == -1){
                                ////System.out.println(" >>>> entro <<<<");
                                distImmersiva(qPosAux,posAux,d+1,max,t,rec,dists);
                            }
                    }

                    if (derecha) {
                        ////System.out.println(" >>> y arriba y derecha = true <<<");
                        if (t.getCasilla(posActual.getFirst()-1,
                            posActual.getSecond()+1).esUsable() &&
                            t.getCasilla(posActual.getFirst()-1,
                            posActual.getSecond()+1).isPrefijada() == false) {

                            Pair posAux = new Pair();
                            posAux.setFirst(posActual.getFirst()-1);
                            posAux.setSecond(posActual.getSecond()+1);
                            
                            /*//System.out.println(" >>> por arriba-derecha dist = "+dists
                                    [posAux.getFirst()][posAux.getSecond()]+
                                    " <<<");*/
                            
                            if (dists[posAux.getFirst()][posAux.getSecond()] > d+1 ||
                                    dists[posAux.getFirst()][posAux.getSecond()] == -1){
                                ////System.out.println(" >>>> entro <<<<");
                                distImmersiva(qPosAux,posAux,d+1,max,t,rec,dists);
                            }
                                

                        }
                    }
                    if (izquierda) {
                        ////System.out.println(" >>> y arriba y izquierda= true <<<");
                        if (t.getCasilla(posActual.getFirst()-1,
                            posActual.getSecond()-1).esUsable() &&
                            t.getCasilla(posActual.getFirst()-1,
                            posActual.getSecond()-1).isPrefijada() == false) {

                            Pair posAux = new Pair();
                            posAux.setFirst(posActual.getFirst()-1);
                            posAux.setSecond(posActual.getSecond()-1);
                            
                            /*//System.out.println(" >>> por arriba-izquierda dist = "+dists
                                    [posAux.getFirst()][posAux.getSecond()]+
                                    " <<<");*/
                            
                            if (dists[posAux.getFirst()][posAux.getSecond()] > d+1 ||
                                    dists[posAux.getFirst()][posAux.getSecond()] == -1) {
                                ////System.out.println(" >>>> entro <<<<");
                                distImmersiva(qPosAux,posAux,d+1,max,t,rec,dists);
                            }
                        }
                    }
                }

                if (abajo) {
                    ////System.out.println(" >>> y abajo = true <<<");
                    if (t.getCasilla(posActual.getFirst()+1,
                            posActual.getSecond()).esUsable() &&
                            t.getCasilla(posActual.getFirst()+1,
                            posActual.getSecond()).isPrefijada() == false) {

                            Pair posAux = new Pair();
                            posAux.setFirst(posActual.getFirst()+1);
                            posAux.setSecond(posActual.getSecond());
                            
                            /*//System.out.println(" >>> por abajo dist = "+dists
                                    [posAux.getFirst()][posAux.getSecond()]+
                                    " <<<");*/
                            
                            if (dists[posAux.getFirst()][posAux.getSecond()] > d+1 ||
                                    dists[posAux.getFirst()][posAux.getSecond()] == -1){
                                ////System.out.println(" >>>> entro <<<<");
                                distImmersiva(qPosAux,posAux,d+1,max,t,rec,dists);
                            }

                    }

                    if (derecha) {
                        ////System.out.println(" >>> y abajo y derecha = true <<<");
                        if (t.getCasilla(posActual.getFirst()+1,
                            posActual.getSecond()+1).esUsable() &&
                            t.getCasilla(posActual.getFirst()+1,
                            posActual.getSecond()+1).isPrefijada() == false) {

                            Pair posAux = new Pair();
                            posAux.setFirst(posActual.getFirst()+1);
                            posAux.setSecond(posActual.getSecond()+1);
                            
                            /*//System.out.println(" >>> por abajo-derecha dist = "+dists
                                    [posAux.getFirst()][posAux.getSecond()]+
                                    " <<<");*/
                            
                            if (dists[posAux.getFirst()][posAux.getSecond()] > d+1 ||
                                    dists[posAux.getFirst()][posAux.getSecond()] == -1){
                                ////System.out.println(" >>>> entro <<<<");
                                distImmersiva(qPosAux,posAux,d+1,max,t,rec,dists);
                            }

                        }
                    }
                    if (izquierda) {
                        ////System.out.println(" >>> y abajo y izquierda= true <<<");
                        if (t.getCasilla(posActual.getFirst()+1,
                            posActual.getSecond()-1).esUsable() &&
                            t.getCasilla(posActual.getFirst()+1,
                            posActual.getSecond()-1).isPrefijada() == false) {

                            Pair posAux = new Pair();
                            posAux.setFirst(posActual.getFirst()+1);
                            posAux.setSecond(posActual.getSecond()-1);
                            
                            /*//System.out.println(" >>> por abajo-izquierda dist = "+dists
                                    [posAux.getFirst()][posAux.getSecond()]+
                                    " <<<");*/
                            
                            if (dists[posAux.getFirst()][posAux.getSecond()] > d+1 ||
                                    dists[posAux.getFirst()][posAux.getSecond()] == -1){
                                ////System.out.println(" >>>> entro <<<<");
                                distImmersiva(qPosAux,posAux,d+1,max,t,rec,dists);
                            }

                        }
                    }
                }

                if (derecha) {
                    ////System.out.println(" >>> y derecha = true <<<");
                    if (t.getCasilla(posActual.getFirst(),
                            posActual.getSecond()+1).esUsable() &&
                            t.getCasilla(posActual.getFirst(),
                            posActual.getSecond()+1).isPrefijada() == false) {

                            Pair posAux = new Pair();
                            posAux.setFirst(posActual.getFirst());
                            posAux.setSecond(posActual.getSecond()+1);
                            
                            /*//System.out.println(" >>> por derecha dist = "+dists
                                    [posAux.getFirst()][posAux.getSecond()]+
                                    " <<<");*/
                            
                            if (dists[posAux.getFirst()][posAux.getSecond()] > d+1 ||
                                    dists[posAux.getFirst()][posAux.getSecond()] == -1){
                                ////System.out.println(" >>>> entro <<<<");
                                distImmersiva(qPosAux,posAux,d+1,max,t,rec,dists);
                            }

                    }
                }

                if (izquierda) {
                    ////System.out.println(" >>> y izquierda = true <<<");
                    if (t.getCasilla(posActual.getFirst(),
                            posActual.getSecond()-1).esUsable() &&
                            t.getCasilla(posActual.getFirst(),
                            posActual.getSecond()-1).isPrefijada() == false) {

                            Pair posAux = new Pair();
                            posAux.setFirst(posActual.getFirst());
                            posAux.setSecond(posActual.getSecond()-1);
                            
                            /*//System.out.println(" >>> por izquierda dist = "+dists
                                    [posAux.getFirst()][posAux.getSecond()]+
                                    " <<<");*/
                            
                            if (dists[posAux.getFirst()][posAux.getSecond()] > d+1 ||
                                    dists[posAux.getFirst()][posAux.getSecond()] == -1){
                                ////System.out.println(" >>>> entro <<<<");
                                distImmersiva(qPosAux,posAux,d+1,max,t,rec,dists);
                            }

                    }
                }
            }
            
        }
        
        ////System.out.println(" # Salgo de distanciaImmersiva con los valores siguientes #");
        ////System.out.println(" # p = ("+p.getFirst()+","+p.getSecond()+") #");
        ////System.out.println(" # d = "+d+" #");
        ////System.out.println(" # max = "+max+" #");
        ////System.out.println(" # matriz de booleanos #");
        for (int i = 0; i < t.getN(); ++i) {
            ////System.out.print(" # ");
            for (int j = 0; j < t.getN(); ++j) {
                ////System.out.print(rec[i][j]+" ");
            }
            ////System.out.print("\n");
        }
        ////System.out.println(" # matriz de distancias #");
        for (int i = 0; i < t.getN(); ++i) {
            ////System.out.print(" # ");
            for (int j = 0; j < t.getN(); ++j) {
                ////System.out.print(dists[i][j]+" ");
            }
            ////System.out.print("\n");
        }
        
        ////System.out.println(" # Esta es toda la informacion final");
    }
    
    public void dibujarSolucionDelTablero(int[][] sol, int t) {
        System.out.print("\n");
        for (int i = 0; i < t; ++i) {
            System.out.print("    ");
            for (int j = 0; j < t; ++j) {
                int auxMaxCol = maxDecCol(j, sol);
                int auxCalcul = calculEspais(sol[i][j],auxMaxCol);
                if (sol[i][j] > 0) System.out.print(sol[i][j]);
                else System.out.print("X");
                for (int e = 0; e < auxCalcul;++e){
                    System.out.print(" ");
                }
            }
            System.out.print("\n");
        }
    }
    
    private static int calculEspais (int i, int max){
        int aux = 0;
        if (i < 10) aux = 1;
        else if (i < 100) aux = 2;
        else aux = 3;
        //System.out.println("i = "+i+" max = "+max+" aux = "+aux);
        return (2 + (max - aux));
    }
    
    private static int maxDecCol (int i, int[][] sol) {
        int max = 1;
        int auxTamano = sol.length;
        for (int j = 0; j < auxTamano; ++j) {
            if (sol[j][i] > 9 && sol[j][i] < 99 && max < 2) max = 2;
            else if (sol[j][i] > 99) max = 3;
        }
        return max;
    }
    
    private boolean prefijadasNoRepetidas(TableroHidato t){
        for (int i = 0; i < t.PrefSize(); ++i){
            for (int j = 0; j < t.PrefSize(); ++j) {
                if (i != j) {
                    if (t.getKeys()[i] == t.getKeys()[j]) {
			System.out.println("Falla en candidatos repetidos");
			return false;
                    }
                }
            }
        }
        return true;
    }
    
    private boolean validacionDuranteBacktracking(TableroHidato t) {

        //Miro que todos las casillas tengan candidatos.
        
        Queue<Integer> qValores = new LinkedList<>();
        
        for (int i = 0; i < t.getTamano(); ++i) {
            for (int j = 0; j < t.getTamano(); ++j) {
                if (t.getUsabilidad(i, j) == true) {
                    if (t.getValor(i,j) == 0 && t.getCasilla(i, j).getNumCan() == 0) {
                        return false;
                    }
                    else qValores.add(t.getValor(i,j));
                }
            }
        }
        
        // Miro que todos los valores esten en minimo una casilla.
        
        // Aqui tengo en qValores todas los valores de casillas prefijadas.
        
        Queue<Integer> qNoPref = new LinkedList<>();
        
        for (int i = 1; i < casillaMax; ++i) {
            if (qValores.contains(i) == false) qNoPref.add(i);
        }
        
        // Aqui tengo en qNoPref todos los valores que aun estan por prefijar.
        
        while (qNoPref.isEmpty() == false) {
            int valorBuscando = qNoPref.poll();
            boolean encontrado = false;
            for (int i = 0; i < t.getTamano(); ++i) {
                for (int j = 0; j < t.getTamano(); ++j) {
                    if (t.getUsabilidad(i, j) == true && t.getValor(i,j) == 0) {
                        if (t.getCasilla(i,j).contains(valorBuscando) == true) {
                            encontrado = true;
                        }
                    }
                }
            }
            if (encontrado == false) return false;
        }
        
        // Miro que no esten rodeadas.
        
        for (int x = 0; x < t.getTamano(); ++x) {
            for (int y = 0; y < t.getTamano(); ++y) {
                if (mirarCercanas(x,y,t) == 0) return false;
                else if (mirarCercanas(x,y,t) == 1 &&
                        (t.getValor(x, y) != casillaMax &&
                        t.getValor(x, y) != casillaMin)) return false;
            }
        }
        
        return true;
    }
    
    private static void dibujarCandidatos(TableroHidato t) {
        
        for (int i = 0; i < t.getTamano(); ++i) {
            for (int j = 0; j < t.getTamano(); ++j) {
                if (t.getUsabilidad(i,j) == true && t.getValor(i,j) == 0) {
                    System.out.print("Candidatos de ("+i+","+j+"): [ ");
                    HashSet<Integer> sAux = t.getCasilla(i, j).getCandidatos();
                    Iterator<Integer> itAux = sAux.iterator();
                    for (int x = 0; x < sAux.size(); ++x) {
                        System.out.print(itAux.next()+" ");
                    }
                    System.out.print("]\n");
                }
            }
        }
        
    }
    
    public boolean mirarConexo(TableroHidato t, int casilla) {
        
        //System.out.println("miro conexo para el "+casilla);
        
        Pair posCasilla = new Pair();
        
        for (int i = 0; i < t.getTamano(); ++i) {
            for (int j = 0; j < t.getTamano(); ++j) {
                if (t.getValor(i, j) == casilla) {
                    posCasilla.setFirst(i);
                    posCasilla.setSecond(j);
                }
            }
        }
        
        boolean recorrido[][] = new boolean[t.getTamano()][t.getTamano()];
        
        recorrerTablero(t,posCasilla, recorrido);
        
        boolean solucio = false;
        
        /*
        for (int i = 0; i < recorrido.length; ++i) {
            System.out.print("##");
            for (int j = 0; j < recorrido.length; ++j) {
                if (recorrido[i][j] == true) System.out.print("1 ");
                if (recorrido[i][j] == false) System.out.print("0 ");
            }
            System.out.print("\n");
        }*/
        
        for (int i = 0; i < recorrido.length; ++i) {
            for (int j = 0; j < recorrido.length; ++j) {
                if (recorrido[i][j] == false) {
                    if (t.getUsabilidad(i, j) == true) {
                        if (t.getPrefijada(i, j) == false) {
                            //System.out.println("fallo en ("+i+","+j+")");
                            return false;
                        }
                    }
                }
            }
        }
        
        return true;
    }
    
    public void recorrerTablero(TableroHidato t, Pair posActual, boolean recorrido[][]) {
        
        //System.out.println("pongo ("+posActual.getFirst()+","+posActual.getSecond()+") a true");
        
        recorrido[posActual.getFirst()][posActual.getSecond()] = true;
        
        /*
        for (int i = 0; i < recorrido.length; ++i) {
            System.out.print("##");
            for (int j = 0; j < recorrido.length; ++j) {
                if (recorrido[i][j] == true) System.out.print("1 ");
                if (recorrido[i][j] == false) System.out.print("0 ");
            }
            System.out.print("\n");
        }
        */
        boolean arriba = (posActual.getFirst() - 1 >= 0);
        boolean abajo = (posActual.getFirst() + 1 < t.getN());
        boolean izquierda = (posActual.getSecond() - 1 >= 0);
        boolean derecha = (posActual.getSecond() + 1 < t.getN());
        
        /*
        System.out.println("top: "+String.valueOf(arriba));
        System.out.println("right: "+String.valueOf(derecha));
        System.out.println("left: "+String.valueOf(izquierda));
        System.out.println("bottom: "+String.valueOf(abajo));
        */
        Pair posAux = new Pair();
        
        if (arriba) {
            //Top (i-1)
            posAux.setFirst(posActual.getFirst() - 1);
            posAux.setSecond(posActual.getSecond());
            if (t.getUsabilidad(posAux.getFirst(), posAux.getSecond()) == true) {
                if (t.getPrefijada(posAux.getFirst(), posAux.getSecond()) == false) {
                    if (recorrido[posAux.getFirst()][posAux.getSecond()] == false)
                        recorrerTablero(t,posAux,recorrido);
                }
            }
            
            //TOP RIGHT (i-1, j+1)
            if (derecha){
                posAux.setFirst(posActual.getFirst() - 1);
                posAux.setSecond(posActual.getSecond() + 1);
                if (t.getUsabilidad(posAux.getFirst(), posAux.getSecond()) == true) {
                    if (t.getPrefijada(posAux.getFirst(), posAux.getSecond()) == false) {
                        if (recorrido[posAux.getFirst()][posAux.getSecond()] == false)
                        recorrerTablero(t,posAux,recorrido);
                    }
                }
            }
            
            //TOP LEFT (i-1, j-1)
            if (izquierda) {
                posAux.setFirst(posActual.getFirst() - 1);
                posAux.setSecond(posActual.getSecond() - 1);
                if (t.getUsabilidad(posAux.getFirst(), posAux.getSecond()) == true) {
                    if (t.getPrefijada(posAux.getFirst(), posAux.getSecond()) == false) {
                        if (recorrido[posAux.getFirst()][posAux.getSecond()] == false)
                        recorrerTablero(t,posAux,recorrido);
                    }
                }
            }
        }
        
        if (abajo) {
            //BOT (i+1)
            posAux.setFirst(posActual.getFirst() + 1);
            posAux.setSecond(posActual.getSecond());
            if (t.getUsabilidad(posAux.getFirst(), posAux.getSecond()) == true) {
                if (t.getPrefijada(posAux.getFirst(), posAux.getSecond()) == false) {
                    if (recorrido[posAux.getFirst()][posAux.getSecond()] == false)
                        recorrerTablero(t,posAux,recorrido);
                }
            }
            
            //BOT RIGHT (i+1,j+1)
            if (derecha) {
                posAux.setFirst(posActual.getFirst() + 1);
                posAux.setSecond(posActual.getSecond() + 1);
                if (t.getUsabilidad(posAux.getFirst(), posAux.getSecond()) == true) {
                    if (t.getPrefijada(posAux.getFirst(), posAux.getSecond()) == false) {
                        if (recorrido[posAux.getFirst()][posAux.getSecond()] == false)
                        recorrerTablero(t,posAux,recorrido);
                    }
                }
            }
            
            //BOT LEFT (i+1, j-1)
            if (izquierda) {
                posAux.setFirst(posActual.getFirst() + 1);
                posAux.setSecond(posActual.getSecond() - 1);
                if (t.getUsabilidad(posAux.getFirst(), posAux.getSecond()) == true) {
                    if (t.getPrefijada(posAux.getFirst(), posAux.getSecond()) == false) {
                        if (recorrido[posAux.getFirst()][posAux.getSecond()] == false)
                        recorrerTablero(t,posAux,recorrido);
                    }
                }
            }
        }
        
        if (derecha) {
            //RIGHT (j+1)
            posAux.setFirst(posActual.getFirst());
            posAux.setSecond(posActual.getSecond() + 1);
            if (t.getUsabilidad(posAux.getFirst(), posAux.getSecond()) == true) {
                if (t.getPrefijada(posAux.getFirst(), posAux.getSecond()) == false) {
                    if (recorrido[posAux.getFirst()][posAux.getSecond()] == false)
                        recorrerTablero(t,posAux,recorrido);
                }
            }
        }
        
        if (izquierda) {
            //LEFT (j-1)
            posAux.setFirst(posActual.getFirst());
            posAux.setSecond(posActual.getSecond() - 1);
            if (t.getUsabilidad(posAux.getFirst(), posAux.getSecond()) == true) {
                if (t.getPrefijada(posAux.getFirst(), posAux.getSecond()) == false) {
                    if (recorrido[posAux.getFirst()][posAux.getSecond()] == false)
                        recorrerTablero(t,posAux,recorrido);
                }
            }
        }
    }
    
}
