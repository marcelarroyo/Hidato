package Dominio.Estructuras;
import java.util.*;
import Compartidas.Taulell;
/*
 *
 * @author Marcel Arroyo
 */
public class TableroHidato extends Taulell {
    private CasillaHidato[][] tablero;
    private String nombre;
    private HashMap <Integer, Pair> Prefijadas;       //IMPORTANT: Prefijadas ordena els elements per defecte per la key 
    private String nombreCreador;                     // es a dir que no fa falta ordenarlo a l'hora de recorrel ja que   
                                                      // ens interesa recorrer de petit a gran
    private int[][] solucion;
    private int casillasTotales;
    private int noUsables;
    private int dificultad;
    
    /* CREADORAS DE TABLEROHIDATO */
    
    /*  PRE: -
        POST: Se crea un objeto TableroHidato sin nombre y con lista de prefijadas vacia
    */
    public TableroHidato(){
        this.nombre = "";
        super.N = 0;
        Prefijadas = new HashMap <> ();
    }
    
    /*  PRE: -
        POST: El tablero se ha creado con un nombre, tamano y lista de prefijadas vacia
    */
    public TableroHidato(String nombre, int tamano) {
        this.nombre = nombre;
        super.N = (tamano);
        tablero = new CasillaHidato[tamano][tamano];
        for (int i = 0; i < tamano; ++i) {       
            for (int j = 0; j < tamano; ++j) {
                tablero[i][j] = new CasillaHidato(i, j);
                tablero[i][j].initCan(tamano*tamano);
            }
        }
        Prefijadas = new HashMap <>();
        casillasTotales = tamano*tamano;
        solucion = new int[tamano][tamano];
    }
    public void copia (TableroHidato t) {
        nombre = t.getNombreTablero();
        super.N = (t.N);
        dificultad = t.getDificultad();
        nombreCreador = (t.getNombreCreador());
        tablero = new CasillaHidato[t.N][t.N];
        for (int i = 0; i < t.N; ++i) {
            for(int j = 0; j < t.N; ++j) {
                tablero[i][j] = new CasillaHidato(i, j);
                tablero[i][j].copy(t.getCasilla(i, j));
                tablero[i][j].setUsabilidadCasilla(t.getUsabilidad(i, j));
            }
        }
        int [] claus = t.getKeys();
        Prefijadas = new HashMap<Integer,Pair>();
        for (int k = 0; k < t.PrefSize(); ++k) {
            Pair p = new Pair();
            p = t.getCoordPref(claus[k]);
            Prefijadas.put(claus[k], p);
        }
        this.solucion = t.retornaSolucion();
    }
    
    /* CONSULTORAS DE TABLEROHIDATO */
    
    
    /*  PRE: 0 <= x <= y < tamany
        POST: la casilla ha adoptado la usabilidad indicada en el parÃ¡metro 
        "Usabilidad"
    */
    public boolean getUsabilidad(int x, int y) {
        return tablero[x][y].esUsable();
    }
    
    public void getSolucion() {
        for (int i = 0; i < solucion.length; ++i) {
            for (int j = 0; j < solucion.length; ++j) {
                System.out.printf(solucion[i][j] + " ");
                
            }
            System.out.println();
        }
    }
    
    public int getTamanoReal() {
        for (int i = 0; i < N; ++i) {
            for (int j = 0; j < N; ++j) {
                if (!tablero[i][j].esUsable()) {
                    ++noUsables;
                }
            }
        }
        return (N*N)-noUsables;
    }
    
    public String getNombreCreador(){
        return this.nombreCreador;
    }
    
    
    @Override
    public CasillaHidato getCasilla(int i, int j){
        return this.tablero[i][j];
    }
    
    /*  PRE: 0 <= x <= y < tamany
        POST: retorna el valor de la casilla en la posiciÃ³n x, y
    */
    
    public int getValor(int x, int y) {
        return tablero[x][y].getValor();
    }
    
    /*  PRE: 0 <= x <= y < tamany
        POST: Retorna si la casilla con coordenadas (x,y) es prefijada
    */
    
    public boolean getPrefijada(int x, int y) {
        return tablero[x][y].isPrefijada();
    }
    
    /*  PRE: -
        POST: Devuelve el nombre del tableroHidato 
    */
    
    public String getNombreTablero() {
        return this.nombre;
    }
    
    /*  PRE: - 
        POST: Devuelve si los dos tableros son iguales
    */
    public boolean sameHidato (TableroHidato h) {
        if (h.N != this.N) return false;
        else {
            for (int i = 0; i < h.N; ++i) {
                for (int j = 0; j < h.N; ++j) {
                    if (tablero[i][j].getValor() != this.getValor(i, j)) return false; 
                }
            }
        }
        return true;
    }
    
    /* CONSULTORAS TABLERO HIDATO CON REFERENCIA AL MAP PREFIJADAS */
    
    /*  PRE: Existe un pair en el map que tiene como key = llave
        POST: Retorna la coordenada X de la casilla prefijada con valor = llave
    */
    public int getCoorXPref(int llave) {
        Pair p = Prefijadas.get(llave);
        return p.getFirst();
    }
    
    /* PRE: Existe un pair en el map que tiene como key = llave
       POST: Retorna la coordenada Y de la casilla prefijada con valor = llave
    */
    public int getCoorYPref(int llave) {
        Pair p = Prefijadas.get(llave);
        return p.getSecond();
    }
    
    /*  PRE: -
        POST: Indica si existe alguna key = valor en el map 
    */
    public boolean existsKey (int valor) {
        return Prefijadas.containsKey(valor);
    }
    
    /*  PRE: -
        POST: Se ha establecido la dificultad del tablero
    */
    public void setDificultad(int d) {
        dificultad = d;
    }
    
    /*  PRE: - 
        POST: Se retorna la dificultad del mapa 
    */
    public int getDificultad() {
        return dificultad;
    }
    
    
    /*  PRE: - 
        POST: Indica si el map de prefijadas esta vacio 
    */
    
    public boolean isEmptyPref() {
        return Prefijadas.isEmpty();
    }
    
    /*  PRE: -
        POST: Retorna el numero de casillas prefijadas en el mapa 
    */
    
    public int PrefSize() {
        return Prefijadas.size();
    }
    
    /*  PRE: -
        POST: Retorna un iterador del map prefijadas que apunta a la primera casilla
    */
    public Iterator <HashMap.Entry <Integer, Pair>> iteradorPref() {
        return Prefijadas.entrySet().iterator();
    }
    
    /*  PRE: Existe un elemento del pair con key = valor
        POST: Retorna un pair de las coordenadas del elemento dle pair con key = valor.
        Primer elemento del pair devuelto coordX, segundo elemento coordY
    */
    
    public Pair getCoordPref(int valor) {
        return Prefijadas.get(valor);
    }
    
    
    /*  PRE: -
        POST: Retorna el conjunto de llaves del HashMap "Prefijadas" como un vector
    */
    public int[] getKeys() {
        int[] llaves = new int[Prefijadas.size()];
        int index = 0;
        //System.out.println("Tam prefijadas " + Prefijadas.size());
        for (Map.Entry<Integer, Pair> mapEntry : Prefijadas.entrySet()) {
            llaves[index] = mapEntry.getKey();
            index++;
        }
        
        return llaves;
    }
    
    public int[] getKeysOrdenadas() {
        int[] llaves = new int[Prefijadas.size()];
        int index = 0;
        //System.out.println("Tam prefijadas " + Prefijadas.size());
        for (Map.Entry<Integer, Pair> mapEntry : Prefijadas.entrySet()) {
            llaves[index] = mapEntry.getKey();
            index++;
        }
        
        int aux;
        
        for (int i = 0; i < llaves.length - 1; i++) {
            for (int x = i + 1; x < llaves.length; x++) {
                if (llaves[x] < llaves[i]) {
                    aux = llaves[i];
                    llaves[i] = llaves[x];
                    llaves[x] = aux;
                }
            }
        }
        
        return llaves;
    }
    
    public int getTamano() {
	return super.N;
    }    


    /*  PRE: 0 <= i < t.getTamano(), 0 <= j < t.getTamano()
        POST: Retorna el numero de candidatos de la casilla
    */
    public int getNumCan(int i, int j) {
        return tablero[i][j].getNumCan();
    }
    
    /*  PRE: - 
        POST: Retorna la matriz solucion
    */
    public int[][] retornaSolucion () {
        return solucion;
    } 
    
    
    /* MODIFICADORAS DE TABLEROHIDATO */
    
    
    public void setNombreCreador(String n){
        this.nombreCreador = n;
    }
    
    /*  PRE: 0 <= x <= y < tamany
        POST: la casilla ha adoptado la usabilidad indicada en el parÃ¡metro 
        "Usabilidad"
    */
   
    public void setUsabilidad(boolean Usabilidad, int x, int y) {
        if (!getUsabilidad(x, y) && Usabilidad) ++casillasTotales;
        else if (getUsabilidad(x, y) && !Usabilidad) --casillasTotales;
        tablero[x][y].setUsabilidadCasilla(Usabilidad);
        
    }
    
    /*  PRE: 0 <= x <= y < tamany
        POST: la casilla ha adoptado el valor indicado actualizando asi sus booleanos
        operacion propia del sistema cuando modifique el tablero 
        ya que el usuario solo podra introducir valores > 0 en caso d eque sea un valor 
        prefijado actualizamos el valor de la casilla (x,y) con el valor dado. Si es no usable o 
        es una casilla no prefijada los valores no los tenemos aun ya que los introducira el usuario 
    */
    
    public void setValor(int valor, int x, int y) {
        if (valor == 0) {
            if (tablero[x][y].isPrefijada()) Prefijadas.remove(valor);
            tablero[x][y].setPrefijada(false);
            tablero[x][y].setUsabilidadCasilla(true);
            tablero[x][y].setValor(0);
        }
        else if (valor == -1) {
            if (tablero[x][y].esUsable()) {
                if (tablero[x][y].isPrefijada()) Prefijadas.remove(valor);
                tablero[x][y].setPrefijada(false);
                tablero[x][y].setUsabilidadCasilla(false);
                tablero[x][y].setValor(-1);
            }
            tablero[x][y].setValor(-1);
        }
        else {
            //si era no usable disminuir casillas no usables
            if (tablero[x][y].isPrefijada()) Prefijadas.remove(valor);
            tablero[x][y].setPrefijada(true);
            tablero[x][y].setUsabilidadCasilla(true);
            tablero[x][y].setValor(valor);
            anadirMarcarPrefijada(x, y, valor);
            for (int i = 0; i < tablero.length; ++i) {
                for (int j = 0; j < tablero.length; ++j) {
                    eliminarCandidatoCasilla(i, j, valor);
                }
            }
        }
    }
    
     public int getSolucion(int i, int j) {
        return solucion[i][j];
    }
    
    public void setSolucion(int valor, int i, int j) {
        solucion[i][j] = valor;
    }
    /*  PRE: 0 <= x <= y < tamany
        POST: la casilla ha adoptado el valor indicado operacion propia del usuario
    */
    
    public void setValorUser(int valor, int x, int y) {
        if (!tablero[x][y].isPrefijada()) tablero[x][y].setValor(valor);
    }
   
    /*  PRE: 0 <= x <= y < tamany
        POST: La casilla con coor(x,y) pasa a ser prefijada si pref = 1 o no prefijada si pref = 0 
    */
    public void setPrefijada(int x, int y, boolean pref) {
        tablero[x][y].setPrefijada(pref);
    }
    
    /*  PRE: -
        POST: El nombre del tablero pasa a ser nombre = s
    */
    public void setNombreTablero(String s) {
        this.nombre = s;
    }

    public void setTamano(int t) {
        super.N = t;
    }
    
    /*  PRE: -
        POST: Se elimina el candidato num de la casilla (x,y) del tableroHidato 
    */
    public void eliminarCandidatoCasilla(int x, int y, int num) {
        boolean a = tablero[x][y].delCan(num);
    }
    
    /*  PRE: -
        POST: Retorna todos los candidatos de la casilla (x,y) del tableroHidato 
    */
    public int[] consultarCandidatosCasilla(int x, int y) {
        Set <Integer> s = tablero[x][y].getCandidatos();
        Iterator<Integer> iter = s.iterator();
        int[] n = new int [s.size()];
        int k = 0;
        for (Integer i : s) {
            n[k++] = i;
        }
        return n;
    }
    
    /* MODIFICADORAS TABLERO HIDATO CON REFERENCIA AL MAP PREFIJADAS */
    
    
    /*  PRE: -
        POST: Anade al map de prefijadas una nueva entrada con la key valor y el pair con las coordenadas (x,y) 
        y marca esa casilla como prefijada, en caso de que exista un elemento con key = valor actualiza el pair 
        con las coordenadas (x,y)
    */   
    public void anadirMarcarPrefijada(int x, int y, int valor) {
        Pair p = new Pair();
        p.setFirst(x);
        p.setSecond(y);
        Prefijadas.put(valor, p);
        tablero[x][y].setPrefijada(true);
    }
    
     /*  PRE: -
        POST: Anade al map de prefijadas una nueva entrada con la key valor y el pair con las coordenadas (x,y), 
        en caso de que exista un elemento con key = valor solo actualiza el pair con las coordenadas (x,y) 
    */   
    public void anadirPrefijada(int x, int y, int valor) {
        Pair p = new Pair();
        p.setFirst(x);
        p.setSecond(y);
        Prefijadas.put(valor, p);
    }
    
    /*  PRE: -
        POST: Si hay una key = valor borra el elemento del map con esa key
    */
    public void borrarPref (int valor) {
        Prefijadas.remove(valor);
    }
    
    /*  PRE: Existe en el map un elemento con key = valor
        POST: Si hay una key = valor borra el elemento del map con esa key y
        se modifica el booleano de esa casilla pasando a ser no prefijada
    */
    public void borrarDesmarcarPref (int valor) {
        Pair p = Prefijadas.get(valor);
        tablero[p.getFirst()][p.getSecond()].setPrefijada(false);
        Prefijadas.remove(valor);
    }
    
    /*  PRE: -
        POST: Solucion pasa a tener el valor de la matriz t
    */
    public void añadirSolucion(int [][] t) {
        solucion = new int [t.length][t.length];
        for (int i = 0; i < t.length; ++i) {
            for (int j = 0; j < t.length; ++j) {
                solucion[i][j] = t[i][j];
            }
        }
    }
    
    /* ESCRITORAS */
    
    /*  PRE:
        POST:
    */
    private int calculEspais (int i, int max){
        int aux = 0;
        if (i < 10) aux = 1;
        else if (i < 100) aux = 2;
        else aux = 3;
        //System.out.println("i = "+i+" max = "+max+" aux = "+aux);
        return (2 + (max - aux));
    }
    
    /*  PRE:
        POST:
    */
    
        private int maxDecCol (int i) {
        int max = 1;
        int auxTamano = this.N;
        for (int j = 0; j < auxTamano; ++j) {
            if (tablero[j][i].getValor() > 9 && tablero[j][i].getValor() < 99 && max < 2) max = 2;
            else if (tablero[j][i].getValor() > 99) max = 3;
        }
        return max;
    }
    
    /*  PRE: -
        POST: Se dibuja el tablero por pantalla
        OBS: Esto en principio se tiene que borrar 
    */
    public void dibujarTablero() {
        System.out.print("\n");
        for (int i = 0; i < N; ++i) {
            System.out.print("    ");
            for (int j = 0; j < N; ++j) {
                int auxMaxCol = maxDecCol(j);
                if (tablero[i][j].esUsable()) {
                    int auxCalcul = calculEspais(tablero[i][j].getValor(),auxMaxCol);
                    System.out.print(tablero[i][j].getValor());
                    for (int e = 0; e < auxCalcul;++e){
                        System.out.print(" ");
                    }
                }
                else {
                    System.out.print("#");
                    for (int e = 0; e < calculEspais(-1,auxMaxCol);++e){
                        System.out.print(" ");
                    }
                }
            }
            System.out.print("\n");
        }
    }
}

