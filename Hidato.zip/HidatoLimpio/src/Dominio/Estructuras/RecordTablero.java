/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dominio.Estructuras;
/**
 *                                              //records[0] = Record menor tiempo
 * @author Marcel                               //records[1] = Record primer jugador en solucionarlo
 *                                              //records[2] = Record maxima puntuacion
 */
public class RecordTablero {
    private PairRecord [] records ;
     
    /* CREADORAS RECORDTABLERO */
    
    /*  PRE: -
        POST: Crea un objeto del tipo recordtablero
    */
    public RecordTablero() {
        records = new PairRecord[3];
        for (int i = 0; i < 3; ++i) {
            records[i] = new PairRecord();
        }  
    }
    
    
    /* CONSULTORAS RECORDTABLERO */
    
    /*  PRE: -
        POST: Retorna true si exite un jugador que tenga el recordTiempo y false en caso contrario
    */
    public boolean existRecordTime() {
        return records[0].exists();
    }
    
    /*  PRE: -
        POST: Retorna true si exite un jugador que tenga el recordFirstPlayer y false en caso contrario
    */
    public boolean existRecordFirstPlayer() {
        return records[1].exists();
    }
    
    /*  PRE: -
        POST: Retorna true si exite un jugador que tenga el recordPuntuacion puntuacion y false en caso contrario
    */
    public boolean existRecordPoints() {
        return records[2].exists();
    }
    
    
    /*  PRE: El recordTiempo ha de existir 
        POST: Retorna un pairRecord con el idjugador i el menor tiempo 
    */
    public PairRecord getRecordTiempo() {
        return records[0];
    }
    
    /*  PRE: El record firstPlayer ha de existir
        POST: Retorna un pairRecord con el idjugador i puntuacion = null 
    */
    public PairRecord getRecordFirstPlayer() {
        return records[1];
    }
    
    /*  PRE: El record maxPoints ha de existir
        POST: Retorna un pairRecord con el idjugador i puntuacion = null 
    */
    public PairRecord getRecordPuntuacion() {
        return records[2];
    }
    
    /*  PRE: Todos los records deben existir
        POST: Retorna el vector records con todos los records del tablero 
    */
    
    public PairRecord[] getAllRecords () {
        return records;
    }
    
    /* MODIFICADORAS RECORDTABLERO */
    
    
    /*  PRE: -
        POST: Modifica el jugador i el tiempo substituyendolos por los valors idjugador = id i puntuacion = t
    */
    public void setRecordTiempo(String id, int t) {  
        records[0].setIdJugador(id);
        records[0].setPuntuacion(t);
    }
    
    /*  PRE: -
        POST: Modifica el jugador i el tiempo substituyendolos por los valors idjugador = id i puntuacion = t
    */
    public void setRecordJugador(String id) {  
        records[1].setIdJugador(id);
    }
    
    
        /*  PRE: -
        POST: Modifica el jugador i la puntuacion substituyendolos por los valors idjugador = id i puntuacion = t
    */
    public void setRecordPuntuacion(String id, int t) {  
        records[2].setIdJugador(id);
        records[2].setPuntuacion(t);
    } 
    
}
