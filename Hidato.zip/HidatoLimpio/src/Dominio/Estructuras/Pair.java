/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dominio.Estructuras;

/**
 *
 * @author Marcel
 */
public class Pair {
    private int first;
    private int second;
    
/* CONSTRUCTORAS PAIR */
    
    //PRE: -
    //POST: Crea un objecte pair 
    
    public Pair () {
    
    }
    
    //PRE: -
    //POST: Crea un pair con los parametros this.first = first y this.second = second
    
    public Pair(int first, int second) {
        this.first = first;
        this.second = second;
    }
    
    /* CONSULTORAS PAIR */
    
        //PRE: - 
    //POST: Devuelve el valor de first
    public int getFirst() {
        return first;
    }
    
    //PRE: - 
    //POST: Devuelve el valor de first
    public int getSecond() {
        return second;
    }
    
    
    /* MODIFICADORAS PAIR */
   
    
    //PRE: - 
    //POST: Se modifica el valor de first atribuyendole x 
    public void setFirst(int x) {
        first = x;
    }
    
    //PRE: - 
    //POST: Se modifica el valor de first atribuyendole y 
    public void setSecond(int y) {
        second = y;
    }
    
}
   