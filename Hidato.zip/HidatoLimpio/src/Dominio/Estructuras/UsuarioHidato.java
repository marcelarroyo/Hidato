package Dominio.Estructuras;
import java.util.*;
import Compartidas.Usuario;
/**
 *
 * @author RaÃºl IbÃ¡Ã±ez PÃ©rez
 */
public class UsuarioHidato extends Usuario {
    private int puntuacionTotal;
    
    
    public UsuarioHidato() {
        super.setNombre(null);
    }
    
    public UsuarioHidato(String n, String c) {
        super.setNombre(n);
        super.setContrasena(c);
        super.setApareceRanking(true);
        Date aux = new Date();
        super.setFecha(aux);
    }
    
    public int getPuntuacionTotal(){
        return this.puntuacionTotal;
    }
    
    public void setPuntuacionTotal(int p){
        this.puntuacionTotal = p;
    }
}
