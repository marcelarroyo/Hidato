package Dominio.Estructuras;
import Compartidas.Casilla;
/**
 *
 * @author Marcel Arroyo
 * 
 */
public class CasillaHidato extends Casilla{     //Casilla usable no pref: Se puede leer y modificar
    private boolean usable;                     //Casilla usable y pref: Se puede leer pero no modificar por el usuario
                                                //Casilla no usable: No se puede modificar ni leer
                                                
    /* CREADORAS CASILLAHIDATO */
        
    /*  PRE: -
        POST: Se crea un objeto CasillaHidato usable
    */
    public CasillaHidato(int x, int y) {
        super(x, y);
        usable = true;
    }
    
    /* CONSULTORAS CASILLA HIDATO */
    
    
    /*  PRE: -
        POST: Retorna si la casilla es usable o no. Si no lo es, no podemos interactuar con ella.
    */
    public boolean esUsable() {
        return usable;
    }
    
    
    /* MODIFICADORAS CASILLA HIDATO */
    
   
    /*  PRE: -
        POST: Se establece la usabilidad de la casilla. Si usable = true, la casilla es
        usable durante la partida y se le puede asignar algÃºn valor.
    */

    public void setUsabilidadCasilla(boolean usabilidad) {
        usable = usabilidad;
    }
    
    /*  PRE: - 
        POST: Si pref = 0 casilla no prefijada, si pref = 1 casilla prefijada
    */
    
    public void setPrefijada(boolean pref) {
        prefijada = pref;
    }
}
