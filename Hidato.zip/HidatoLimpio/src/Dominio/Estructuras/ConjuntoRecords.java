/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dominio.Estructuras;

import java.util.HashMap;

/**
 *
 * @author Marcel
 */
public class ConjuntoRecords {
    private HashMap <String, RecordTablero> cjt;
    
    
    
    //CREADORAS CJTRECORDS
    
    /*  PRE: -
        POST: Crea un conjunto de recordTablero 
    */
    public ConjuntoRecords () {
        cjt = new HashMap <> ();
    }
    
    
    
    //CONSULTORAS CJTRECORDS
    
    /*  PRE: -
        POST: Si existe el tablero s en el hashmap retorna true sino retorna false;
    */
    
    public boolean existeTablero(String s) {
        return cjt.containsKey(s);
    }
    
    /*  PRE: -
        POST: Si el hashmap esta vacio retorna true sino retorna false
    */
    
    public boolean isEmpty() {
        return cjt.isEmpty();
    }
    
    /*  PRE: -
        POST: Retorna el tamano del hashmap 
    */
    public int getTamano() {
        return cjt.size();
    }
    
    /*  PRE: El mapa s existe en el hashmap 
        POST: En caso de que el mapa s tenga un record retorna el PairRecord 
        correspondiente en caso de que no exista el record retorna un PairRecord 
        con "null" en el primer parametro y -1 en el segundo
    */
    
    public PairRecord consultarRecordTimeTablero(String s) {
        RecordTablero r = new RecordTablero();
        r = cjt.get(s);
        if (r.existRecordTime()) {
            return r.getRecordTiempo();
        }
        else {
            PairRecord rp = new PairRecord(null, 0);
            return rp;
        }
    }
    
    /*  PRE: El mapa s existe en el hashmap 
        POST: En caso de que el mapa s tenga un record retorna el PairRecord 
        correspondiente en caso de que no exista el record retorna un PairRecord 
        con "null" en el primer parametro y -1 en el segundo
    */
    
    public PairRecord consultarRecordFirstPlayerTablero(String s){
        RecordTablero r = new RecordTablero();
        r = cjt.get(s);
        if (r.existRecordFirstPlayer()) {
            return r.getRecordFirstPlayer();
        }
        else {
            PairRecord rp = new PairRecord(null, 0);
            return rp;
        }
    }
    
    /*  PRE: El mapa s existe en el hashmap 
        POST: En caso de que el mapa s tenga un record retorna el PairRecord 
        correspondiente en caso de que no exista el record retorna un PairRecord 
        con "null" en el primer parametro y -1 en el segundo
    */
    
    public PairRecord consultarRecordMaxPuntuacionTablero(String s) {
        RecordTablero r = new RecordTablero();
        r = cjt.get(s);
        if (r.existRecordPoints()) {
            return r.getRecordPuntuacion();
        }
        else {
            PairRecord rp = new PairRecord(null, 0);
            return rp;
        }
    }
    
    /*  PRE: El mapa s existe en el hashmap 
        POST: En caso de que el mapa s exist retorna todos los records de ese mapa
    */
    
    public RecordTablero consultarTodosRecordsTablero (String s) {
        return cjt.get(s);
    }
    
    //MODIFICADORAS DE CJTRECORDS
    
    /*  PRE: -
        POST: Anade el tablero s en el hashmap con un recordTablero vacio 
    */
    
    public void anadirTablero (String s) {
        RecordTablero r = new RecordTablero();
        cjt.put(s, r);
    }
    
    /*  PRE: El mapa s existe en el hashmap 
        POST: El record de minimo tiempo del mapa s se actualiza con el 
        jugador id y la puntuacion punt 
    */
    
    public void setRecordTimeTablero(String s, String id, int punt) {
        RecordTablero r = new RecordTablero();
        r = cjt.get(s);
        r.setRecordTiempo(id, punt);
        cjt.put(s, r);
    }
    
    /*  PRE: El mapa s existe en el hashmap 
        POST: El record de primer jugador del mapa s se actualiza con el 
        jugador id
    */
    
    public void setRecordFirstPlayerTablero(String s, String id) {
        RecordTablero r = new RecordTablero();
        r = cjt.get(s);
        r.setRecordJugador(id);
        cjt.put(s, r);
    }
    
    
   /*  PRE: El mapa s existe en el hashmap 
        POST: El record de maxima puntuacion del mapa s se actualiza con el 
        jugador id y la puntuacion punt 
    */
    
    public void setRecordMaxPuntTablero(String s, String id, int punt) {
        RecordTablero r = new RecordTablero();
        r = cjt.get(s);
        r.setRecordPuntuacion(id, punt);
        cjt.put(s, r);
    }
    
    /*  PRE: -
        POST: Elimina el elemento s del hashmap en caso de que exista
    */
    
    public void eliminarTablero (String s) {
        cjt.remove(s);
    }

    public HashMap<String, RecordTablero> getRecords() {
       return this.cjt;
    }
}

