/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dominio.Estructuras;

/**
 *
 * @author Marcel
 */
public class PairRecord{
    private String idjugador;
    private int puntuacion;
    
/* CONSTRUCTORAS PAIR */
    
    //PRE: -
    //POST: Crea un objecte pairRecord 
    
    public PairRecord () {
        idjugador = null;
        puntuacion = 0;
    }
    
    //PRE: -
    //POST: Crea un pairRecord con los parametros this.first = first y this.puntuacion = puntuacion 
    
    public PairRecord(String idjugador, int puntuacion) {
        this.idjugador = idjugador;
        this.puntuacion = puntuacion;
    }
    
    /* CONSULTORAS PAIR */
    
        //PRE: - 
    //POST: Devuelve idJugador del record de un tablero
    public String getIdJugador() {
        return idjugador;
    }
    
    //PRE: - 
    //POST: Devuelve la puntuacion del record de un tablero
    public int getPuntuacion() {
        return puntuacion;
    }
    
    //PRE: - 
    //POST: Devuelve si existe un jugador con ese record en ese tablero
    public boolean exists() {
        if (idjugador == null) return false;
        else return true;
    }
    
    /* MODIFICADORAS PAIR */
   
    
    //PRE: - 
    //POST: Se modifica el valor de idJugador atribuyendole el parametro de entrada idjugador 
    public void setIdJugador(String idjugador) {
        this.idjugador = idjugador;
    }
    
    //PRE: - 
    //POST: Se modifica el valor de puntuacion atribuyendole el parametro de entrada puntuacion
    public void setPuntuacion(int puntuacion) {
        this.puntuacion = puntuacion;
    }
    
}
