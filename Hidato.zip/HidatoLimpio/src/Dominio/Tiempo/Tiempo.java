package Dominio.Tiempo;

/**
 *
 * @author Hamid Latif
 */
public class Tiempo {
    int Segundos;
    int Minutos;
    int Horas;
    long time = 0;
    public Tiempo () {
        time = System.currentTimeMillis();
    }
}
