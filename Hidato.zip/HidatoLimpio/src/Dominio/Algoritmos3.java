/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dominio;
import Dominio.Estructuras.TableroHidato;
import Dominio.Estructuras.Pair;
import static java.util.Arrays.sort;
import java.util.*;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Queue;

/**
 *
 * @author Hamid Latif
 * Colaborador: Marcel Arroyo Pinar
 * Colaborador: RaÃºl IbÃ¡Ã±ez
 * Colaborador: Marc Barrio Ruiz
 */

public class Algoritmos3 {
    
    private static int casillaMin,casillaMax,numNoUsables, tamano;
    private static final TableroHidato tableroOriginal = new TableroHidato();
    private static TableroHidato tableroSolucionado;
    private int mapaAux[][];
    private static boolean BFS;
    private static int nIt = 1;
    
    
    
    
    
    public boolean resolver(TableroHidato t, boolean solucionBfs) {
        
        BFS = solucionBfs;
        
        tableroOriginal.copia(t);
        
        if (this.validarTablero(t) == false) return false;
        
        int[] llaves = t.getKeys();
        sort(llaves);
        
        if (solucionBfs == false) return false;
        
        else {
            calcularMapaAux(t);
            for (int i = 0; i < llaves.length; ++i) {
                Pair casilla = new Pair();
                casilla.setFirst(t.getCoorXPref(llaves[i]));
                casilla.setSecond(t.getCoorYPref(llaves[i]));
                
                calcularCandidatosBFS(t, casilla, i, llaves);
                
                // Aqui ya tengo todos los candidatos;
                
                boolean b =  backtrack(t);
                if (b == true) {
                    return true;
                }
                else {
                    t.copia(tableroOriginal);
                    return false;
                }
            }
        }
        return false;
    }
    
    private void calcularCandidatosBFS(TableroHidato tAux, Pair cas, int posicion, int[] llaves) {
        
        for (int i = 0; i < tamano; ++i) {
            for (int j = 0; j < tamano; ++j) {
                tAux.getCasilla(i, j).setCan(1);
                tAux.getCasilla(i,j).delCan(1);
            }
        }
        for(int i = 0; i < (llaves.length - 1); ++i) {
            calcularCandidatosPalante(llaves[i],llaves[i+1],tAux);
            calcularCandidatosPatras(llaves[i+1],llaves[i],tAux);
        }
        HashSet<Integer> auxSetCandidatos = new HashSet<>();
        for (int i = 1; i <= casillaMax; ++i) {
            auxSetCandidatos.add(i);
        }
        
        for (int i = 0; i < tamano; ++i) {
            for (int j = 0; j < tamano; ++j) {
                if (tAux.getValor(i, j) != 0) {
                    tAux.getCasilla(i,j).delCan(1);
                    tAux.getCasilla(i, j).setCandidatos(auxSetCandidatos);
                }
            }
        }
    }
    
    private void calcularCandidatosPalante (int x, int x2, TableroHidato t) {
        
        int distMax = x2 - (x + 1);
        int dists[][] = new int[tamano][tamano];
        
        distanciaCasillas(x,distMax,t,dists);
        
        for (int i = 0; i < tamano; ++i) {
            for (int j = 0; j < tamano; ++j) {
                
                if (dists[i][j] == 0) {
                    // Si no llego le quito los candidatos que no puede tener
                    // segun estas distancias.
                    for (int e = x+1; e < x2; ++e) t.getCasilla(i,j).delCan(e);
                    
                }
                
                if (dists[i][j] > 0) {
                    // Si llego le pongo los candidatos que puede tener
                    // segun las distancias
                    for (int k = dists[i][j]; k < x2-x; ++k) {
                        
                        HashSet<Integer> sAux = new HashSet<>();
                        Iterator<Integer> itAux = t.getCasilla(i,j).getCandidatos().iterator();
                        for (int aux = 0; aux < t.getCasilla(i,j).getNumCan();++aux) sAux.add(itAux.next());
                        sAux.add(x+k);
                        t.getCasilla(i, j).setCandidatos(sAux);
                        
                    }
                }
            }
        }
    }
    
    private void distanciaCasillas(int n, int d, TableroHidato t, int dists[][]) {
        
        Pair posInit = new Pair();
        posInit.setFirst(t.getCoorXPref(n));
        posInit.setSecond(t.getCoorYPref(n));
        
        Queue<Pair> qPos = new LinkedList<>();
        qPos.add(posInit);
        
        int dist = 1;
        boolean vecRecorridas[][] = new boolean[tamano][tamano];
        for (int i = 0; i < tamano; ++i) {
            for (int j = 0; j < tamano; ++j) {
                vecRecorridas[i][j] = false;
            }
        }
        for (int i = 0; i < tamano; ++i) {
            for (int j = 0; j < tamano; ++j) {
                dists[i][j] = -1;
            }
        }
        
        while(qPos.isEmpty() == false) {

            Pair posActual = qPos.remove();

            boolean arriba = (posActual.getFirst() - 1 >= 0);
            boolean abajo = (posActual.getFirst() + 1 < tamano);
            boolean izquierda = (posActual.getSecond() - 1 >= 0);
            boolean derecha = (posActual.getSecond() + 1 < tamano);

            if (arriba) {
                if (t.getCasilla(posActual.getFirst()-1,
                        posActual.getSecond()).esUsable() &&
                        t.getCasilla(posActual.getFirst()-1,
                        posActual.getSecond()).isPrefijada() == false) {
                    
                        Pair posAux = new Pair();
                        posAux.setFirst(posActual.getFirst()-1);
                        posAux.setSecond(posActual.getSecond());
                        distImmersiva(posAux,dist,d,t,vecRecorridas,dists);
                }

                if (derecha) {
                    if (t.getCasilla(posActual.getFirst()-1,
                        posActual.getSecond()+1).esUsable() &&
                        t.getCasilla(posActual.getFirst()-1,
                        posActual.getSecond()+1).isPrefijada() == false) {

                        Pair posAux = new Pair();
                        posAux.setFirst(posActual.getFirst()-1);
                        posAux.setSecond(posActual.getSecond()+1);
                        distImmersiva(posAux,dist,d,t,vecRecorridas,dists);
                    }
                }
                if (izquierda) {
                    if (t.getCasilla(posActual.getFirst()-1,
                        posActual.getSecond()-1).esUsable() &&
                        t.getCasilla(posActual.getFirst()-1,
                        posActual.getSecond()-1).isPrefijada() == false) {

                        Pair posAux = new Pair();
                        posAux.setFirst(posActual.getFirst()-1);
                        posAux.setSecond(posActual.getSecond()-1);
                        distImmersiva(posAux,dist,d,t,vecRecorridas,dists);;

                    }
                }
            }

            if (abajo) {
                if (t.getCasilla(posActual.getFirst()+1,
                        posActual.getSecond()).esUsable() &&
                        t.getCasilla(posActual.getFirst()+1,
                        posActual.getSecond()).isPrefijada() == false) {

                        Pair posAux = new Pair();
                        posAux.setFirst(posActual.getFirst()+1);
                        posAux.setSecond(posActual.getSecond());
                        distImmersiva(posAux,dist,d,t,vecRecorridas,dists);

                }

                if (derecha) {

                    if (t.getCasilla(posActual.getFirst()+1,
                        posActual.getSecond()+1).esUsable() &&
                        t.getCasilla(posActual.getFirst()+1,
                        posActual.getSecond()+1).isPrefijada() == false) {

                        Pair posAux = new Pair();
                        posAux.setFirst(posActual.getFirst()+1);
                        posAux.setSecond(posActual.getSecond()+1);
                        distImmersiva(posAux,dist,d,t,vecRecorridas,dists);

                    }
                }
                if (izquierda) {
                    if (t.getCasilla(posActual.getFirst()+1,
                        posActual.getSecond()-1).esUsable() &&
                        t.getCasilla(posActual.getFirst()+1,
                        posActual.getSecond()-1).isPrefijada() == false) {

                        Pair posAux = new Pair();
                        posAux.setFirst(posActual.getFirst()+1);
                        posAux.setSecond(posActual.getSecond()-1);
                        distImmersiva(posAux,dist,d,t,vecRecorridas,dists);

                    }
                }
            }

            if (derecha) {
                if (t.getCasilla(posActual.getFirst(),
                        posActual.getSecond()+1).esUsable() &&
                        t.getCasilla(posActual.getFirst(),
                        posActual.getSecond()+1).isPrefijada() == false) {

                        Pair posAux = new Pair();
                        posAux.setFirst(posActual.getFirst());
                        posAux.setSecond(posActual.getSecond()+1);
                        distImmersiva(posAux,dist,d,t,vecRecorridas,dists);

                }
            }

            if (izquierda) {
                if (t.getCasilla(posActual.getFirst(),
                        posActual.getSecond()-1).esUsable() &&
                        t.getCasilla(posActual.getFirst(),
                        posActual.getSecond()-1).isPrefijada() == false) {

                        Pair posAux = new Pair();
                        posAux.setFirst(posActual.getFirst());
                        posAux.setSecond(posActual.getSecond()-1);
                        distImmersiva(posAux,dist,d,t,vecRecorridas,dists);

                }
            }
        }
    }
    
    private void distImmersiva(Pair p, int d, int max, TableroHidato t, boolean rec[][], int dists[][]) {
        
        if (d <= max) {
            
            dists[p.getFirst()][p.getSecond()] = d;
            rec[p.getFirst()][p.getSecond()] = true;
            
            Queue<Pair> qPos = new LinkedList<>();
            qPos.add(p);
            
            while(qPos.isEmpty() == false) {

                Pair posActual = qPos.remove();
                
                boolean arriba = (posActual.getFirst() - 1 >= 0);
                boolean abajo = (posActual.getFirst() + 1 < tamano);
                boolean izquierda = (posActual.getSecond() - 1 >= 0);
                boolean derecha = (posActual.getSecond() + 1 < tamano);
                
                if (arriba) {
                    
                    if (t.getCasilla(posActual.getFirst()-1,
                            posActual.getSecond()).esUsable() &&
                            t.getCasilla(posActual.getFirst()-1,
                            posActual.getSecond()).isPrefijada() == false) {

                        Pair posAux = new Pair();
                        posAux.setFirst(posActual.getFirst()-1);
                        posAux.setSecond(posActual.getSecond());

                        if (dists[posAux.getFirst()][posAux.getSecond()] > d+1 ||
                                dists[posAux.getFirst()][posAux.getSecond()] == -1){

                            distImmersiva(posAux,d+1,max,t,rec,dists);
                        }
                    }

                    if (derecha) {
                        if (t.getCasilla(posActual.getFirst()-1,
                            posActual.getSecond()+1).esUsable() &&
                            t.getCasilla(posActual.getFirst()-1,
                            posActual.getSecond()+1).isPrefijada() == false) {

                            Pair posAux = new Pair();
                            posAux.setFirst(posActual.getFirst()-1);
                            posAux.setSecond(posActual.getSecond()+1);

                            if (dists[posAux.getFirst()][posAux.getSecond()] > d+1 ||
                                    dists[posAux.getFirst()][posAux.getSecond()] == -1){

                                distImmersiva(posAux,d+1,max,t,rec,dists);
                            }
                        }
                    }
                    if (izquierda) {
                        if (t.getCasilla(posActual.getFirst()-1,
                            posActual.getSecond()-1).esUsable() &&
                            t.getCasilla(posActual.getFirst()-1,
                            posActual.getSecond()-1).isPrefijada() == false) {

                            Pair posAux = new Pair();
                            posAux.setFirst(posActual.getFirst()-1);
                            posAux.setSecond(posActual.getSecond()-1);

                            if (dists[posAux.getFirst()][posAux.getSecond()] > d+1 ||
                                    dists[posAux.getFirst()][posAux.getSecond()] == -1) {

                                distImmersiva(posAux,d+1,max,t,rec,dists);
                            }
                        }
                    }
                }

                if (abajo) {
                    
                    if (t.getCasilla(posActual.getFirst()+1,
                            posActual.getSecond()).esUsable() &&
                            t.getCasilla(posActual.getFirst()+1,
                            posActual.getSecond()).isPrefijada() == false) {

                        Pair posAux = new Pair();
                        posAux.setFirst(posActual.getFirst()+1);
                        posAux.setSecond(posActual.getSecond());

                        if (dists[posAux.getFirst()][posAux.getSecond()] > d+1 ||
                                dists[posAux.getFirst()][posAux.getSecond()] == -1){

                            distImmersiva(posAux,d+1,max,t,rec,dists);
                        }

                    }

                    if (derecha) {
                        if (t.getCasilla(posActual.getFirst()+1,
                            posActual.getSecond()+1).esUsable() &&
                            t.getCasilla(posActual.getFirst()+1,
                            posActual.getSecond()+1).isPrefijada() == false) {

                            Pair posAux = new Pair();
                            posAux.setFirst(posActual.getFirst()+1);
                            posAux.setSecond(posActual.getSecond()+1);

                            if (dists[posAux.getFirst()][posAux.getSecond()] > d+1 ||
                                    dists[posAux.getFirst()][posAux.getSecond()] == -1){

                                distImmersiva(posAux,d+1,max,t,rec,dists);
                            }

                        }
                    }
                    if (izquierda) {
                        if (t.getCasilla(posActual.getFirst()+1,
                            posActual.getSecond()-1).esUsable() &&
                            t.getCasilla(posActual.getFirst()+1,
                            posActual.getSecond()-1).isPrefijada() == false) {

                            Pair posAux = new Pair();
                            posAux.setFirst(posActual.getFirst()+1);
                            posAux.setSecond(posActual.getSecond()-1);

                            if (dists[posAux.getFirst()][posAux.getSecond()] > d+1 ||
                                    dists[posAux.getFirst()][posAux.getSecond()] == -1){

                                distImmersiva(posAux,d+1,max,t,rec,dists);
                            }

                        }
                    }
                }

                if (derecha) {
                    if (t.getCasilla(posActual.getFirst(),
                            posActual.getSecond()+1).esUsable() &&
                            t.getCasilla(posActual.getFirst(),
                            posActual.getSecond()+1).isPrefijada() == false) {
                        
                        Pair posAux = new Pair();
                        posAux.setFirst(posActual.getFirst());
                        posAux.setSecond(posActual.getSecond()+1);

                        if (dists[posAux.getFirst()][posAux.getSecond()] > d+1 ||
                                dists[posAux.getFirst()][posAux.getSecond()] == -1){

                            distImmersiva(posAux,d+1,max,t,rec,dists);
                        }
                    }
                }

                if (izquierda) {
                    if (t.getCasilla(posActual.getFirst(),
                            posActual.getSecond()-1).esUsable() &&
                            t.getCasilla(posActual.getFirst(),
                            posActual.getSecond()-1).isPrefijada() == false) {

                        Pair posAux = new Pair();
                        posAux.setFirst(posActual.getFirst());
                        posAux.setSecond(posActual.getSecond()-1);

                        if (dists[posAux.getFirst()][posAux.getSecond()] > d+1 ||
                                dists[posAux.getFirst()][posAux.getSecond()] == -1){

                            distImmersiva(posAux,d+1,max,t,rec,dists);
                        }
                    }
                }
            }
        }
    }
    
    private void calcularCandidatosPatras (int x, int x2, TableroHidato t) {
        
        int distMax = x - (x2 + 1);
        int dists[][] = new int[tamano][tamano];
                
        distanciaCasillas(x,distMax,t,dists);
        
        for (int i = 0; i < tamano; ++i) {
            for (int j = 0; j < tamano; ++j) {
                if (dists[i][j] < 1) {
                    // Quito los candidatos que no llego por distancia, es decir
                    // Todos ente x y x2.
                    for (int e = x-1; e > x2; --e){
                        t.getCasilla(i,j).delCan(e);
                    }
                }
                if (dists[i][j] > 0) {
                    // Quito los candidatos que no llegue por distancia.
                    if (dists[i][j] > 1) {
                        for (int y = 0; y <= (x - (x - dists[i][j] +1));++y) {
                            t.getCasilla(i, j).delCan(x-y);
                        }
                    }
                    
                    Set<Integer> sAux = new HashSet<>();
                    for (int k = dists[i][j]; k > x-(x2+1); ++k) {
                        sAux.add(x-k);
                    }
                    
                    Iterator<Integer> itAux1 = sAux.iterator();
                    Iterator<Integer> itAux2 = t.getCasilla(i,j).getCandidatos().iterator();
                    
                    for (int z = 0; z < t.getCasilla(i,j).getNumCan();++z) {
                        
                        int aux = itAux2.next(); // candidatos de la casilla
                        
                        if (aux > x2 && aux < x) {
                            
                            boolean encontrado = false;
                            
                            for (int m = 0; m < sAux.size(); ++m) {
                                int aux2 = itAux1.next();
                                if (aux == aux2) {
                                    encontrado = true;
                                }
                            }
                            
                            if (encontrado = false) {
                                t.getCasilla(i,j).delCan(aux);
                            }
                        }
                    }
                }
            }
        }
    }
    
    private boolean validarTablero(TableroHidato t){
        
        if (hayAlgunaNoPref(tableroOriginal) == false) return false;
        
        tamano = t.getTamano();
        
        casillaMin = 2;
        
        casillaMax = 2;
        
        numNoUsables = 0;
                
        for (int i = 0; i < t.getTamano();++i) {
            for (int j = 0; j < t.getTamano();++j) {
                if (t.getPrefijada(i, j)) {
                    if (t.getValor(i, j) > casillaMax) casillaMax = t.getValor(i,j);
                    else if (t.getValor(i,j) < casillaMin) casillaMin = t.getValor(i,j);
                }
                else if (t.getUsabilidad(i, j) == false) numNoUsables++;
            }
        }
        // Si la casilla prefijada minima no es 1 esta mal.
        if (casillaMin != 1) return false;
        
        // Si la casilla prefijada maxima no es el numero de casillas
        // usables esta mal.
        
        if (casillaMax != ((t.getTamano() * t.getTamano()) - numNoUsables)) return false;
        
        // Miro que una casilla no esta rodeada por casillas no usables y
        // miro que si una casilla solo tiene una casilla usable cercana
        // que esa casilla sea la inicial o la final.
        
        //System.out.println(" # Miro que una casilla no estÃ© aislada #");
        
        for (int i = 0; i < tamano; ++i) {
            for (int j = 0; j < tamano; ++j) {
                if (this.mirarCercanas(i,j,tableroOriginal) == 0) {
                    return false;
                }
                else if ((this.mirarCercanas(i,j,tableroOriginal) == 1) &&
                        (t.getCasilla(i, j).isPrefijada() == true && 
                        (t.getValor(i,j) != casillaMin &&
                        (t.getValor(i,j) != casillaMax)))) {
                    return false;
                }
            }
        }
        
        if (distanciasCorrectas(tableroOriginal) == false) {
            //System.out.println("distancias incorrectas");
            return false;
        }
        //System.out.println("distancias correctas");
        
        if (calcularTodosLosCaminos() == false) {
            //System.out.println("todos los caminos mal");
            return false;
        }
        //System.out.println("Todos los caminos bien");
        
        return prefijadasNoRepetidas(tableroOriginal);
        
    }
    
    private boolean hayAlgunaNoPref(TableroHidato t){
        
        for (int i = 0; i < t.getTamano(); ++i) {
            for (int j = 0; j < t.getTamano(); ++j) {
                if (t.getValor(i, j) == 0) return true;
            }
        }
        
        return false;
        
    }
    
    private boolean distanciasCorrectas(TableroHidato t) {
        
        int pref[] = new int[t.getTamano()];
        
        pref = t.getKeys();
        
        for (int i = 0; i < pref.length - 1; ++i) {
            
            int act = pref[i];
            
            if (distanciaCasillas(pref[i], pref[i+1],t) == false) {
                return false;
            }
            
        }
        
        return true;
    }
    
    private boolean distanciaCasillas(int x, int x2, TableroHidato t) {
        
        //System.out.println("miro las distancias entre "+x+" y "+x2);
        
        int distancia = x2 - x;
        
        if (x > x2) distancia = x - x2;
        
        Pair pos = t.getCoordPref(x);
        
        Pair pos2 = t.getCoordPref(x2);
        
        int recorrido[][] = new int[t.getTamano()][t.getTamano()];
        
        for (int i = 0; i < t.getTamano(); ++i) {
            for (int j = 0; j < t.getTamano(); ++j) {
                recorrido[i][j] = t.getTamano() * t.getTamano() + 1;
            }
        }
        
        getDistancia(pos, pos2, t, recorrido, 1);
        
        if (recorrido[pos2.getFirst()][pos2.getSecond()] > distancia) {
            //System.out.println("fallan las distancias entre "+x+" y "+x2+" .");
            return false;
        }
        else {
            //System.out.println("Las distancias entre +x+ y +x2+ son correctas.");
            //System.out.println("distancia matemática: "+distancia);
            //System.out.println("distancia bfs: "+recorrido[pos2.getFirst()][pos2.getSecond()]);
        }
        
        return true;
    }
    
    private void getDistancia(Pair p, Pair p2, TableroHidato t, int[][] recorrido, int dist) {
        
        boolean arriba = p.getFirst() - 1 >= 0;
        boolean abajo = p.getFirst() + 1 < t.getTamano();
        boolean derecha = p.getSecond() + 1 < t.getTamano();
        boolean izquierda = p.getSecond() - 1 >= 0;

        Pair aux = new Pair();
        if (((p.getFirst() == p2.getFirst()) && (p.getSecond() == p2.getSecond())) == false) {
            if (arriba) {
                // arriba
                aux.setFirst(p.getFirst() - 1);
                aux.setSecond(p.getSecond());
                if (recorrido[aux.getFirst()][aux.getSecond()] > dist) {
                    recorrido[aux.getFirst()][aux.getSecond()] = dist;
                    getDistancia(aux,p2,t,recorrido,dist+1);
                }
                if (derecha) {
                    // arriba-derecha
                    aux.setFirst(p.getFirst() - 1);
                    aux.setSecond(p.getSecond() + 1);
                    if (recorrido[aux.getFirst()][aux.getSecond()] > dist) {
                        recorrido[aux.getFirst()][aux.getSecond()] = dist;
                        getDistancia(aux,p2,t,recorrido,dist+1);
                    }
                }
                if (izquierda) {
                    // arriba-izquierda
                    aux.setFirst(p.getFirst() - 1);
                    aux.setSecond(p.getSecond() - 1);
                    if (recorrido[aux.getFirst()][aux.getSecond()] > dist) {
                        recorrido[aux.getFirst()][aux.getSecond()] = dist;
                        getDistancia(aux,p2,t,recorrido,dist+1);
                    }
                }
            }
            if (abajo) {
                // abajo
                aux.setFirst(p.getFirst() + 1);
                aux.setSecond(p.getSecond());
                if (recorrido[aux.getFirst()][aux.getSecond()] > dist) {
                    recorrido[aux.getFirst()][aux.getSecond()] = dist;
                    getDistancia(aux,p2,t,recorrido,dist+1);
                }
                if (derecha) {
                    // abajo-derecha
                    aux.setFirst(p.getFirst() + 1);
                    aux.setSecond(p.getSecond() + 1);
                    if (recorrido[aux.getFirst()][aux.getSecond()] > dist) {
                        recorrido[aux.getFirst()][aux.getSecond()] = dist;
                        getDistancia(aux,p2,t,recorrido,dist+1);
                    }
                }
                if (izquierda) {
                    // abajo-izquierda
                    aux.setFirst(p.getFirst() + 1);
                    aux.setSecond(p.getSecond() - 1);
                    if (recorrido[aux.getFirst()][aux.getSecond()] > dist) {
                        recorrido[aux.getFirst()][aux.getSecond()] = dist;
                        getDistancia(aux,p2,t,recorrido,dist+1);
                    }
                }
            }
            if (derecha) {
                // derecha
                aux.setFirst(p.getFirst());
                aux.setSecond(p.getSecond() + 1);
                if (recorrido[aux.getFirst()][aux.getSecond()] > dist) {
                    recorrido[aux.getFirst()][aux.getSecond()] = dist;
                    getDistancia(aux,p2,t,recorrido,dist+1);
                }
            }
            if (izquierda) {
                // izquierda
                aux.setFirst(p.getFirst());
                aux.setSecond(p.getSecond() - 1);
                if (recorrido[aux.getFirst()][aux.getSecond()] > dist) {
                    recorrido[aux.getFirst()][aux.getSecond()] = dist;
                    getDistancia(aux,p2,t,recorrido,dist+1);
                }
            }
        }
    }
    
    private int mirarCercanas(int x, int y, TableroHidato t) {
        
        
        if (tableroOriginal.getUsabilidad(x, y) == true) {
            
            int aux = 0;
            boolean arriba = (x-1 >= 0);
            boolean abajo = (x+1 < tableroOriginal.getTamano());
            boolean izquierda = (y-1 >= 0);
            boolean derecha = (y+1 < tableroOriginal.getTamano());

            if (arriba) {

                if (tableroOriginal.getCasilla(x-1,y).esUsable()) 
                    ++aux;
                if (derecha) if (tableroOriginal.getCasilla(x-1,y+1).esUsable()) 
                    ++aux;
                if (izquierda) if (tableroOriginal.getCasilla(x-1,y-1).esUsable()) 
                    ++aux;
                
            }
            if (abajo) {
                
                if (tableroOriginal.getCasilla(x+1,y).esUsable()) 
                    ++aux;
                if (derecha) if (tableroOriginal.getCasilla(x+1,y+1).esUsable()) 
                    ++aux;
                if (izquierda) if (tableroOriginal.getCasilla(x+1,y-1).esUsable())
                    ++aux;
                
            }
            if (izquierda) if (tableroOriginal.getCasilla(x,y-1).esUsable()) ++aux;
            if (derecha) if (tableroOriginal.getCasilla(x,y+1).esUsable()) ++aux;
            return aux;
        }
        return 8;
    }
    
    private void calcularMapaAux(TableroHidato t) {
        mapaAux = new int[t.getTamano()][t.getTamano()];
        for (int i = 0; i < t.getTamano(); ++i) {
            for (int j = 0; j < t.getTamano(); ++j) {
                if (t.getUsabilidad(i, j) && t.getValor(i, j) == 0)  mapaAux[i][j] = -1;
                else mapaAux[i][j] = 0; 
            }
        }
    }
    
    private boolean calcularTodosLosCaminos() {
        
        boolean encontrado = false;
        
        Pair posicion = new Pair();
        posicion.setFirst(tableroOriginal.getCoorXPref(1));
        posicion.setSecond(tableroOriginal.getCoorYPref(1));
        
        Queue<Pair> qPos = new LinkedList<>();
        qPos.add(posicion);
        int tableroDist[][] = new int[tamano][tamano];
        for (int i = 0; i < tamano; ++i) {
            for (int j = 0; j < tamano; ++j) {
                if (i == posicion.getFirst() && j == posicion.getSecond()) 
                    tableroDist[i][j] = 1;
                else if (tableroOriginal.getCasilla(i, j).esUsable() == false) 
                    tableroDist[i][j] = -1;
                else tableroDist[i][j] = 0;
            }
        }
                
        while(qPos.isEmpty() == false) {
            
            Pair posActual = new Pair();
            posActual = qPos.remove();
            
            boolean arriba = (posActual.getFirst() - 1 >= 0);
            boolean abajo = (posActual.getFirst() + 1 < tamano);
            boolean izquierda = (posActual.getSecond() - 1 >= 0);
            boolean derecha = (posActual.getSecond() + 1 < tamano);
            
            Pair posAux = new Pair();
            
            if (arriba) {
                posAux.setFirst(posActual.getFirst() - 1);
                posAux.setSecond(posActual.getSecond());
                if (tableroOriginal.getCasilla(posAux.getFirst(),
                        posAux.getSecond()).esUsable()) {
                    if (tableroDist[posAux.getFirst()][posAux.getSecond()] == 0) {
                        qPos.add(posAux);
                        ++tableroDist[posAux.getFirst()][posAux.getSecond()];
                    }
                }
            }
            posAux = new Pair();
            if (arriba && derecha) {
                posAux.setFirst(posActual.getFirst() - 1);
                posAux.setSecond(posActual.getSecond() +1);
                if (tableroOriginal.getCasilla(posAux.getFirst(),
                        posAux.getSecond()).esUsable()) {
                    if (tableroDist[posAux.getFirst()][posAux.getSecond()] == 0) {
                        qPos.add(posAux);
                        ++tableroDist[posAux.getFirst()][posAux.getSecond()];
                    }
                }
            }
            posAux = new Pair();
            if (arriba && izquierda) {
                posAux.setFirst(posActual.getFirst() - 1);
                posAux.setSecond(posActual.getSecond() - 1);
                if (tableroOriginal.getCasilla(posAux.getFirst(),
                        posAux.getSecond()).esUsable()) {
                    if (tableroDist[posAux.getFirst()][posAux.getSecond()] == 0) {
                        qPos.add(posAux);
                        ++tableroDist[posAux.getFirst()][posAux.getSecond()];
                    }
                }
            }
            posAux = new Pair();
            if (abajo) {
                posAux.setFirst(posActual.getFirst() + 1);
                posAux.setSecond(posActual.getSecond());
                if (tableroOriginal.getCasilla(posAux.getFirst(),
                        posAux.getSecond()).esUsable()) {
                    if (tableroDist[posAux.getFirst()][posAux.getSecond()] == 0) {
                        qPos.add(posAux);
                        ++tableroDist[posAux.getFirst()][posAux.getSecond()];
                    }
                }
            }
            posAux = new Pair();
            if (abajo && derecha) {
                posAux.setFirst(posActual.getFirst() + 1);
                posAux.setSecond(posActual.getSecond() + 1);
                if (tableroOriginal.getCasilla(posAux.getFirst(),
                        posAux.getSecond()).esUsable()) {
                    if (tableroDist[posAux.getFirst()][posAux.getSecond()] == 0) {
                        qPos.add(posAux);
                        ++tableroDist[posAux.getFirst()][posAux.getSecond()];
                    }
                }
            }
            posAux = new Pair();
            if (abajo && izquierda) {
                posAux.setFirst(posActual.getFirst() + 1);
                posAux.setSecond(posActual.getSecond() - 1);
                if (tableroOriginal.getCasilla(posAux.getFirst(),
                        posAux.getSecond()).esUsable()) {
                    if (tableroDist[posAux.getFirst()][posAux.getSecond()] == 0) {
                        qPos.add(posAux);
                        ++tableroDist[posAux.getFirst()][posAux.getSecond()];
                    }
                }
            }
            posAux = new Pair();
            if (derecha) {
                posAux.setFirst(posActual.getFirst());
                posAux.setSecond(posActual.getSecond() + 1);
                if (tableroOriginal.getCasilla(posAux.getFirst(),
                        posAux.getSecond()).esUsable()) {
                    if (tableroDist[posAux.getFirst()][posAux.getSecond()] == 0) {
                        qPos.add(posAux);
                        ++tableroDist[posAux.getFirst()][posAux.getSecond()];
                    }
                }
            }
            posAux = new Pair();
            if (izquierda) {
                posAux.setFirst(posActual.getFirst());
                posAux.setSecond(posActual.getSecond() - 1);
                if (tableroOriginal.getCasilla(posAux.getFirst(),
                        posAux.getSecond()).esUsable()) {
                    if (tableroDist[posAux.getFirst()][posAux.getSecond()] == 0) {
                        qPos.add(posAux);
                        ++tableroDist[posAux.getFirst()][posAux.getSecond()];
                    }
                }
            }
            
        }
        return !encontrado;
    }
    
    private boolean backtrack(TableroHidato t) {
        int candidatosMin = t.getN()*t.getN();
        int contador = 0;
        //miramos el menor nº de candidatos para todas las casillas del mapa (!= 0)
        for (int i = 0; i < t.getN(); ++i) {
            for (int j = 0; j< t.getN(); ++j) {
                if (t.getUsabilidad(i, j) && t.getPrefijada(i, j) == false && t.getNumCan(i, j) < candidatosMin && t.getValor(i, j) == 0) {
                    candidatosMin = t.getNumCan(i, j);
                    contador = 1;
                }
                else if (t.getNumCan(i, j) == candidatosMin) ++contador;
            }
        }
        //para guardarnos las casillas con menor numero de candidatos en un vector
        if (candidatosMin != 0) {
            //vector de pairs para guardar las pos de las casillas
            Pair[] casillasAProbar = new Pair[contador];
            //System.out.println("Tamaño casillasaprobar:" + casillasAProbar.length);
            int k = 0;
            for (int i = 0; i < t.getN(); ++i) {
                for (int j = 0; j < t.getN(); ++j) {
                    if (t.getUsabilidad(i, j) && t.getNumCan(i, j) == candidatosMin && t.getValor(i, j) == 0) {
                        casillasAProbar[k] = new Pair();
                        casillasAProbar[k].setFirst(i);
                        casillasAProbar[k].setSecond(j);
                        ++k;
                    }
                }
            }
            //escogemos una casilla al alzar para empezar el backtracking
            Random rn = new Random();
            int elegido = 0;
            if (contador > 1) elegido = rn.nextInt(contador-1);
            int x = casillasAProbar[elegido].getFirst();
            int y = casillasAProbar[elegido].getSecond();
           // System.out.println("La casilla con menos candidatos para empezar el backtracking es: " + x + " " + y);
            //System.out.println("Empiezo el backtracking con: " + x + " " + y);
            if(backtracking(t, x, y, t)) return true;
            return false;
        }
        return false;
    }
    
    /*  PRE: 0 <= i <= t.getTam(), 0 <= j <= t.getTam()
        POST: Se calcula una solución válida del tablero t
    */
    
    // HAY QUE HACER QUE PRIMERO MIRE DE PONER LOS VALORES QUE SOLO ESTEN EN
    // UNA CASILLA
    
    private boolean backtracking(TableroHidato t, int i, int j, TableroHidato orig) {
        
        // Miro todos los valores que quedan por prefijar esten en mínimo una casilla
        // Miro que todas las casillas tengan candidatos.
        // Miro que no hayan casillas aisladas.
        if (validacionDuranteBacktracking(t) == false) {
            return false;
        }
        
        int[] candidatos = t.consultarCandidatosCasilla(i, j);
        Pair act = new Pair();
        act.setFirst(i);
        act.setSecond(j);
        mapaAux[i][j] = 0;
        for (int x = 0; x < candidatos.length; ++x) {
            boolean iteracionacabada = false;
            TableroHidato copy = new TableroHidato();
            copy.copia(t);
            copy.setValor(candidatos[x], i, j);
            //calcularMapaAux(copy);
            int[] prefijadas = copy.getKeys();
            sort(prefijadas);
            
            int k = 1;
            boolean acabado = false;
            //System.out.println("prefijadas.length = "+prefijadas.length);
            while (k < prefijadas.length && !acabado) {
                if (prefijadas[k] ==  candidatos[x]) {
                    Pair sig = new Pair();
                    sig.setFirst(copy.getCoorXPref(prefijadas[k+1]));
                    sig.setSecond(copy.getCoorYPref(prefijadas[k+1]));
                    acabado = true;
                }
                else ++k;
            }
            
            if (BFS) {
                calcularCandidatosBFS(copy, act, k, prefijadas);
            }
            
            else {
                //todas las casillas prefijadas
                //Pair sig = new Pair();
                //sig.setFirst(t.getCoorXPref(prefijadas[k+1]));
                //sig.setSecond(t.getCoorYPref(prefijadas[k+1]));
                //calcularCandidatos(copy, act, sig);
            }
            
            Pair sig = new Pair();
            int candidatosMin = copy.getN()*copy.getN();
            int contador = 0;
            //miramos el menor nº de candidatos para todas las casillas del mapa (!= 0)
            for (int ii = 0; ii < copy.getN(); ++ii) {
                for (int jj = 0; jj< copy.getN(); ++jj) {
                    if (copy.getUsabilidad(ii, jj) && copy.getNumCan(ii, jj) < candidatosMin && copy.getValor(ii, jj) == 0) {
                        candidatosMin = copy.getNumCan(ii, jj);
                        contador = 1;
                        if (copy.getValor(ii, jj) == 0 && copy.getNumCan(ii, jj) == 0) iteracionacabada = true;
                    }
                    else if (copy.getNumCan(ii, jj) == candidatosMin && copy.getValor(ii, jj) == 0) ++contador;
                }
            }
            //para guardarnos las casillas con menor numero de candidatos en un vector
            if (contador != 0) { //no he encontrado ninguna casilla sin rellenar
                //vector de pairs para guardar las pos de las casillas
                Pair[] casillasAProbar = new Pair[contador];
                k = 0;
                for (int ii = 0; ii < t.getN(); ++ii) {
                    for (int jj = 0; jj < t.getN(); ++jj) {
                        if (copy.getUsabilidad(ii, jj) && copy.getNumCan(ii, jj) == candidatosMin && copy.getValor(ii, jj) == 0) {
                            casillasAProbar[k] = new Pair();
                            casillasAProbar[k].setFirst(ii);
                            casillasAProbar[k].setSecond(jj);
                            ++k;
                        }
                    }
                }
                Random rn = new Random();
                int elegido = 0;
                if (contador > 1) elegido = rn.nextInt(contador-1);
                //escogemos una casilla al alzar para empezar el backtracking
                //System.out.println("elegido = "+elegido);
                //System.out.println("casillasAProbar.sie = "+casillasAProbar.length);
                // Si quito esta linea peta (not joking)
                int xeleg = casillasAProbar[elegido].getFirst();
                int yeleg = casillasAProbar[elegido].getSecond();
                sig.setFirst(xeleg);
                sig.setSecond(yeleg);
            }
            else {
                //int[][] sol = new int[orig.getN()][orig.getN()];
                for (int iii = 0; iii < orig.getN(); ++iii) {
                    for (int jjj = 0; jjj < orig.getN(); ++jjj) {
                        orig.setSolucion(copy.getValor(iii, jjj), iii, jjj);
                    }
                }
                return true;
            }
            if (!iteracionacabada) {
                if ((backtracking(copy, sig.getFirst(), sig.getSecond(), orig))) return true;
            }
        }
        mapaAux[i][j] = -1;
        return false;
    }
        
    // INTENTO DE GENERADOR RECURSIVO //
    
    public TableroHidato generadorTableroRandomRecursivo(TableroHidato t) {
        boolean solucionable = false;    
        TableroHidato copiadoT = new TableroHidato();
        TableroHidato solucion = new TableroHidato();
        while (solucionable == false) {
            try {
                while (solucionable == false) {
                    
                    copiadoT.copia(t);
                    int tam = copiadoT.getN();
                    Random rand = new Random();
                    
                    int anadirPorc1 = 0;
                    
                    if (tam > 6) anadirPorc1 = 5;
                    
                    double porc1 = (double) rand.nextInt(20) + anadirPorc1;
                    
                    
                    int nNoUsables = (int) ((porc1/(double)100) * (tam*tam));
                    /*
                    for (int i = 0; i < nNoUsables; ++i) {
                        int fila = rand.nextInt(tam - 1);
                        int col = rand.nextInt(tam - 1);
                        copiadoT.setUsabilidad(false, fila, col);
                    }*/
                    
                    nNoUsables = 0;
                    /*
                    for (int i = 0; i < tam; ++i) {
                        for (int j = 0; j < tam; ++j) {
                            if (copiadoT.getUsabilidad(i, j) == false) ++nNoUsables;
                        }
                    }*/
                    boolean todoCorrecto = false;
                    
                    casillaMin = 1;
                    casillaMax = (tam*tam) - nNoUsables;
                    
                    
                    Queue<Integer> qCas = new LinkedList<>();
                    
                    for (int i = 1; i <= (tam*tam)-nNoUsables; ++i) {
                        qCas.add(i);
                    }
                    
                    todoCorrecto = ponerCasillasRecursivo(qCas,copiadoT,1,null,nNoUsables);
                    
                    if (todoCorrecto == true) {
                        
                        ponerNoUsables(copiadoT);
                        
                        solucion.copia(copiadoT);
                        
                        quitarCasillas(solucion,nNoUsables);
                        //solucion.dibujarTablero();
                        nIt = 0;
                        solucionable = true;
                        
                    }
                    
                }
            }
            
            catch(ArrayIndexOutOfBoundsException | NoSuchElementException | NullPointerException e) {
                solucionable = false;
                e.printStackTrace();
            }
        }
        
        TableroHidato tSol = new TableroHidato(solucion.getNombreTablero(), solucion.getTamano());
        tSol.setNombreCreador(solucion.getNombreCreador());
        
        for (int i = 0; i < solucion.getTamano(); ++i) {
            for (int j = 0; j < solucion.getTamano(); ++j) {
                if (solucion.getUsabilidad(i, j) == false) tSol.setValor(-1, i, j);
                else tSol.setValor(solucion.getValor(i, j), i, j);
            }
        }
        
        return tSol;
    }
    
    private void ponerNoUsables(TableroHidato t) {
        
        for (int i = 0; i < t.getTamano(); ++i) {
            for (int j = 0; j < t.getTamano(); ++j) {
                
                if (t.getValor(i, j) == 0) {
                    t.setValor(-1, i, j);
                }
                
            }
        }
        
    }
    
    public void quitarCasillas(TableroHidato t, int noUs) {
        
        Random r = new Random();
        
        noUs = 0;
        
        for (int i = 0; i < t.getTamano(); ++i) {
            for (int j = 0; j < t.getTamano(); ++j) {
                if (t.getUsabilidad(i, j) == false) ++noUs;
            }
        }
        
        int max = (t.getTamano()*t.getTamano()) - noUs;
        int tam = t.getTamano();
        int anadirPorc2 = 0;
        
        if (tam > 6) anadirPorc2 = 20;
        
        double porc2 = (double) r.nextInt(40) + anadirPorc2;
        
        for (int i = 0; i < t.getTamano(); ++i) {
            for (int j = 0; j < t.getTamano(); ++j) {
                if (t.getValor(i, j) != 1 && t.getValor(i,j) != max && t.getUsabilidad(i, j)) {
                    int aux = r.nextInt(101);
                    if (aux > porc2) t.setValor(0, i, j);
                }
            }
        }
    }
    
    private double porcentajePuestas (TableroHidato t) {
        
        int puestas = 0;
        
        for (int i = 0; i < t.getTamano(); ++i) {
            for (int j = 0; j < t.getTamano(); ++j) {
                if (t.getPrefijada(i, j)) ++puestas;
            }
        }
        
        return (100*(double)((double) puestas / ((double)t.getTamano()*t.getTamano())));
        
    }
    
    private boolean ponerCasillasRecursivo(Queue<Integer> qCas, TableroHidato t,
            int casAnt, Pair posAnt, int nNoUsables) {
        
        // En qCas tengo los valores de las casillas que seran prefijadas.
        
        // La primera casilla que hay es la siguiente al 1.
        
        // La ultima casilla de qCas es la casilla maxima.
        
        // Tengo que calcular (excepto para el 1) todas las posiciones 
        // que puede tener la siguiente prefijada y elegir una al azar.
        // Una vez hecho y sin quitar el resto de posiciones, tengo que hacer
        // lo mismo para el resto de casillas y una vez puesta la ultima.
        // Si es solucionable devuelvo el tablero y en el caso contrario
        // lo intento con la siguiente posicion.
                
        if (mirarConexo(t,casAnt) == false) {
            if (t.getTamano() > 6) {
                if (porcentajePuestas(t) > 65) {
                    Random rand = new Random();
                    if (rand.nextInt(100) > 70) {
                        return true;
                    }
                    else return false;
                }
                else {
                    return false;
                }
            }
            else {
                if (porcentajePuestas(t) > 80) {
                    Random rand = new Random();
                    if (rand.nextInt(100) > 70) {
                        return true;
                    }
                    else return false;
                }
                else {
                    return false;
                }
            }
        }
        
        if (qCas.isEmpty()) {
            //System.out.println("qCas esta vacio asi que voy  resolver este tablero:");
            //t.dibujarTablero();
            ++nIt;
            //System.out.println("FINAL");
            //System.out.println(nIt);
            return true;
        }
        else {
            //System.out.println("Entro en la recursividad y soy la casilla con valor: "+qCas.element());
            int casillaActual = qCas.poll();

            Queue<Pair> qPos = new LinkedList<>();

            // Si es la casilla 1 le pongo todas las posiciones posibles.
            if (casillaActual == 1) {
                for (int i = 0; i < t.getTamano(); ++i) {
                    for (int j = 0; j < t.getTamano(); ++j) {
                        if ((t.getUsabilidad(i, j)) && (t.getPrefijada(i, j) == false)) {
                            Pair aux = new Pair();
                            aux.setFirst(i);
                            aux.setSecond(j);
                            qPos.add(aux);
                        }
                    }
                }
                //System.out.println("Como soy el 1 me he puesto todas las pocisiciones.");
            }
            // Si es otra casilla tengo que calcular que posiciones puede tener.
            else {
                //System.out.println("Soy el "+casillaActual+" y mi anterior es "+casAnt);
                int distMax = (casillaActual - casAnt);
                calcularPorBFS(posAnt,distMax,t,qPos);
            }

            // Ahora en qPos tengo todas las posiciones posibles para
            // 'casillaActual', asi que tengo que elegir un valor
            // al azar y probar suerte.
            
            boolean acabado = false;
            while (qPos.isEmpty() == false && acabado == false) {

                //t.dibujarTablero();
                
                Pair posicionCasilla = new Pair();
                Random rand = new Random();
                int index = 0;
                
                if (qPos.size() > 1) {

                    index = rand.nextInt(qPos.size() - 1);
                    // 0 <= index <= (qPos.size() - 1)
                    // index tiene la posicion de qPos que contiene la posicion
                    // que vamos a probar.

                    for (int i = 0; i < index; ++i) qPos.add(qPos.poll());
                    // Hemos quitado 'index' posiciones de la cola que hemos movido
                    // al final de esta.
                    
                    posicionCasilla = qPos.poll();

                }
                else posicionCasilla = qPos.poll();

                // ahora qPos tiene un elemento menos que tenemos en
                // posicionCasilla
                
                TableroHidato tCopia = new TableroHidato();
                tCopia.copia(t);
                tCopia.setValor(casillaActual, posicionCasilla.getFirst(), posicionCasilla.getSecond());
                
                /*
                for (int x = 0; x < tCopia.getTamano(); ++x) {
                    for (int y = 0; y < tCopia.getTamano(); ++y) {
                        if (mirarCercanas(x,y,tCopia) == 0) return false;
                        else if (mirarCercanas(x,y,tCopia) == 1 &&
                                (t.getValor(x, y) != casillaMax &&
                                t.getValor(x, y) != casillaMin)) return false;
                    }
                }*/
                
                Queue<Integer> qCasCopia = new LinkedList<>(qCas);
                
                acabado = ponerCasillasRecursivo(qCasCopia, tCopia,
                        casillaActual, posicionCasilla, nNoUsables);
                
                if (acabado == true) {
                    //System.out.println("La iteracion ha sido correcta.");
                    //System.out.println("Este es t");
                    //t.dibujarTablero();
                    //System.out.println("Esta es su copia");
                    //tCopia.dibujarTablero();
                    //System.out.println("Ahora t es la copia");
                    t.copia(tCopia);
                    return true;
                }
                
            }
        }
        return false;
    }
    
    public boolean mirarConexo(TableroHidato t, int casilla) {
        
        //System.out.println("miro conexo para el "+casilla);
        
        Pair posCasilla = new Pair();
        
        for (int i = 0; i < t.getTamano(); ++i) {
            for (int j = 0; j < t.getTamano(); ++j) {
                if (t.getValor(i, j) == casilla) {
                    posCasilla.setFirst(i);
                    posCasilla.setSecond(j);
                }
            }
        }
        
        boolean recorrido[][] = new boolean[t.getTamano()][t.getTamano()];
        
        recorrerTablero(t,posCasilla, recorrido);
        
        boolean solucio = false;
        
        /*
        for (int i = 0; i < recorrido.length; ++i) {
            System.out.print("##");
            for (int j = 0; j < recorrido.length; ++j) {
                if (recorrido[i][j] == true) System.out.print("1 ");
                if (recorrido[i][j] == false) System.out.print("0 ");
            }
            System.out.print("\n");
        }*/
        
        for (int i = 0; i < recorrido.length; ++i) {
            for (int j = 0; j < recorrido.length; ++j) {
                if (recorrido[i][j] == false) {
                    if (t.getUsabilidad(i, j) == true) {
                        if (t.getPrefijada(i, j) == false) {
                            //System.out.println("fallo en ("+i+","+j+")");
                            return false;
                        }
                    }
                }
            }
        }
        
        return true;
    }
    
    public void recorrerTablero(TableroHidato t, Pair posActual, boolean recorrido[][]) {
        
        //System.out.println("pongo ("+posActual.getFirst()+","+posActual.getSecond()+") a true");
        
        recorrido[posActual.getFirst()][posActual.getSecond()] = true;
        
        /*
        for (int i = 0; i < recorrido.length; ++i) {
            System.out.print("##");
            for (int j = 0; j < recorrido.length; ++j) {
                if (recorrido[i][j] == true) System.out.print("1 ");
                if (recorrido[i][j] == false) System.out.print("0 ");
            }
            System.out.print("\n");
        }
        */
        boolean arriba = (posActual.getFirst() - 1 >= 0);
        boolean abajo = (posActual.getFirst() + 1 < t.getN());
        boolean izquierda = (posActual.getSecond() - 1 >= 0);
        boolean derecha = (posActual.getSecond() + 1 < t.getN());
        
        /*
        System.out.println("top: "+String.valueOf(arriba));
        System.out.println("right: "+String.valueOf(derecha));
        System.out.println("left: "+String.valueOf(izquierda));
        System.out.println("bottom: "+String.valueOf(abajo));
        */
        Pair posAux = new Pair();
        
        if (arriba) {
            //Top (i-1)
            posAux.setFirst(posActual.getFirst() - 1);
            posAux.setSecond(posActual.getSecond());
            if (t.getUsabilidad(posAux.getFirst(), posAux.getSecond()) == true) {
                if (t.getPrefijada(posAux.getFirst(), posAux.getSecond()) == false) {
                    if (recorrido[posAux.getFirst()][posAux.getSecond()] == false)
                        recorrerTablero(t,posAux,recorrido);
                }
            }
            
            //TOP RIGHT (i-1, j+1)
            if (derecha){
                posAux.setFirst(posActual.getFirst() - 1);
                posAux.setSecond(posActual.getSecond() + 1);
                if (t.getUsabilidad(posAux.getFirst(), posAux.getSecond()) == true) {
                    if (t.getPrefijada(posAux.getFirst(), posAux.getSecond()) == false) {
                        if (recorrido[posAux.getFirst()][posAux.getSecond()] == false)
                        recorrerTablero(t,posAux,recorrido);
                    }
                }
            }
            
            //TOP LEFT (i-1, j-1)
            if (izquierda) {
                posAux.setFirst(posActual.getFirst() - 1);
                posAux.setSecond(posActual.getSecond() - 1);
                if (t.getUsabilidad(posAux.getFirst(), posAux.getSecond()) == true) {
                    if (t.getPrefijada(posAux.getFirst(), posAux.getSecond()) == false) {
                        if (recorrido[posAux.getFirst()][posAux.getSecond()] == false)
                        recorrerTablero(t,posAux,recorrido);
                    }
                }
            }
        }
        
        if (abajo) {
            //BOT (i+1)
            posAux.setFirst(posActual.getFirst() + 1);
            posAux.setSecond(posActual.getSecond());
            if (t.getUsabilidad(posAux.getFirst(), posAux.getSecond()) == true) {
                if (t.getPrefijada(posAux.getFirst(), posAux.getSecond()) == false) {
                    if (recorrido[posAux.getFirst()][posAux.getSecond()] == false)
                        recorrerTablero(t,posAux,recorrido);
                }
            }
            
            //BOT RIGHT (i+1,j+1)
            if (derecha) {
                posAux.setFirst(posActual.getFirst() + 1);
                posAux.setSecond(posActual.getSecond() + 1);
                if (t.getUsabilidad(posAux.getFirst(), posAux.getSecond()) == true) {
                    if (t.getPrefijada(posAux.getFirst(), posAux.getSecond()) == false) {
                        if (recorrido[posAux.getFirst()][posAux.getSecond()] == false)
                        recorrerTablero(t,posAux,recorrido);
                    }
                }
            }
            
            //BOT LEFT (i+1, j-1)
            if (izquierda) {
                posAux.setFirst(posActual.getFirst() + 1);
                posAux.setSecond(posActual.getSecond() - 1);
                if (t.getUsabilidad(posAux.getFirst(), posAux.getSecond()) == true) {
                    if (t.getPrefijada(posAux.getFirst(), posAux.getSecond()) == false) {
                        if (recorrido[posAux.getFirst()][posAux.getSecond()] == false)
                        recorrerTablero(t,posAux,recorrido);
                    }
                }
            }
        }
        
        if (derecha) {
            //RIGHT (j+1)
            posAux.setFirst(posActual.getFirst());
            posAux.setSecond(posActual.getSecond() + 1);
            if (t.getUsabilidad(posAux.getFirst(), posAux.getSecond()) == true) {
                if (t.getPrefijada(posAux.getFirst(), posAux.getSecond()) == false) {
                    if (recorrido[posAux.getFirst()][posAux.getSecond()] == false)
                        recorrerTablero(t,posAux,recorrido);
                }
            }
        }
        
        if (izquierda) {
            //LEFT (j-1)
            posAux.setFirst(posActual.getFirst());
            posAux.setSecond(posActual.getSecond() - 1);
            if (t.getUsabilidad(posAux.getFirst(), posAux.getSecond()) == true) {
                if (t.getPrefijada(posAux.getFirst(), posAux.getSecond()) == false) {
                    if (recorrido[posAux.getFirst()][posAux.getSecond()] == false)
                        recorrerTablero(t,posAux,recorrido);
                }
            }
        }
    }
    
    // FIN DE FUNCIONES DE GENERADOR
    
    private void calcularPorBFS(Pair posAnt, int d, TableroHidato t,
            Queue<Pair>qPosAux) {
        
        ////System.out.println(" # Entro en calcularPorBFS #");
        ////System.out.println(" # la posicion inicial es ("+posAnt.getFirst()+","+posAnt.getSecond()+") #");
        //t.dibujarTablero();
        int dists[][] = new int[t.getN()][t.getN()];
        
        Pair posInit = new Pair();
        posInit.setFirst(posAnt.getFirst());
        posInit.setSecond(posAnt.getSecond());
        
        Queue<Pair> qPos = new LinkedList<>();
        qPos.add(posInit);
        ////System.out.println(" # la posicion actual es ("+posInit.getFirst()+","+posInit.getSecond()+") #");
        ////System.out.println(" # t.getN() = "+t.getN()+" #");
        int dist = 1;
        boolean vecRecorridas[][] = new boolean[t.getN()][t.getN()];
        for (int i = 0; i < t.getN(); ++i) {
            for (int j = 0; j < t.getN(); ++j) {
                if (i == posInit.getFirst() && j == posInit.getSecond()) vecRecorridas[i][j] = true;
                else vecRecorridas[i][j] = false;
            }
        }
        for (int i = 0; i < t.getN(); ++i) {
            for (int j = 0; j < t.getN(); ++j) {
                dists[i][j] = -1;
            }
        }
        
        ////System.out.println(" # matriz de booleanos #");
        for (int i = 0; i < t.getN(); ++i) {
            ////System.out.print(" # ");
            for (int j = 0; j < t.getN(); ++j) {
                ////System.out.print(vecRecorridas[i][j]+" ");
            }
            ////System.out.print("\n");
        }
        
        while(qPos.isEmpty() == false) {
            
            //////System.out.println(" > qPos no estÃ¡ vacÃ­a.");

            Pair posActual = qPos.remove();

            boolean arriba = (posActual.getFirst() - 1 >= 0);
            boolean abajo = (posActual.getFirst() + 1 < t.getN());
            boolean izquierda = (posActual.getSecond() - 1 >= 0);
            boolean derecha = (posActual.getSecond() + 1 < t.getN());

            if (arriba) {
                // Si la casilla de arriba es un 0 le pongo la distancia.
                if (t.getCasilla(posActual.getFirst()-1,
                        posActual.getSecond()).esUsable() &&
                        t.getCasilla(posActual.getFirst()-1,
                        posActual.getSecond()).isPrefijada() == false) {
                    
                        Pair posAux = new Pair();
                        posAux.setFirst(posActual.getFirst()-1);
                        posAux.setSecond(posActual.getSecond());
                        //////System.out.println(" > EntrarÃ© en immersiva por arriba");
                        distImmersiva(qPosAux,posAux,dist,d,t,vecRecorridas,dists);
                        //distImmersiva(Pair p, int d, int max, TableroHidato t, boolean rec[][], int dists[][])
                }

                if (derecha) {
                    if (t.getCasilla(posActual.getFirst()-1,
                        posActual.getSecond()+1).esUsable() &&
                        t.getCasilla(posActual.getFirst()-1,
                        posActual.getSecond()+1).isPrefijada() == false) {

                        Pair posAux = new Pair();
                        posAux.setFirst(posActual.getFirst()-1);
                        posAux.setSecond(posActual.getSecond()+1);
                        //////System.out.println(" > EntrarÃ© en immersiva por arriba a la derecha");
                        distImmersiva(qPosAux,posAux,dist,d,t,vecRecorridas,dists);

                    }
                }
                if (izquierda) {
                    if (t.getCasilla(posActual.getFirst()-1,
                        posActual.getSecond()-1).esUsable() &&
                        t.getCasilla(posActual.getFirst()-1,
                        posActual.getSecond()-1).isPrefijada() == false) {

                        Pair posAux = new Pair();
                        posAux.setFirst(posActual.getFirst()-1);
                        posAux.setSecond(posActual.getSecond()-1);
                        //////System.out.println(" > EntrarÃ© en immersiva por arriba a la izquierda");
                        distImmersiva(qPosAux,posAux,dist,d,t,vecRecorridas,dists);;

                    }
                }
            }

            if (abajo) {
                if (t.getCasilla(posActual.getFirst()+1,
                        posActual.getSecond()).esUsable() &&
                        t.getCasilla(posActual.getFirst()+1,
                        posActual.getSecond()).isPrefijada() == false) {

                        Pair posAux = new Pair();
                        posAux.setFirst(posActual.getFirst()+1);
                        posAux.setSecond(posActual.getSecond());
                        //////System.out.println(" > EntrarÃ© en immersiva por abajo");
                        distImmersiva(qPosAux,posAux,dist,d,t,vecRecorridas,dists);

                }

                if (derecha) {

                    if (t.getCasilla(posActual.getFirst()+1,
                        posActual.getSecond()+1).esUsable() &&
                        t.getCasilla(posActual.getFirst()+1,
                        posActual.getSecond()+1).isPrefijada() == false) {

                        Pair posAux = new Pair();
                        posAux.setFirst(posActual.getFirst()+1);
                        posAux.setSecond(posActual.getSecond()+1);
                        //////System.out.println(" > EntrarÃ© en immersiva por abajo a la derecha");
                        distImmersiva(qPosAux,posAux,dist,d,t,vecRecorridas,dists);

                    }
                }
                if (izquierda) {
                    if (t.getCasilla(posActual.getFirst()+1,
                        posActual.getSecond()-1).esUsable() &&
                        t.getCasilla(posActual.getFirst()+1,
                        posActual.getSecond()-1).isPrefijada() == false) {

                        Pair posAux = new Pair();
                        posAux.setFirst(posActual.getFirst()+1);
                        posAux.setSecond(posActual.getSecond()-1);
                        //////System.out.println(" > EntrarÃ© en immersiva por abajo a la izquierda");
                        distImmersiva(qPosAux,posAux,dist,d,t,vecRecorridas,dists);

                    }
                }
            }

            if (derecha) {
                if (t.getCasilla(posActual.getFirst(),
                        posActual.getSecond()+1).esUsable() &&
                        t.getCasilla(posActual.getFirst(),
                        posActual.getSecond()+1).isPrefijada() == false) {

                        Pair posAux = new Pair();
                        posAux.setFirst(posActual.getFirst());
                        posAux.setSecond(posActual.getSecond()+1);
                        //////System.out.println(" > EntrarÃ© en immersiva por la derecha");
                        distImmersiva(qPosAux,posAux,dist,d,t,vecRecorridas,dists);

                }
            }

            if (izquierda) {
                if (t.getCasilla(posActual.getFirst(),
                        posActual.getSecond()-1).esUsable() &&
                        t.getCasilla(posActual.getFirst(),
                        posActual.getSecond()-1).isPrefijada() == false) {

                        Pair posAux = new Pair();
                        posAux.setFirst(posActual.getFirst());
                        posAux.setSecond(posActual.getSecond()-1);
                        //////System.out.println(" > EntrarÃ© en immersiva por la izquierda");
                        distImmersiva(qPosAux,posAux,dist,d,t,vecRecorridas,dists);

                }
            }
        }
        
        ////System.out.println(" poicion inicial = ("+posAnt.getFirst()+","+posAnt.getSecond()+") #");
        
        //System.out.println(" # casilla ("+posAnt.getFirst()+","+posAnt.getSecond()+") #");
        //System.out.println(" # la distancia es "+d+" #");
        //System.out.println(" # matriz de distancias #");
        for (int i = 0; i < t.getN(); ++i) {
            //System.out.print(" # ");
            for (int j = 0; j < t.getN(); ++j) {
                //System.out.print(dists[i][j]+" ");
            }
            //System.out.print("\n");
        }
        
    }
    
    private void distImmersiva(Queue<Pair> qPosAux,Pair p, int d, int max,
            TableroHidato t, boolean rec[][], int dists[][]) {
        
        ////System.out.println(" # Entro en distanciaImmersiva con los valores siguientes #");
        ////System.out.println(" # p = ("+p.getFirst()+","+p.getSecond()+") #");
        ////System.out.println(" # d = "+d+" #");
        ////System.out.println(" # max = "+max+" #");
        
        ////System.out.println(" # matriz de booleanos #");
        for (int i = 0; i < t.getN(); ++i) {
            ////System.out.print(" # ");
            for (int j = 0; j < t.getN(); ++j) {
                ////System.out.print(rec[i][j]+" ");
            }
            ////System.out.print("\n");
        }
        ////System.out.println(" # matriz de distancias #");
        for (int i = 0; i < t.getN(); ++i) {
            ////System.out.print(" # ");
            for (int j = 0; j < t.getN(); ++j) {
                ////System.out.print(dists[i][j]+" ");
            }
            ////System.out.print("\n");
        }
        
        ////System.out.println(" # Esta es toda la informacion inicial");
        
        if (d <= max) {
            //System.out.println("encuentro la pos ("+p.getFirst()+","+p.getSecond()+")");
            //System.out.println("y rec = "+rec[p.getFirst()][p.getSecond()]);
            if (rec[p.getFirst()][p.getSecond()] == false) {
                //System.out.println("Lo añado");
                qPosAux.add(p);
            }
            ////System.out.println(" # Como la distancia aun no es la maxima, le pongo la distancia #");
            dists[p.getFirst()][p.getSecond()] = d;
            rec[p.getFirst()][p.getSecond()] = true;
            
            ////System.out.println(" # Y las matrizes quedan asÃ­ #");
            
            ////System.out.println(" # matriz de booleanos #");
            for (int i = 0; i < t.getN(); ++i) {
                ////System.out.print(" # ");
                for (int j = 0; j < t.getN(); ++j) {
                    ////System.out.print(rec[i][j]+" ");
                }
                ////System.out.print("\n");
            }
            ////System.out.println(" # matriz de distancias #");
            for (int i = 0; i < t.getN(); ++i) {
                ////System.out.print(" # ");
                for (int j = 0; j < t.getN(); ++j) {
                    ////System.out.print(dists[i][j]+" ");
                }
                ////System.out.print("\n");
            }
            
            Queue<Pair> qPos = new LinkedList<>();
            qPos.add(p);
            
            while(qPos.isEmpty() == false) {

                Pair posActual = qPos.remove();
                
                ////System.out.println(" >> la pos actual es: ("+posActual.getFirst()+","+posActual.getSecond()+") <<");
                
                ////System.out.println(" En el tablero distancias: ");
                ////System.out.println(" # matriz de distancias #");
                /*
                for (int i = 0; i < t.getN(); ++i) {
                    ////System.out.print(" # ");
                    for (int j = 0; j < t.getN(); ++j) {
                        if (i == posActual.getFirst() &&
                                j == posActual.getSecond())
                            //System.out.print("-5 ");
                        else if (dists[i][j] > 0) //System.out.print("+"+dists[i][j]+" ");
                        else //System.out.print(+dists[i][j]+" ");
                    }
                    ////System.out.print("\n");
                }
                */
                
                boolean arriba = (posActual.getFirst() - 1 >= 0);
                boolean abajo = (posActual.getFirst() + 1 < t.getN());
                boolean izquierda = (posActual.getSecond() - 1 >= 0);
                boolean derecha = (posActual.getSecond() + 1 < t.getN());
                
                ////System.out.println("> pos("+posActual.getFirst()+","+posActual.getSecond()+") <");
                ////System.out.println(" > arriba = "+arriba);
                ////System.out.println(" > abajo = "+abajo);
                ////System.out.println(" > derecha = "+derecha);
                ////System.out.println(" > izquierda = "+izquierda);
                
                if (arriba) {
                    ////System.out.println(" >>> y arriba = true <<<");
                    //Si la casilla de arriba es un 0 le pongo la distancia.
                    if (t.getCasilla(posActual.getFirst()-1,
                            posActual.getSecond()).esUsable() &&
                            t.getCasilla(posActual.getFirst()-1,
                            posActual.getSecond()).isPrefijada() == false) {

                            Pair posAux = new Pair();
                            posAux.setFirst(posActual.getFirst()-1);
                            posAux.setSecond(posActual.getSecond());
                            
                            /*//System.out.println(" >>> por arriba dist = "+dists
                                    [posAux.getFirst()][posAux.getSecond()]+
                                    " <<<");*/
                            
                            if (dists[posAux.getFirst()][posAux.getSecond()] > d+1 ||
                                    dists[posAux.getFirst()][posAux.getSecond()] == -1){
                                ////System.out.println(" >>>> entro <<<<");
                                distImmersiva(qPosAux,posAux,d+1,max,t,rec,dists);
                            }
                    }

                    if (derecha) {
                        ////System.out.println(" >>> y arriba y derecha = true <<<");
                        if (t.getCasilla(posActual.getFirst()-1,
                            posActual.getSecond()+1).esUsable() &&
                            t.getCasilla(posActual.getFirst()-1,
                            posActual.getSecond()+1).isPrefijada() == false) {

                            Pair posAux = new Pair();
                            posAux.setFirst(posActual.getFirst()-1);
                            posAux.setSecond(posActual.getSecond()+1);
                            
                            /*//System.out.println(" >>> por arriba-derecha dist = "+dists
                                    [posAux.getFirst()][posAux.getSecond()]+
                                    " <<<");*/
                            
                            if (dists[posAux.getFirst()][posAux.getSecond()] > d+1 ||
                                    dists[posAux.getFirst()][posAux.getSecond()] == -1){
                                ////System.out.println(" >>>> entro <<<<");
                                distImmersiva(qPosAux,posAux,d+1,max,t,rec,dists);
                            }
                                

                        }
                    }
                    if (izquierda) {
                        ////System.out.println(" >>> y arriba y izquierda= true <<<");
                        if (t.getCasilla(posActual.getFirst()-1,
                            posActual.getSecond()-1).esUsable() &&
                            t.getCasilla(posActual.getFirst()-1,
                            posActual.getSecond()-1).isPrefijada() == false) {

                            Pair posAux = new Pair();
                            posAux.setFirst(posActual.getFirst()-1);
                            posAux.setSecond(posActual.getSecond()-1);
                            
                            /*//System.out.println(" >>> por arriba-izquierda dist = "+dists
                                    [posAux.getFirst()][posAux.getSecond()]+
                                    " <<<");*/
                            
                            if (dists[posAux.getFirst()][posAux.getSecond()] > d+1 ||
                                    dists[posAux.getFirst()][posAux.getSecond()] == -1) {
                                ////System.out.println(" >>>> entro <<<<");
                                distImmersiva(qPosAux,posAux,d+1,max,t,rec,dists);
                            }
                        }
                    }
                }

                if (abajo) {
                    ////System.out.println(" >>> y abajo = true <<<");
                    if (t.getCasilla(posActual.getFirst()+1,
                            posActual.getSecond()).esUsable() &&
                            t.getCasilla(posActual.getFirst()+1,
                            posActual.getSecond()).isPrefijada() == false) {

                            Pair posAux = new Pair();
                            posAux.setFirst(posActual.getFirst()+1);
                            posAux.setSecond(posActual.getSecond());
                            
                            /*//System.out.println(" >>> por abajo dist = "+dists
                                    [posAux.getFirst()][posAux.getSecond()]+
                                    " <<<");*/
                            
                            if (dists[posAux.getFirst()][posAux.getSecond()] > d+1 ||
                                    dists[posAux.getFirst()][posAux.getSecond()] == -1){
                                ////System.out.println(" >>>> entro <<<<");
                                distImmersiva(qPosAux,posAux,d+1,max,t,rec,dists);
                            }

                    }

                    if (derecha) {
                        ////System.out.println(" >>> y abajo y derecha = true <<<");
                        if (t.getCasilla(posActual.getFirst()+1,
                            posActual.getSecond()+1).esUsable() &&
                            t.getCasilla(posActual.getFirst()+1,
                            posActual.getSecond()+1).isPrefijada() == false) {

                            Pair posAux = new Pair();
                            posAux.setFirst(posActual.getFirst()+1);
                            posAux.setSecond(posActual.getSecond()+1);
                            
                            /*//System.out.println(" >>> por abajo-derecha dist = "+dists
                                    [posAux.getFirst()][posAux.getSecond()]+
                                    " <<<");*/
                            
                            if (dists[posAux.getFirst()][posAux.getSecond()] > d+1 ||
                                    dists[posAux.getFirst()][posAux.getSecond()] == -1){
                                ////System.out.println(" >>>> entro <<<<");
                                distImmersiva(qPosAux,posAux,d+1,max,t,rec,dists);
                            }

                        }
                    }
                    if (izquierda) {
                        ////System.out.println(" >>> y abajo y izquierda= true <<<");
                        if (t.getCasilla(posActual.getFirst()+1,
                            posActual.getSecond()-1).esUsable() &&
                            t.getCasilla(posActual.getFirst()+1,
                            posActual.getSecond()-1).isPrefijada() == false) {

                            Pair posAux = new Pair();
                            posAux.setFirst(posActual.getFirst()+1);
                            posAux.setSecond(posActual.getSecond()-1);
                            
                            /*//System.out.println(" >>> por abajo-izquierda dist = "+dists
                                    [posAux.getFirst()][posAux.getSecond()]+
                                    " <<<");*/
                            
                            if (dists[posAux.getFirst()][posAux.getSecond()] > d+1 ||
                                    dists[posAux.getFirst()][posAux.getSecond()] == -1){
                                ////System.out.println(" >>>> entro <<<<");
                                distImmersiva(qPosAux,posAux,d+1,max,t,rec,dists);
                            }

                        }
                    }
                }

                if (derecha) {
                    ////System.out.println(" >>> y derecha = true <<<");
                    if (t.getCasilla(posActual.getFirst(),
                            posActual.getSecond()+1).esUsable() &&
                            t.getCasilla(posActual.getFirst(),
                            posActual.getSecond()+1).isPrefijada() == false) {

                            Pair posAux = new Pair();
                            posAux.setFirst(posActual.getFirst());
                            posAux.setSecond(posActual.getSecond()+1);
                            
                            /*//System.out.println(" >>> por derecha dist = "+dists
                                    [posAux.getFirst()][posAux.getSecond()]+
                                    " <<<");*/
                            
                            if (dists[posAux.getFirst()][posAux.getSecond()] > d+1 ||
                                    dists[posAux.getFirst()][posAux.getSecond()] == -1){
                                ////System.out.println(" >>>> entro <<<<");
                                distImmersiva(qPosAux,posAux,d+1,max,t,rec,dists);
                            }

                    }
                }

                if (izquierda) {
                    ////System.out.println(" >>> y izquierda = true <<<");
                    if (t.getCasilla(posActual.getFirst(),
                            posActual.getSecond()-1).esUsable() &&
                            t.getCasilla(posActual.getFirst(),
                            posActual.getSecond()-1).isPrefijada() == false) {

                            Pair posAux = new Pair();
                            posAux.setFirst(posActual.getFirst());
                            posAux.setSecond(posActual.getSecond()-1);
                            
                            /*//System.out.println(" >>> por izquierda dist = "+dists
                                    [posAux.getFirst()][posAux.getSecond()]+
                                    " <<<");*/
                            
                            if (dists[posAux.getFirst()][posAux.getSecond()] > d+1 ||
                                    dists[posAux.getFirst()][posAux.getSecond()] == -1){
                                ////System.out.println(" >>>> entro <<<<");
                                distImmersiva(qPosAux,posAux,d+1,max,t,rec,dists);
                            }

                    }
                }
            }
            
        }
        
        ////System.out.println(" # Salgo de distanciaImmersiva con los valores siguientes #");
        ////System.out.println(" # p = ("+p.getFirst()+","+p.getSecond()+") #");
        ////System.out.println(" # d = "+d+" #");
        ////System.out.println(" # max = "+max+" #");
        ////System.out.println(" # matriz de booleanos #");
        for (int i = 0; i < t.getN(); ++i) {
            ////System.out.print(" # ");
            for (int j = 0; j < t.getN(); ++j) {
                ////System.out.print(rec[i][j]+" ");
            }
            ////System.out.print("\n");
        }
        ////System.out.println(" # matriz de distancias #");
        for (int i = 0; i < t.getN(); ++i) {
            ////System.out.print(" # ");
            for (int j = 0; j < t.getN(); ++j) {
                ////System.out.print(dists[i][j]+" ");
            }
            ////System.out.print("\n");
        }
        
        ////System.out.println(" # Esta es toda la informacion final");
    }
    
    public void dibujarSolucionDelTablero(int[][] sol, int t) {
        System.out.print("\n");
        for (int i = 0; i < t; ++i) {
            System.out.print("    ");
            for (int j = 0; j < t; ++j) {
                int auxMaxCol = maxDecCol(j, sol);
                int auxCalcul = calculEspais(sol[i][j],auxMaxCol);
                if (sol[i][j] > 0) System.out.print(sol[i][j]);
                else System.out.print("X");
                for (int e = 0; e < auxCalcul;++e){
                    System.out.print(" ");
                }
            }
            System.out.print("\n");
        }
    }
    
    private static int calculEspais (int i, int max){
        int aux = 0;
        if (i < 10) aux = 1;
        else if (i < 100) aux = 2;
        else aux = 3;
        //System.out.println("i = "+i+" max = "+max+" aux = "+aux);
        return (2 + (max - aux));
    }
    
    private static int maxDecCol (int i, int[][] sol) {
        int max = 1;
        int auxTamano = sol.length;
        for (int j = 0; j < auxTamano; ++j) {
            if (sol[j][i] > 9 && sol[j][i] < 99 && max < 2) max = 2;
            else if (sol[j][i] > 99) max = 3;
        }
        return max;
    }
    
    private boolean prefijadasNoRepetidas(TableroHidato t){
        for (int i = 0; i < t.PrefSize(); ++i){
            for (int j = 0; j < t.PrefSize(); ++j) {
                if (i != j) {
                    if (t.getKeys()[i] == t.getKeys()[j]) {
			//System.out.println("Falla en candidatos repetidos");
			return false;
                    }
                }
            }
        }
        return true;
    }
    
    private boolean validacionDuranteBacktracking(TableroHidato t) {
        
        Queue<Integer> qValores = new LinkedList<>();
        
        for (int i = 0; i < t.getTamano(); ++i) {
            for (int j = 0; j < t.getTamano(); ++j) {
                if (t.getUsabilidad(i, j) == true) {
                    if (t.getValor(i,j) == 0 && t.getCasilla(i, j).getNumCan() == 0) {
                        return false;
                    }
                    else qValores.add(t.getValor(i,j));
                }
            }
        }
        
        // Aqui tengo en qValores todas los valores de casillas prefijadas.
        
        Queue<Integer> qNoPref = new LinkedList<>();
        
        for (int i = 1; i < casillaMax; ++i) {
            if (qValores.contains(i) == false) qNoPref.add(i);
        }
        
        // Aqui tengo en qNoPref todos los valores que aun estan por prefijar.
        
        while (qNoPref.isEmpty() == false) {
            int valorBuscando = qNoPref.poll();
            boolean encontrado = false;
            for (int i = 0; i < t.getTamano(); ++i) {
                for (int j = 0; j < t.getTamano(); ++j) {
                    if (t.getUsabilidad(i, j) == true && t.getValor(i,j) == 0) {
                        if (t.getCasilla(i,j).contains(valorBuscando) == true) {
                            encontrado = true;
                        }
                    }
                }
            }
            if (encontrado == false) return false;
        }
        
        /*
        for (int x = 0; x < t.getTamano(); ++x) {
            for (int y = 0; y < t.getTamano(); ++y) {
                if (mirarCercanas(x,y,t) == 0) return false;
                else if (mirarCercanas(x,y,t) == 1 &&
                        (t.getValor(x, y) != casillaMax &&
                        t.getValor(x, y) != casillaMin)) return false;
            }
        }
        */
        return true;
    }
    
    private static void dibujarCandidatos(TableroHidato t) {
        
        for (int i = 0; i < t.getTamano(); ++i) {
            for (int j = 0; j < t.getTamano(); ++j) {
                if (t.getUsabilidad(i,j) == true && t.getValor(i,j) == 0) {
                    System.out.print("Candidatos de ("+i+","+j+"): [ ");
                    HashSet<Integer> sAux = t.getCasilla(i, j).getCandidatos();
                    Iterator<Integer> itAux = sAux.iterator();
                    for (int x = 0; x < sAux.size(); ++x) {
                        System.out.print(itAux.next()+" ");
                    }
                    System.out.print("]\n");
                }
            }
        }
        
    }
    
    public boolean ayuda1(TableroHidato t){
        //t.dibujarTablero();
        return resolver(t, true);
    }
     public boolean ayuda2(TableroHidato t){
         ArrayList<Pair> pospair = new ArrayList();
         boolean ret = resolver(t,true);
         if(ret){
             for (int i = 0; i < t.getTamano(); ++i){
                 for(int j = 0; j < t.getTamano(); ++j){
                     if(t.getUsabilidad(i,j)==true && t.getValor(i,j)==0){
                         Pair aux = new Pair(i,j);
                         pospair.add(aux);
                     }
                 }
             }
             Pair[] aPair = pospair.toArray(new Pair[pospair.size()]);
             int[][] retSol = t.retornaSolucion();
             Random rand = new Random();
             int rint = rand.nextInt(aPair.length - 1);
             System.out.print("EL VALOR ALEATORI CORRECTE ÉS: "+retSol[aPair[rint].getFirst()][aPair[rint].getSecond()]+"\n \n");
             System.out.print("La posicio és: "+aPair[rint].getFirst()+" "+aPair[rint].getSecond()+"\n \n");
             t.setValorUser(retSol[aPair[rint].getFirst()][aPair[rint].getSecond()], aPair[rint].getFirst(), aPair[rint].getSecond());
         }
         return ret;
     }
     
     /*  PRE: El tablero es correcto y tiene solución
        POST: Se calcula la solución del tablero en función del número de casillas usables 
            y del número de casillas prefijadas
    */
    public void calcularDificultad(TableroHidato t) {
        double casillasTotales = t.getTamanoReal();
        double prefijadas = t.PrefSize();
        double porcentaje = prefijadas/casillasTotales;
        if (t.getTamanoReal() <= 16) {
            t.setDificultad(1);
        }
        else if (t.getTamanoReal() < 37) { //posible tamaño fácil
            if (porcentaje > (double) 1/3) { //bastantes casillas prefijadas, ver su posición
                if (posicionDificultad(t.getKeys())) {
                    t.setDificultad(1);
                }
                else {
                    t.setDificultad(2);
                }
            }
            else {
                t.setDificultad(2);
            } //pocas casillas prefijadas -> aumenta dificultad
        }
        else if (t.getTamanoReal() < 65) { //posible tamaño medio
            if (porcentaje > (double) 1/3) {
                if (posicionDificultad(t.getKeys())) t.setDificultad(3);
                else t.setDificultad(2);
            }
            else {
                t.setDificultad(3);
            } //pocas casillas prefijadas -> aumenta dificultad
        }
        else { //posible tamaño difícil
            if (porcentaje < (double) 1/3) {
                t.setDificultad(3);
            }
            else if (porcentaje > (double) 1/2) {
                t.setDificultad(2);
            }
        } 
    }
    
    /*  PRE: -
        POST: Comprueba si la posición de las casillas afecta a la dificultad. Si más de la mitad de las 
            casillas son consecutivas, no nos aportarán información, y afectarán a la dificultad (haciendo
            que tener muchas prefijadas no la disminuya)
    */
    private boolean posicionDificultad(int[] prefijadas) {
        int contador = 0;
        for (int i = 1; i < prefijadas.length; ++i) {
            if (prefijadas[i] == prefijadas[i-1]+1) ++contador;
        }
        double porcentaje = contador/prefijadas.length;
        return (porcentaje > (double) 1/2);
    }
    
    
             
}