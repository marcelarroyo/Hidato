/**
 *
 * @author RaÃºl IbÃ¡Ã±ez PÃ©rez
 * Colaborador: Marcel Arroyo
 * Colaborador: Marc Barrio Ruiz
 */
package Dominio;
import java.util.*;
import Dominio.Estructuras.TableroHidato;
import Persistencia.ControladorPersistencia;
import Persistencia.ControladorDatosUsuario;
import Persistencia.ControladorDatosTablero;
import Dominio.Estructuras.UsuarioHidato;
import Dominio.AlgoritmosMios;
import Dominio.Algoritmos4;
import Compartidas.Ranking;
import Compartidas.Fila;
import Dominio.Estructuras.ConjuntoRecords;
import Dominio.Estructuras.PairRecord;
import Dominio.Estructuras.PairString;
import Dominio.Estructuras.RecordTablero;
import Persistencia.ControladorDatosRanking;
import Persistencia.ControladorDatosRecords;
import Persistencia.ControladorPartidasGuardadas;

public class ControladorDominio {
    private TableroHidato TH;
    private HashMap<String,String> nombresMapa = new HashMap<>();
    private static final ControladorDominio instance = new ControladorDominio();
    private final ControladorDatosUsuario CDUsuario = new ControladorDatosUsuario();
    private final ControladorDatosTablero CDTablero = new ControladorDatosTablero();
    private UsuarioHidato usuario = new UsuarioHidato();
    private final Algoritmos3 alg = new Algoritmos3();
    private final Algoritmos4 alg4 = new Algoritmos4();
    private boolean usuarioInvitado;
    
    private Ranking rankDificil;
    private Ranking rankMedio;
    private Ranking rankFacil;
    private final ControladorDatosRanking CDRanking = new ControladorDatosRanking();
    
    private ConjuntoRecords conj = new ConjuntoRecords();
    private final ControladorDatosRecords CDRecords = new ControladorDatosRecords();
    private final ControladorPartidasGuardadas CDPartidas = new ControladorPartidasGuardadas();
    /*   CREADORAS DE USUARIO   */
    
    /*  PRE: -
        POST: La clase queda inicializada
    */
    public ControladorDominio() {
        usuarioInvitado = true;
    }
    
    public static ControladorDominio getInstance() {
        return instance;
    }
    
    /*   CONSULTORAS DE USUARIO   */
    
    /*  PRE: -
        POST: devuelve true si el nombre es vÃ¡lido y no existe y false en caso contrario.
    */
    public boolean nombreValido(String s){
        int longitud = s.length();
        int i;
        for (i=0;i<longitud;++i){
            char a = s.charAt(i);
            if(!((a > 47 && a < 58) || (a > 64 && a < 91) || (a > 96 && a < 123))){
                return false;
            }
        }
        return (s.length() > 5 && (this.CDUsuario.nombreUsuarioExistente(s) == false));
    }
    
    /*  PRE: -
        POST: Devuelve true si la contrasena cumple los requisitos y false si no.
    */
    public boolean contrasenaValida(String c){
        int longitud = c.length();
        int i;
        for (i=0;i<longitud;++i){
            char a = c.charAt(i);
            if(!((a > 47 && a < 58) || (a > 64 && a < 91) || (a > 96 && a < 123))){
                return false;
            }
        }
        return (c.length() >= 6);
    }
    
    /*  PRE: -
        POST: Devuelve true si el nombre existe en la base de datos y false si no.
    */
    public boolean nombreExistente(String n){
        return CDUsuario.nombreUsuarioExistente(n);
    }
    
    /*  PRE: n es un nombre de usuario vÃ¡lido.
        POST: devuelve trye si la contraseÃ±a es la contraseÃ±a del usuario y false en caso contrario.
    */
    public boolean contrasenaValida(String n, String c){
        return CDUsuario.contrasenaValida(n,c);
    }
    
    /*  PRE: hay un usuario no vacÃ­o cargado.
        POST: devuelve la puntuaciÃ³n total del usuario cargado.
    */
    public int getPuntuacionUsuario(){
        return this.usuario.getPuntuacionTotal();
    }
    
    public String getNombreUsuario() {
        return usuario.getNombre();
    }
    
    /*  PRE: hay un usuario no vacÃ­o cargado..
        POST: devuelve la fecha de creacion del usuario cargado.
    */
    public Date getFechaCreacion(){
        return this.usuario.getFecha();
    }
    
    /*  PRE: hay un usuario no vacÃ­o cargado..
        POST: devuelve el boolean apareceRanking del usuario cargado.
    */
    public boolean getApareceRanking(){
        return this.usuario.getApareceRanking();
    }
    
    public boolean getInvitado(){
        return usuarioInvitado;
    }
    
    /*   MODIFICADORAS DE USUARIO   */
    
    /*  PRE: n es un nombre de usuario vÃ¡lido (no repetido).
        POST: Se crea un usuario nuevo con nombre = n y contraseÃ±a = c.
    */
    public void crearUsuario(String n, String c){
        usuarioInvitado = false;
        this.usuario = new UsuarioHidato(n,c);
        CDUsuario.crearUsuario(n,c);
        CDUsuario.guardarUsuario(this.usuario);
    }
    
    /*  PRE: n es un nombre de usuario vÃ¡lido.
        POST: se carga el usuario con nombre = n y contraseÃ±a= c.
    */
    public void loginUsuario(String n, String c){
        usuarioInvitado = false;
        this.usuario = new UsuarioHidato();
        this.usuario.setNombre(n);
        this.usuario = CDUsuario.cargarUsuario(this.usuario);
    }
    
    /*  PRE: hay un usuario no vacÃ­o cargado.
        POST: niega el valor del boolean aoareceRanking del usuario cargado.
    */
    public void toggleApareceRanking(){
        this.usuario.toggleApareceRanking();
        /*String auxNombre = this.usuario.getNombre();
        int auxPuntuacion = this.usuario.getPuntuacionTotal();
        boolean auxRanking = this.usuario.getApareceRanking();
        Date auxFecha = this.usuario.getFecha();*/
        CDUsuario.guardarUsuario(this.usuario);
    }
    
    /*  PRE: hay un usuario no vacÃ­o cargado.
        POST: guarda en la base de datos el usuario cargado.
    */
    public void guardarDatosUsuario(){
        CDUsuario.guardarUsuario(this.usuario);
        usuarioInvitado = true;
        usuario = new UsuarioHidato();
    }
    
    /*  PRE: hay un usuario no vacio cargado.
        POST: borra todos los datos del usuario cargado y se hace log out.
    */
    public void borrarUsuario(){
        usuarioInvitado = true;
        CDUsuario.borrarUsuario(this.usuario.getNombre());
        usuario = new UsuarioHidato();
    }
    
    /*   TABLEROS   */
    
    public boolean nombreTableroValido(String n) {
        if (this.CDTablero.nombreTableroExistente(n)) return false;
        int longitud = n.length();
        if (longitud < 5) return false;
        int i;
        for (i=0;i<longitud;++i){
            char a = n.charAt(i);
            if(!((a > 47 && a < 58) || (a > 64 && a < 91) || (a > 96 && a < 123))){
                return false;
            }
        }
        return true; 
    }
    
     public void borrarTablero(){
        System.out.println("NOMBRE TABLERO:" + TH.getNombreTablero());
        CDRecords.eliminarRecordsTablero(this.TH.getNombreTablero());
        CDTablero.borrarTablero(this.TH.getNombreTablero());
        System.out.println("NOMBRE TABLERO:" + TH.getNombreTablero());
        TH = new TableroHidato();
    }
    
    public boolean nombreTableroExistente(String n) {
        return this.CDTablero.nombreTableroExistente(n);
    }
    
    public PairString[] nombreTableros() {
        return CDTablero.nombreTableros();
    }
    
    public void crearTablero(String n, int t){
        TH = new TableroHidato(n,t);
    }
    
    public void crearCasilla(int v, int i, int j){
        if (v== 0) {
            TH.setValor(0,i,j);
        }
        else if (v==-1) {
            TH.setValor(-1,i,j);
        }
        else {
            TH.setValor(v,i,j);
            TH.setPrefijada(i,j,true);
        }
    }
    //ET falta modificar nomcreador valor del taulell(nomes passes sol) 
    public void crearTableroValores(String n, int t, int sol[][], int valores[][], String creador) {
        TH = new TableroHidato(n,t);
        for (int i = 0; i < t; ++i) {
            for (int j = 0; j < t; ++j) {
                TH.setValor(valores[i][j],i,j);
                TH.setSolucion(sol[i][j], i, j);
            }
        }
        TH.setNombreCreador(creador);
        alg4.calcularDificultad(TH);
        TH.dibujarTablero();
        TH.getSolucion();
        System.out.println(TH.getNombreTablero());
        CDTablero.crearTablero(TH);
        CDTablero.guardarTablero(TH);
        CDRecords.guardarRecord(TH.getNombreTablero());
    }
    public void guardarTableroValores(String n, int t, int sol[][], int valores[][], String creador) {
        TH = new TableroHidato(n,t);
        for (int i = 0; i < t; ++i) {
            for (int j = 0; j < t; ++j) {
                TH.setValor(valores[i][j],i,j);
                TH.setSolucion(sol[i][j], i, j);
            }
        }
        alg.calcularDificultad(TH);
        TH.setNombreCreador(creador);
        CDTablero.guardarTablero(TH);
    }
    
    public void cargarTableroPartidaRapida(int[][] tab) {
        
        TH = new TableroHidato("partidaRapida",tab.length);
        
        for (int i = 0; i < tab.length; ++i) {
            for (int j = 0; j < tab.length; ++j) {
                TH.setValor(tab[i][j], i, j);
            }
        }
        
    }
    
    public int [][] triangleinvertido (int tamany) {
        int max= tamany/2 -1;
        int matrix [][] = new int[tamany][tamany];
        for (int i = 0; i < tamany; ++i) {
            for (int j = 0; j < tamany; ++j) {
                matrix[i][j] = -1;
            }
        }
        boolean nomore = false;
        // Si el valor recibido es par, le añadimos uno
        if(tamany%2 != 0)
        {
            int mitad = tamany/2;
            int count = 0;
            for (int i = tamany - 1; i >= 0; --i){
                if (nomore && (i == 0)) {}
                else {
                    matrix[i][mitad] = 0;
                    for (int j = 1; j <= count; ++j) {
                        if ((mitad + j < tamany) && (mitad -j >= 0)) {
                            matrix[i][mitad+j] = 0;
                            matrix[i][mitad-j] = 0;
                        }
                        else {
                            nomore = true;
                        }
                    }
                }
                ++count;
            }
        }
        else {
            int mitadder = tamany/2;
            int mitadizq = tamany/2 -1;
            int count = 0;
            for (int i = tamany -1; i >= 0; --i){
                if (nomore && i == 0) {}
                else {
                    matrix[i][mitadizq] = 0;
                    matrix[i][mitadder] = 0;
                    for (int j = 1; j <= count; ++j) {
                        if (mitadder + j < tamany && mitadizq -j >= 0) {
                            matrix[i][mitadder+j] = 0;
                            matrix[i][mitadizq-j] = 0;
                        }
                        else {
                            nomore = true;
                        }
                    }
                }
                ++count;
            }
        }
        for (int i = 0; i < tamany; ++i) {
            for (int j = 0; j < tamany; ++j) {
                System.out.print(matrix[i][j]);
            }
            System.out.println();
        }
        return matrix;
    }
    
    public int [][] trianglesuperiordiaginversa(int tamany){
        int matrix [][] = new int[tamany][tamany];
        for (int i = 0; i < tamany; ++i) {
            for (int j = 0; j < tamany; ++j) {
                matrix[i][j] = -1;
            }
        }
        for (int i = 0; i < tamany; ++i) {
            for (int j = 0; j < tamany; ++j) {
                if (i + j <= tamany-1) matrix[i][j] = 0;
            }
        }
        for (int i = 0; i < tamany; ++i) {
            for (int j = 0; j < tamany; ++j) {
                System.out.print(matrix[i][j]);
            }
            System.out.println();
        }
        return matrix;
    }
    
    public int[][] triangleinferiordiaginversa(int tamany) {
        int matrix [][] = new int[tamany][tamany];
        for (int i = 0; i < tamany; ++i) {
            for (int j = 0; j < tamany; ++j) {
                matrix[i][j] = -1;
            }
        }
        for (int i = 0; i < tamany; ++i) {
            for (int j = 0; j < tamany; ++j) {
                if (i + j >= tamany-1) matrix[i][j] = 0;
            }
        }
        for (int i = 0; i < tamany; ++i) {
            for (int j = 0; j < tamany; ++j) {
                System.out.print(matrix[i][j]);
            }
            System.out.println();
        }
        return matrix;
    }
    
    public int[][] triangleinferior(int tamany) {
        int matrix [][] = new int[tamany][tamany];
        for (int i = 0; i < tamany; ++i) {
            for (int j = 0; j < tamany; ++j) {
                matrix[i][j] = -1;
            }
        }
        for (int i = 0; i < tamany; ++i) {
            for (int j = 0; j <= i; ++j) {
                matrix[i][j] = 0;
            }
        }
        for (int i = 0; i < tamany; ++i) {
            for (int j = 0; j < tamany; ++j) {
                System.out.print(matrix[i][j]);
            }
            System.out.println();
        }
        return matrix;
    }
    
    public int[][] trianglesuperior(int tamany) {
        int matrix [][] = new int[tamany][tamany];
        for (int i = 0; i < tamany; ++i) {
            for (int j = 0; j < tamany; ++j) {
                matrix[i][j] = -1;
            }
        }
        for (int i = 0; i < tamany; ++i) {
            for (int j = tamany-1; j >= i; --j) {
                matrix[i][j] = 0;
            }
        }
        for (int i = 0; i < tamany; ++i) {
            for (int j = 0; j < tamany; ++j) {
                System.out.print(matrix[i][j]);
            }
            System.out.println();
        }
        return matrix;
    }
    
    public int [][] rombo (int tamany) {
        int max= tamany/2 -1;
        int matrix [][] = new int[tamany][tamany];
        for (int i = 0; i < tamany; ++i) {
            for (int j = 0; j < tamany; ++j) {
                matrix[i][j] = -1;
            }
        }
        boolean nomore = false;
        // Si el valor recibido es par, le añadimos uno
        if(tamany%2 != 0)
        {
            int mitad = tamany/2;
            int count = 0;
            for (int i = 0; i < tamany/2 + 1; ++i){
                matrix[i][mitad] = 0;
                for (int j = 1; j <= count; ++j) {
                    if ((mitad + j < tamany) && (mitad -j >= 0)) {
                        matrix[i][mitad+j] = 0;
                        matrix[i][mitad-j] = 0;
                    }
                }
                ++count;
            }
            --count;
            --count;
            for(int i = tamany/2 + 1; i < tamany; ++i) {
                matrix[i][mitad] = 0;
                for (int j = count; j > 0; --j) {
                    if ((mitad + j < tamany) && (mitad -j >= 0)) {
                        matrix[i][mitad+j] = 0;
                        matrix[i][mitad-j] = 0;
                    }
                }
                --count;
            }
            
        }
        
        else {
            int mitadder = tamany/2;
            int mitadizq = tamany/2 -1;
            int count = 0;
            for (int i = 0; i < tamany/2; ++i){
                matrix[i][mitadizq] = 0;
                matrix[i][mitadder] = 0;
                for (int j = 1; j <= count; ++j) {
                    if (mitadder + j < tamany && mitadizq -j >= 0) {
                        matrix[i][mitadder+j] = 0;
                        matrix[i][mitadizq-j] = 0;
                    }
                }
                ++count;
            }
            --count;
            for (int i = tamany/2; i < tamany; ++i){
                matrix[i][mitadizq] = 0;
                matrix[i][mitadder] = 0;
                for (int j = count; j > 0; --j) {
                    if (mitadder + j < tamany && mitadizq -j >= 0) {
                        matrix[i][mitadder+j] = 0;
                        matrix[i][mitadizq-j] = 0;
                    }
                }
                --count;
            }
        }
        for (int i = 0; i < tamany; ++i) {
            for (int j = 0; j < tamany; ++j) {
                System.out.print(matrix[i][j]);
            }
            System.out.println();
        }
        return matrix;
    }
    
    public int[][] cuadrado (int tamany) {
        int[][] matrix = new int[tamany][tamany];
        for (int i = 0; i < tamany; ++i) {
            matrix[0][i] = -1;
            matrix[i][0] = -1;
            matrix[tamany-1][i] = -1;
            matrix[i][tamany-1] = -1;
        }
        for (int i = 0; i < tamany; ++i) {
            for (int j = 0; j < tamany; ++j) {
                System.out.print(matrix[i][j]);
            }
            System.out.println();
        }
        return matrix;
    }
    
    public int[][] triangle (int tamany) {
        // obtenemos el valor recibido
        
        int max= tamany/2 -1;
        int matrix [][] = new int[tamany][tamany];
        for (int i = 0; i < tamany; ++i) {
            for (int j = 0; j < tamany; ++j) {
                matrix[i][j] = -1;
            }
        }
        boolean nomore = false;
        // Si el valor recibido es par, le añadimos uno
        if(tamany%2 != 0)
        {
            int mitad = tamany/2;
            int count = 0;
            for (int i = 0; i < tamany; ++i){
                if (nomore && (i == (tamany -1))) {}
                else {
                    matrix[i][mitad] = 0;
                    for (int j = 1; j <= count; ++j) {
                        if ((mitad + j < tamany) && (mitad -j >= 0)) {
                            matrix[i][mitad+j] = 0;
                            matrix[i][mitad-j] = 0;
                        }
                        else {
                            nomore = true;
                        }
                    }
                }
                ++count;
            }
        }
        else {
            int mitadder = tamany/2;
            int mitadizq = tamany/2 -1;
            int count = 0;
            for (int i = 0; i < tamany;++i){
                if (nomore && i == tamany -1) {}
                else {
                    matrix[i][mitadizq] = 0;
                    matrix[i][mitadder] = 0;
                    for (int j = 1; j <= count; ++j) {
                        if (mitadder + j < tamany && mitadizq -j >= 0) {
                            matrix[i][mitadder+j] = 0;
                            matrix[i][mitadizq-j] = 0;
                        }
                        else {
                            nomore = true;
                        }
                    }
                }
                ++count;
            }
        }
        for (int i = 0; i < tamany; ++i) {
            for (int j = 0; j < tamany; ++j) {
                System.out.print(matrix[i][j]);
            }
            System.out.println();
        }
        return matrix;
    } 
    
    
    public TableroHidato getTablero(){
        return TH;
    }
    
    public void guardarTablero(){
        CDTablero.guardarTablero(this.TH);
    }
    
    public void guardarTableroNuevo(){
        CDTablero.crearTablero(this.TH);
        this.guardarTablero();
    }
    
    public void setNombreCreador(){
        TH.setNombreCreador(usuario.getNombre());
    }
    
    public PairString[] nombreTablero() {
        return CDTablero.nombreTableros();
    }
    
    public void cargarTablero(String n){
        TH = CDTablero.cargarTablero(n);
    }
    public void resolver() {
        alg.resolver(TH,true);
    }
    public boolean resolverTablero(){
        return alg.resolver(TH,true);
    }
    
    public int[][] getSolucion() {
        return TH.retornaSolucion();
    }
    
    public void crearTableroRandom(int tam, String nomTabRand) {
        TableroHidato tabRand = new TableroHidato(nomTabRand, tam);
        TH = alg.generadorTableroRandomRecursivo(tabRand);
    }
            
    public int[][] getVectorTablero(){
        int[][] aux = new int[TH.getN()][TH.getN()];
        for (int i = 0; i < TH.getN(); ++i) {
            for (int j = 0; j < TH.getN(); ++j) {
                if (TH.getUsabilidad(i, j) == false) aux[i][j] = -1;
                else aux[i][j] = TH.getValor(i, j);
            }
        }
        return aux;
    }
    
    public int getTamano() {
        return TH.getN();
    }
    
    public void dibujarSolucion(){
        alg.dibujarSolucionDelTablero(TH.retornaSolucion(),TH.getN());
    }
    
    //Ranking
    public void crearRanking(){
        rankDificil = new Ranking();
        rankMedio = new Ranking();
        rankFacil = new Ranking();
        
        CDRanking.crearRanking("Dificil", rankDificil);
        CDRanking.crearRanking("Medio", rankMedio);
        CDRanking.crearRanking("Facil", rankFacil);
        
        CDRanking.cargarRanking("Dificil");
        CDRanking.cargarRanking("Medio");
        CDRanking.cargarRanking("Facil");
        
        
    }
    
    public int getRanksize(String dif){
        int ret = -1;
        if(dif.equals("Dificil")){
            ret = rankDificil.getSize();
        }
        else if(dif.equals("Medio")){
            ret = rankMedio.getSize();
        }
        else if(dif.equals("Facil")){
            ret = rankFacil.getSize();
        }
        return ret;
    }
    
    public String getusri(int pos, String dif){
        String ret = null;
        Fila aux = new Fila();
        if(dif.equals("Dificil")){
            aux = rankDificil.getFilapos(pos);
            ret = aux.getNombre();
        }
        else if(dif.equals("Medio")){
            aux = rankMedio.getFilapos(pos);
            ret = aux.getNombre();
        }
        else if(dif.equals("Facil")){
            aux = rankFacil.getFilapos(pos);
            ret = aux.getNombre();
        }
        return ret;
    }
    public int getpunti(int pos, String dif){
        int ret = -1;
        Fila aux = new Fila();
        if(dif.equals("Dificil")){
            aux = rankDificil.getFilapos(pos);
            ret = aux.getPuntuacion();
        }
        else if(dif.equals("Medio")){
            aux = rankMedio.getFilapos(pos);
            ret = aux.getPuntuacion();
        }
        else if(dif.equals("Facil")){
            aux = rankFacil.getFilapos(pos);
            ret = aux.getPuntuacion();
        }
        return ret;
    }
    
    public Ranking getRank(String dif){
        Ranking rank = new Ranking();
        if(dif.equals("Dificil"))
            rank = rankDificil;
        else if(dif.equals("Medio"))
            rank = rankMedio;
        else if(dif.equals("Facil"))
            rank = rankFacil;
        return rank;
    }
    //CONSULTORAS RECORDS
   
   /*PRE: -
    POST: Crea el conjunto de records conj
    */ 
    
    public void crearConjuntoRecords() {
        conj = new ConjuntoRecords();
    }
    
    /*  PRE: El conjunto esta creado
    POST: El conjunto de records conj contiene todos los datos guardados en persistencia
    */
    
    public void cargarConjuntoRecords () {
        conj = CDRecords.cargarRecordsTablero();
    }
    
    /*PRE: El conjunto esta creado
    POST: SE guarda en la capa de persistencia los datos del conjunto de records
    */
    public void guardarConjuntoRecords() {
        CDRecords.guardarRecordsTablero(conj);
    }
        
    /*  PRE: -
        POST: Si existe el tablero s en el hashmap(con record) de records retorna true sino retorna false;
    */
    
    public boolean isEmpty() {
        return conj.isEmpty();
    }
    
    /*  PRE: -
        POST: Retorna el tamano del conjunto de records(numero de tableros con record) 
    */
    
    public int getTamanoConjuntoRecords() {
        return conj.getTamano();
    }
    
    /* PRE: El conjunto records esta creado
    POST: Devuelve si el tablero s se encuentra en el conjunto de records
    */
    
    public boolean existeTablero(String s) {
        return conj.existeTablero(s);
    }
    
    /*PRE: El tablero s se encuentra en el conjuntoRecords
    POST: Retorna el usuario i la puntuacion del record de tiempo del tablero s 
    si ese record existe. En caso que no exista el record (ningun jugador lo tenga)
    retorna null i 0
    */ 
    public PairRecord consultarRecordTimeTablero(String s) {
        return conj.consultarRecordTimeTablero(s);
    }
    
    /*PRE: El tablero s se encuentra en el conjuntoRecords
    POST: Retorna el usuario i puntuacion (en este caso negligible)con record 
    firstPlayer del tablero s si ese record existe. En caso que no exista el record
    (ningun jugador lo tenga) retorna null i 0
    */ 
    public PairRecord consultarRecordFirstPlayerTablero(String s){
        return conj.consultarRecordFirstPlayerTablero(s);
    }
    
    /*PRE: El tablero s se encuentra en el conjuntoRecords
    POST: Retorna el usuario i la puntuacion del record de puntuacion del tablero s 
    si ese record existe. En caso que no exista el record (ningun jugador lo tenga)
    retorna null i 0
    */ 
    
    public PairRecord consultarRecordMaxPuntuacionTablero(String s) {
        return conj.consultarRecordMaxPuntuacionTablero(s);
    }
    
    /*  PRE: El mapa s existe en el hashmap 
        POST: En caso de que el mapa s exist retorna todos los records de ese mapa
    */
    
    public RecordTablero consultarTodosRecordsTablero (String s) {
        return conj.consultarTodosRecordsTablero(s);
    }
    
    
    //MODIFICADORAS DE CJTRECORDS
    
    /*  PRE: No existe el tablero s en el conjunto de ecords conj
        POST: Anade el tablero s en el hashmap con un recordTablero vacio 
    */
    
    public void anadirTablero (String s) {
        conj.anadirTablero(s);
    }
    
    /*  PRE: El mapa s existe en el hashmap 
        POST: El record de primer jugador del mapa s se actualiza con el 
        jugador id
    */
    
    public void setRecordFirstPlayerTablero(String s, String id) {
        conj.setRecordFirstPlayerTablero(s, id);
    }
    
     /*  PRE: El mapa s existe en el hashmap 
        POST: El record de minimo tiempo del mapa s se actualiza con el 
        jugador id y la puntuacion punt 
    */
    
    public void setRecordTimeTablero(String s, String id, int punt) {
        conj.setRecordTimeTablero(s, id, punt);
    }
    
    /*  PRE: El mapa s existe en el hashmap 
        POST: El record de maxima puntuacion del mapa s se actualiza con el 
        jugador id y la puntuacion punt 
    */
    
    public void setRecordMaxPuntTablero(String s, String id, int punt) {
        conj.setRecordMaxPuntTablero(s, id, punt);
    }
    
    /*  PRE: -
        POST: Elimina el elemento s del hashmap en caso de que exista
    */
 
    public void eliminarTableroRecords (String s) {
        conj.eliminarTablero(s);
    }
    
    /*  PRE: -
        POST: Retorna el hashmap del conjunto de records conj
    */
    
    public HashMap<String, RecordTablero> getRecords() {
        return conj.getRecords();
    }
    
    
    public int[][] getSolucio (int[][] tablero) {
        
        TableroHidato aux = new TableroHidato("test",tablero.length);
        
        for (int i = 0; i < tablero.length; ++i) {
            for (int j = 0; j < tablero.length; ++j) {
                aux.setValor(tablero[i][j], i, j);
            }
        }
        
        alg.resolver(aux, true);
        
        return aux.retornaSolucion();
        
    }
    
    public boolean getTeSolucio (int[][] tablero) {
        
        TableroHidato aux = new TableroHidato("test",tablero.length);
        
        for (int i = 0; i < tablero.length; ++i) {
            for (int j = 0; j < tablero.length; ++j) {
                aux.setValor(tablero[i][j], i, j);
            }
        }
        
        return alg.resolver(aux, true);
        
    }
    
    public int[][] darTableroRandom (int tamano) {
        
        int solucio[][] = new int[tamano][tamano];
        
        TableroHidato aux = new TableroHidato("nombre",tamano);
        
        aux = alg.generadorTableroRandomRecursivo(aux);
        
        for (int i = 0; i < tamano; ++i) {
            for (int j = 0; j < tamano; ++j) {
                if (aux.getUsabilidad(i, j) == false) solucio[i][j] = -1;
                else solucio[i][j] = aux.getValor(i, j);
            }
        }
        
        return solucio;
    }
    
    /*  PRE: El usuario no es invitado
        POST: Retorna los nombres de las partidas guardadas del usuario 
    */
    public String[] getMapasUsuario() {
        return CDPartidas.nombresGuardadas(usuario.getNombre());
    }
    
    public boolean ayuda1Enteros (int[][] tab) {
        
        TableroHidato aux = new TableroHidato("ayuda1",tab.length);
        
        for (int i = 0; i < tab.length; ++i) {
            for (int j = 0; j < tab.length; ++j) {
                aux.setValor(tab[i][j], i, j);
            }
        }
        
        return alg.resolver(aux,true);
        
    }
    
    public int[][] ayuda2Enteros (int[][] tab) {
        
        TableroHidato aux = new TableroHidato("ayuda1",tab.length);
        int[][] solucion = tab;
        
        for (int i = 0; i < tab.length; ++i) {
            for (int j = 0; j < tab.length; ++j) {
                aux.setValor(tab[i][j], i, j);
            }
        }
        
        if (alg.resolver(aux,true)) {
            
            int[] pref = aux.getKeysOrdenadas();
            boolean encontrado = false;
            int valor = 0;
            
            for (int x = 0; x < (pref.length - 1); ++x) {
                if ((pref[x] + 1) != (pref[x+1])) {
                    if (encontrado == false) {
                        encontrado = true;
                        valor = pref[x] + 1;
                    }
                }
            }
            
            if (encontrado) {
                
                int[][] matrix = aux.retornaSolucion();
            
                for (int i = 0; i < tab.length; ++i) {
                    for (int j = 0; j < tab.length; ++j) {
                        if (matrix[i][j] == valor) {
                            solucion[i][j] = valor;
                        }
                    }
                }
            }
        }
        return solucion;
    }
    
    public boolean ayuda1(TableroHidato t){
        
        TableroHidato paramay = new TableroHidato(t.getNombreTablero(), t.getTamano());
        
        for(int i = 0; i < paramay.getTamano(); ++i){
            for(int j = 0; j < paramay.getTamano();++j){
                if(t.getUsabilidad(i, j)== true){
                    paramay.setValor(t.getValor(i,j), i, j);
                }
                else{
                    paramay.setValor(-1, i, j);
                }
            }
        }
        
        paramay.dibujarTablero();
        
        return alg.ayuda1(paramay);
        
    }
    public boolean ayuda2(TableroHidato t){
        TableroHidato paramay = new TableroHidato(t.getNombreTablero(), t.getTamano());
        boolean ret;
        for(int i = 0; i < paramay.getTamano(); ++i){
            for(int j = 0; j < paramay.getTamano();++j){
                if(t.getUsabilidad(i, j)== true){
                    paramay.setValor(t.getValor(i,j), i, j);
                }
                else{
                    paramay.setValor(-1, i, j);
                }
            }
        }
        ret = alg.ayuda2(paramay);
        for(int ii = 0; ii < paramay.getTamano(); ++ii){
            for(int jj = 0; jj < paramay.getTamano(); ++jj){
                if(t.getValor(ii, jj) != paramay.getValor(ii, jj)){
                    System.out.print("El valor que tenen diferent es a: "+ii+ " "+jj+ "\n");
                    t.setValorUser(paramay.getValor(ii,jj), ii, jj);
                }
            }
        }
        return ret;
    }
    
}

