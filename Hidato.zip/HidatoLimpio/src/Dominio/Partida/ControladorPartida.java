/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dominio.Partida;

import Dominio.AlgoritmosMios;
import java.util.*;
import Dominio.ControladorDominio;
import Dominio.Estructuras.ConjuntoRecords;
import Dominio.Estructuras.Pair;
import Dominio.Estructuras.PairRecord;
import Dominio.Estructuras.TableroHidato;
import Dominio.Estructuras.UsuarioHidato;
import Persistencia.ControladorDatosUsuario;
import Persistencia.ControladorDatosRanking;
import Persistencia.ControladorDatosRecords;
import Persistencia.ControladorPartidasGuardadas;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Hamid Latif
 */
public class ControladorPartida {
    private Partida p; //no inicio aqui la partida porque el timer se inicia al hacer el new Partida();
    private static final ControladorDominio CDominio = ControladorDominio.getInstance();
    private ControladorDatosUsuario CU = new ControladorDatosUsuario();
    ArrayList<Pair> l = new ArrayList();
    private static final ControladorPartida instance = new ControladorPartida();
    private ControladorPartidasGuardadas CPG = new ControladorPartidasGuardadas();
    private AlgoritmosMios a = new AlgoritmosMios();
    TableroHidato t;
    
    /*  PRE: -
        POST: Se ha creado un objeto ControladorPartida
    */
    public ControladorPartida() {}
    
    public static ControladorPartida getInstance() {
        return instance;
    }
    
    
    /*  PRE: -
        POST: Se ha iniciado la partida con el tablero t y el judaor u 
    */
    public void iniciarPartida(TableroHidato t) {
        p = new Partida(t);
    }
    
    /*public void iniciarPartidaInivitado(TableroHidato t) {
       p = new Partida(t);
       p.iniciarInvitado();
    }*/
    
    /*  PRE: -
        POST: Se ha introducido el valor definido por los parámetros en el tablero
            de la partida
    */
    public void setValor(int valor, int posX, int posY) {
        p.setValor(valor, posX, posY);
        Pair p = new Pair(posX, posY);
        l.add(p);
    }
    
    /*  PRE: -
        POST: Se retorna el valor de la casilla en la pos posX posY
    */
    public int getValor( int posX, int posY) {
        return p.getValor(posX, posY);
    }
    
    /*  PRE: -
        POST: Se ha borrado el valor de la casilla (o sea, se le ha dado valor 0)
    */
    public void resetValor(int posX, int posY) {
        p.setValor(0, posX, posY);
        Pair p = new Pair(posX, posY);
        l.remove(p);
    }
    
    /*  PRE: -
        POST: Retorna el numero de casillas totales usables que tiene el tablero
    */
    public void getCasillasTotales() {
        p.getCasillasTotales();
    }
    
    /*  PRE: -
        POST: Se eliminan todos los valores colocados por el usuario 
    */
    public void resetAll() {
        Pair[] vals = l.toArray(new Pair[l.size()]);
        for (int i = 0; i < vals.length; ++i) {
            resetValor(vals[i].getFirst(), vals[i].getSecond());
        }
    }
    
    /*  PRE: -
        POST: Retorna true si el tablero está lleno, false en caso contrario
            Se usa para saber cuando hemos acabado de introducir valores
    */
    public boolean estaLleno(TableroHidato t) {
        for (int i = 0; i < t.getTamano(); ++i) {
            for (int j = 0; j < t.getTamano(); ++j) {
                if (p.estaVacia(i, j)) return false;
            }
        }
        return true;
    }
    
    
    /*  PRE: -
        POST: Retorna true si el jugador aparece en el ranking, false en caso contrario 
    */
    public boolean sumaraPuntos() {
        return p.sumaraPuntos();
    }
    
    /*  PRE: -
        POST: Se 
    */
    public void setSumaraPuntos(boolean a) {
        p.setSumaraPuntos(a);
    }
    /*  PRE: -
        POST: Retorna el contador de movimientos de la partida 
    */
    public int getMovimientos() {
        return p.getMovimientos();
    }
    
    /*  PRE: -
        POST: Se calcula la puntuación total para la partida que hemos jugado 
    */
    public int calculoPuntuacion() {
        int movis = p.getMovimientos();
        int tam = p.getTamanoReal();
        double factor = (double) movis/tam;
        if (factor >= 3 || !p.sumaraPuntos()) return 0; //si se han necesitado más de 3 tiros por casilla, obtenemos 0 puntos
        else return ((int)(3-factor) * p.getDificultad() * tam);
    }
    
    //ESTA FUNCION ES PARA PROBAR, A ELIMINAR DESPUES
    public void verMapa() {
        p.verMapa();
    }
    
    /*  PRE: -
        POST: Se ha cargado la partida con los atributos especificados
              Se han cargado en la lista las posiciones de los elementos añadidos por el usuario (para hacer el reset)
    */
    public void cargarPartida(String usuario, String partida) {
        
        int tiros = CPG.getTiradas(partida, usuario);
        boolean sumara = CPG.getSumara(partida, usuario);
        t = CPG.cargarPartida(partida, usuario);
        p = new Partida(t, tiros, sumara);
        for (int i = 0; i < t.getTamano(); ++i) {
            for (int j = 0; j < t.getTamano(); ++j) {
                if (!t.getPrefijada(i, j) && t.getValor(i, j) != 0) {
                    Pair p = new Pair(i, j);
                    l.add(p);
                }
            }
        }
    }
    
    /*  PRE: -
        POST: Retorna el tablero de la partida
    */
    public TableroHidato getTablero() {
        TableroHidato t = p.getTablero();
        return t;
    }
    /*  PRE: -
        POST: Retorna el tiempo jugado de la partida guardada
    */
    public int getTiempo(String usuario, String partida) {
        int tiempo = CPG.getTiempo(partida, usuario);
        return tiempo;
    }
    
    /*  PRE: -
        POST: Guarda la partida con los valores acumulados e indica que no sumará puntos
    */
    public void guardar(String nombreJugador, int tiempoAcumulado) throws IOException {
        TableroHidato t = new TableroHidato();
        t.copia(p.getTablero());
        boolean sumara = p.sumaraPuntos();
        int tiradas = p.getMovimientos();
        CPG.guardarPartida(t, nombreJugador, tiradas, tiempoAcumulado, false);
    }
    
    /*  PRE: -
        POST: Retorna la usabilidad de la casilla en la posición i, j
    */
    public boolean getUsabilidad(int i, int j) {
        return p.getUsabilidad(i, j);
    }
    
    /*  PRE: -
        POST: Retorna true si la casilla en la posición i j es prefijada, false en caso contrario
    */
    public boolean getPrefijada(int i, int j) {
        return p.getPrefijada(i, j);
    }
    
    /*  PRE: - 
        POST: Se obtiene el tamaño del mapa
    */
    public int getTamano() {
        return p.getTamano();
    }
    
    /*  PRE: -
        POST: Retorna true si el mapa está lleno, false en caso contrario
    */
    public boolean tableroLleno() {
        for (int i = 0; i < p.getTamano(); ++i) {
            for (int j = 0; j < p.getTamano(); ++j) if (p.getValor(i, j) == 0) return false;
        }
        return true;
    }
    
    /*  PRE: - 
        POST: Inicializa la partida
    */
    private void inicializar(String opcion, String partida) {
        if ("Continuar".equals(opcion)) { //vamos a continuar una partida ya guardada
            this.cargarPartida(CDominio.getNombreUsuario(),partida);
        }
        else if ("Nueva".equals(opcion)) {
            CDominio.cargarTablero(partida);
            this.iniciarPartida(CDominio.getTablero());
        }
    }
    
    /*  PRE: -
        POST: Se calculan los puntos que se consiguen en esta partida 
    */
    public void acabarPartida(String jugador, int tiempo) {
        ConjuntoRecords cr = new ConjuntoRecords();
        CDominio.crearConjuntoRecords();
        CDominio.cargarConjuntoRecords();
        System.out.println("HA ACABADO LA PARTIDA");
        String nombreTab = p.getNombreTablero();
        PairRecord pr = new PairRecord();
        pr = CDominio.consultarRecordFirstPlayerTablero(nombreTab);
        if (pr.getIdJugador() == null) CDominio.setRecordFirstPlayerTablero(nombreTab, jugador);
        int puntuacion = calculoPuntuacion();
        System.out.println("LA PUNTUACIÓN PARA ESTA PARTIDA ES: " + puntuacion);
        pr = CDominio.consultarRecordMaxPuntuacionTablero(nombreTab);
        if (pr.getPuntuacion() < puntuacion) CDominio.setRecordMaxPuntTablero(nombreTab, jugador, puntuacion);
        System.out.println("EL TIEMPO USADO PARA ESTA PARTIDA ES (EN SEGUNDOS): " + tiempo);
        pr = CDominio.consultarRecordTimeTablero(nombreTab);
        if (pr.getPuntuacion() > tiempo || pr.getPuntuacion() == 0) CDominio.setRecordTimeTablero(nombreTab, jugador, tiempo);
        CDominio.guardarConjuntoRecords();
    }
    
}
