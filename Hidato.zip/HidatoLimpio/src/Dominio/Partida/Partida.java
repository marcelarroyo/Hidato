/**
 *
 * @author Hamid Latif
 */
package Dominio.Partida;
//import Dominio.Tiempo;
import java.util.Timer;
import Compartidas.Usuario;
import Dominio.AlgoritmosMios;
import Dominio.Estructuras.TableroHidato;
import Dominio.Estructuras.PairRecord;


import Dominio.Estructuras.TableroHidato;
import Dominio.Estructuras.UsuarioHidato;


public class Partida {
    private int puntuacion;
    //private String nombreTablero = new String();
    //private String nombreJugador = new String();
    private boolean invitado;
    private UsuarioHidato usr; 
    public PairRecord record;
    private TableroHidato t = new TableroHidato();
    private AlgoritmosMios a = new AlgoritmosMios();
    private int movimientos; //contador de movimientos en la partida
    private boolean puntos;
    
    /*  PRE: -
        POST: Se ha creado una partida con un usuario invitado
    */
    public Partida(TableroHidato t) {
        this.t.copia(t);
        movimientos = 0;
        puntos = true;
    }
    
    //Se crea una instancia de partida inicializada (es decir, una partida cargada)
    public Partida(TableroHidato t, int tiros, boolean sumara) {
        this.t.copia(t); //copia del tablero
        this.movimientos = tiros;
        this.puntos = sumara;
        invitado = false;
    }
    
    
    
    /*  PRE: -
        POST: Se indica que se usará un usuario invitado para jugar
    */
    public void iniciarInvitado() {
        invitado = true;
    }
    
    /*  PRE: -
    POST: Retorna true si el jugador sumará puntos por esta partida, false en caso contrario
    */
    public boolean sumaraPuntos() {
        return puntos;
    }
    
    public void setSumaraPuntos(boolean a) {
        this.puntos = a;
    }
    
    /*  PRE: -
        POST: Se ha cargado el usuario u para jugar la partida 
    */
    public void setUsuario(UsuarioHidato u) { 
        usr = u;
        invitado = false;
    }
    
    /*  PRE: -
        POST: Retorna el numero de casillas totales usables que tiene el tablero
    */
    public void getCasillasTotales() {
        t.getTamanoReal();
    }
    
    /*  PRE: -
        POST: Devuelve el nombre del usuario que se está usando para jugar
    */
    public String getNombreUsuario() {
        if (!invitado) return usr.getNombre();
        else return "Invitado";
    }
    
    /*  PRE: -
        POST: Retorna la usabilidad de la casilla en la posición i j
    */
    public boolean getUsabilidad(int i,int j) {
        return t.getUsabilidad(i, j);
    }
    
    /*  PRE: -
        POST: Retorna true si la casilla en la posición i j es prefijada, false en caso contrario
    */
    public boolean getPrefijada(int i, int j) {
        return t.getPrefijada(i, j);
    }
    
    /*  PRE: -
        POST: Devuelve el nombre del tablero que se está usando para jugar
    */
    public String getNombreTablero() {
        return t.getNombreTablero();
    }
    
    /*  PRE: -
        POST: Devuelve true si el usuario es invitado, false en caso contrario
    */
    /*public boolean esInvitado(){
        return invitado;
    }*/
    
    /*  PRE: -
        POST: Se ha asignado el valor a la posición definida por los parámetros
    */
    public void setValor(int valor, int posX, int posY) {
        if (valor != 0 && valor != t.getValor(posX, posY)) ++movimientos;
        t.setValorUser(valor, posX, posY);
        for(int i = 0; i < t.getTamano(); ++i) {
            for (int j = 0; j < t.getTamano(); ++j) {
                System.out.printf(t.getValor(i,j) + " ");
            }
            System.out.println();
        }
        System.out.println();
    }
    
    /*  PRE: -
        POST: Retorna el valor de la casilla definida por los parámetros
    */
    public int getValor(int posX, int posY) {
        return t.getValor(posX, posY);
    }
    
    /*  PRE: -
        POST: Retorna true si la casilla cuya posición está definida por los parámetros
            está vacia, false en caso contrario
    */
    public boolean estaVacia(int posX, int posY) {
        return (t.getValor(posX, posY) == 0);
    }
    
    /*  PRE: -
        POST: Retorna el valor del contador de movimientos
    */
    public int getMovimientos() {
        return movimientos;
    }
    
    /*  PRE: - 
        POST: Se obtiene el tamaño real del mapa (o sea, el número de casillas totales a rellenar)
    */
    public int getTamanoReal() {
        return t.getTamanoReal();
    }
    
    /*  PRE: - 
        POST: Se obtiene el tamaño del mapa
    */
    public int getTamano() {
        return t.getTamano();
    }
    
    /*  PRE: - 
        POST: Se retorna la dificultad del mapa que se está jugando
    */
    public int getDificultad() {
        return t.getDificultad();
    }
    
    /*  PRE: -
        POST: Retorna el tablero t
    */
    public TableroHidato getTablero() {
        return t;
    }
    
    
    //FUNCION PARA PROBAR, A BORRAR DESPUES
    public void verMapa() {
        t.dibujarTablero();
    }
    
    
}
