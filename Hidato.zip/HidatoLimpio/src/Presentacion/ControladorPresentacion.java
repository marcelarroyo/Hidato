/**
 *
 * @author RaÃºl Ibañez Perez
 */
package Presentacion;
import java.util.*;
import Dominio.*;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ControladorPresentacion {
    private static int opcion;
    private static final ControladorPresentacion instance = new ControladorPresentacion();
    private static final ControladorDominio CDominio = new ControladorDominio();
    private static boolean usuarioInvitado = true;
    private static String nombreUsuario;
    private static int puntuacionTotal;
    private static Date fechaCreacion;
    private static String nombreTablero;
    private static int[][] matrizTablero;
    
    /*   CREADORAS   */
    
    /*
    PRE: -
    POST: La clase queda inicializada
    */
    private ControladorPresentacion() {}
    
    /*
    PRE: -
    POST: Inicializacion por metodo Singleton (Eager). Se usa para evitar el error
        de llamar a una funcion no static desde el main (que es static)
    */
    public static ControladorPresentacion getInstance() {
        return instance;
    }
    
    
    /*   MENU PRINCIPAL   */
    
    /*
    PRE: -
    POST: Se inicia el Controlador de Presentacion.
    */
    public void iniciar() {
        //inicioSuperGuay();
        while (true) {
            
            opcion = this.menuPrincipal();
                
                if (opcion == 1) this.gestionUsuario();
                
                else if (opcion == 2) {
                    menuJuegoGeneral();
                }
                
                else if(opcion == 3) {
                    //DAR REPOSITORIO DE MAPAS
                }
                
                else if(opcion == 4) {
                    //DAR RANKINGS Y RECORDS
                }
                
                else if (opcion == 5) {
                    //GUARDAR TODOS LOS DATOS
                    System.exit(0); //Salimos del juego
                }
        }
        
        
    }
    
    /*  PRE: -
        POST: Menu Principal del programa.
    */
    private int menuPrincipal() {
        this.limpiarPantalla();
	System.out.println("    ###################################");
        System.out.println("    #         MENU PRINCIPAL          #");
        System.out.println("    ###################################");
        datosUsuario();
        System.out.println("    ###################################");
        System.out.println("    #                                 #");
	System.out.println("    #     Escoje opcion:              #");
        System.out.println("    #                                 #");
        System.out.println("    #     1) Gestion de Usuario       #");
	System.out.println("    #     2) Jugar                    #");
	System.out.println("    #     3) Repositorio de Hidatos   #");
        System.out.println("    #     4) Rankings y Records       #");
        System.out.println("    #     5) Salir                    #");
        System.out.println("    #                                 #");
	System.out.println("    ###################################");
        opcion = leerOpcion(5);
        
	return opcion;
    }
    
    /*   FUNCIONES   */
    
    private void datosUsuario(){
        System.out.println("    #                                 #");
        System.out.println("    # Datos del usuario:              #");
        System.out.println("    #                                 #");
        if(usuarioInvitado) 
            System.out.println("    # > Usuario invitado              #");
        else{
            System.out.print("    # > Usuario: "+nombreUsuario);
            calcularEspaciosParaMenu("    # > Usuario: ",nombreUsuario);
            System.out.print("    # > Puntuacion Total: "+puntuacionTotal);
            calcularEspaciosParaMenu("    # > Puntuacion Total: ",
                    Integer.toString(puntuacionTotal));
            if (CDominio.getApareceRanking())
                System.out.println("    # > Si aparece en Rankings        #");
            else System.out.println("    # > No aparece en Rankings        #");
            System.out.print("    # > Fecha Creacion: "+fechaCreacion);
            calcularEspaciosParaMenu("    # > Fecha Creacion: ",
                    fechaCreacion.toString());
        }
        System.out.println("    #                                 #");
    }
        
    private void limpiarPantalla(){
                
        if ("Windows".equals(System.getProperty("os.name"))) {
            //Si el SO es Windows ejecuto cls.
            try {
                Runtime.getRuntime().exec("cls");
            }
            catch (IOException ex) {
                Logger.getLogger(ControladorPresentacion.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else if ("Linux".equals(System.getProperty("os.name"))) {
            //Si el SO es Linux ejecuto la limpeiza de pantalla.
            System.out.print(String.format("\033[2J"));
        }
        else {
            //Si es otro hago muchas lineas en blanco.
            for (int i = 0; i < 80; ++i) {
                System.out.print("\n");
            }
        }
    }
    
    /*  PRE: i > 0
        POST: Se lee una opcion entre 1 y i (si)
    */
    private int leerOpcion(int i) {
        
        int opcionLeida = 0;
        String auxOpcion = "";
        Scanner in = new Scanner(System.in);
        
        while (opcionLeida == 0) {
            System.out.print("    > opcion:  ");
            auxOpcion = in.nextLine();
            boolean trobat = false;
            for(int e = 1;e<=i;++e){
                if (String.valueOf(e).equalsIgnoreCase(auxOpcion)){
                    trobat = true;
                    opcionLeida = e;
                }
            }
            if (trobat == false) {
                detectaErrorOpcion(auxOpcion);
            }
        }
	return opcionLeida;
    }
    
    /*  PRE: i > 0
        POST: Detecta per que l'opcio que has marcat no es vÃ lida..
    */
    private void detectaErrorOpcion(String s){
        
        boolean encontrado = false;
        int e = s.length();
        
        for(int j = 0;j<e;++j){
            if (s.charAt(j) < 48 || s.charAt(j) > 57) {
                if (encontrado == false) {
                    System.out.println("    ERROR: Has introducido un valor no numerico.");
                    encontrado = true;
                }
            }
        }
        
        if (encontrado == false) {
            System.out.println("    ERROR: Has introducido un valor que no existe.");
        }
        
    }
    
    /*  PRE: -
        POST: Se leen los datos del usuario (nombre y contraseña), se validan y
        se loguea.
    */
    private void logIn() {
        this.limpiarPantalla();
        System.out.println("    ###################################");
        System.out.println("    #              LOG IN             #");
        System.out.println("    ###################################\n");
        boolean nombreCompletado = false;
        boolean contrasenaCompletada = false;
        boolean salirOpcion = false;
        boolean opcionInvalida = true;
        String nombreUsuario = "";
        String nombreContrasena = "";
        
        System.out.println("    Introduce tu nombre de usuario:");
        while (!nombreCompletado && !salirOpcion) {
            System.out.print("      > usuario: ");
            Scanner in = new Scanner(System.in);
            nombreUsuario = in.nextLine();
            if (CDominio.nombreExistente(nombreUsuario) == false) {
                System.out.println("\n    Ese nombre de usuario no existe.\n");
                opcionInvalida = true;
                if (!salirOpcion) {
                    while (opcionInvalida) {
                        System.out.println("    ¿Quieres intentarlo otra vez? (S/N)\n");
                        System.out.print("      > ");
                        in = new Scanner(System.in);
                        String salirString = in.nextLine();
                        if (salirString.equals("N") || salirString.equals("n")) {
                            salirOpcion = true;
                            opcionInvalida = false;
                        }
                        else if (salirString.equals("S") || salirString.equals("s")){
                            System.out.println("\n    Introduce tu nombre de usuario:\n");
                            opcionInvalida = false;
                        }
                        else 
                            System.out.println("\n    Solo puedes usar S / N. Vuelve a intentarlo.\n");
                    }
                }
            }
            else nombreCompletado = true;
        }
        
        System.out.println("\n    Nombre de usuario valido.\n");
        System.out.println ("    Introduce tu contraseña:\n");
        
        while (!contrasenaCompletada && !salirOpcion) {
            System.out.print("      > contraseña: ");
            Scanner in = new Scanner(System.in);
            nombreContrasena = in.nextLine();
            if (CDominio.contrasenaValida(nombreUsuario,nombreContrasena) == false) {
                System.out.println("\n    La contraseña no es correcta.\n");
                opcionInvalida = true;
                if (!salirOpcion) {
                    while (opcionInvalida) {
                        System.out.println("    ¿Quieres intentarlo otra vez? (S/N)\n");
                        System.out.print("      > (S/N): ");
                        in = new Scanner(System.in);
                        String salirString = in.nextLine();
                        if (salirString.equals("N") || salirString.equals("n")) {
                            salirOpcion = true;
                            opcionInvalida = false;
                        }
                        else if (salirString.equals("S") || salirString.equals("s")){
                            System.out.println("\n    Introduce tu contraseña:\n");
                            opcionInvalida = false;
                        }
                        else 
                            System.out.println("\n    Solo puedes usar S / N. Vuelve a intentarlo.\n");
                    }
                }
            }
            else contrasenaCompletada = true;
        }
        
        if (salirOpcion == false){
            CDominio.loginUsuario(nombreUsuario, nombreContrasena);
            System.out.println("\n    Contraseña valida, usuario logueado.\n");
            ControladorPresentacion.usuarioInvitado = false;
            ControladorPresentacion.nombreUsuario = nombreUsuario;
            ControladorPresentacion.puntuacionTotal = CDominio.getPuntuacionUsuario();
            ControladorPresentacion.fechaCreacion = CDominio.getFechaCreacion();
        }
        else {
            System.out.println("\n    Usuario NO logueado.\n");
        }
        
        System.out.println("    Volviendo al MenÃº Principal.\n");
        this.limpiarPantalla();
    }
    
    /*  PRE: -
        POST: Se desloguea el usuario que estaba cargado.
    */
    private void logOut(){
        usuarioInvitado = true;
        CDominio.guardarDatosUsuario();
    }
    
    /*  PRE: -
        POST: Se leen los datos del usuario (nombre y contraseña), se validan, se creaun usuario nuevo y
        se loguea.
    */
    private void crearUsuario(){
        this.limpiarPantalla();
        System.out.println("    ###################################");
        System.out.println("    #        CREADOR DE USUARIO       #");
        System.out.println("    ###################################\n");
        
        boolean nombreCompletado = false;
        boolean contrasenaCompletada = false;
        boolean salirOpcion = false;
        boolean opcionInvalida = true;
        String nombreUsuario = "";
        String nombreContrasena = "";
        
        System.out.println("    Introduce un nombre de usuario: (6 o mas caracteres alfanumericos)\n");
        
        while (!nombreCompletado && !salirOpcion) {
            System.out.print("      > usuario: ");
            Scanner in = new Scanner(System.in);
            nombreUsuario = in.nextLine();
            if (CDominio.nombreValido(nombreUsuario) == false) {
                System.out.println("\n    Ese nombre de usuario ya existe o es invalido.\n");
                opcionInvalida = true;
                if (!salirOpcion) {
                    while (opcionInvalida) {
                        System.out.println("    ¿Quieres elegir otro nombre? (S/N)\n");
                        System.out.print("      > (S/N): ");
                        in = new Scanner(System.in);
                        String salirString = in.nextLine();
                        if (salirString.equals("N") || salirString.equals("n")) {
                            salirOpcion = true;
                            opcionInvalida = false;
                        }
                        else if (salirString.equals("S") || salirString.equals("s")){
                            System.out.println("\n    Elige otro nombre de usuario:\n");
                            opcionInvalida = false;
                        }
                        else 
                            System.out.println("\n    Solo puedes usar S / N. Vuelve a intentarlo.\n");
                    }
                }
            }
            else nombreCompletado = true;
        }
        
        System.out.println("\n    Nombre de usuario valido.");
        System.out.println("    Introduce una contraseña: (6 o mas caracteres alfanumericos)\n");
        
        while (!contrasenaCompletada && !salirOpcion) {
            System.out.print("      > contraseña: ");
            Scanner in = new Scanner(System.in);
            nombreContrasena = in.nextLine();
            if (CDominio.contrasenaValida(nombreContrasena)) {
                System.out.println("\n    Esa contraseña no es valida.\n");
                opcionInvalida = true;
                if (!salirOpcion) {
                    while (opcionInvalida) {
                        System.out.println("    ¿Quieres elegir otra contraseña? (S/N)\n");
                        System.out.print("      > (S/N): ");
                        in = new Scanner(System.in);
                        String salirString = in.nextLine();
                        if (salirString.equals("N") || salirString.equals("n")) {
                            salirOpcion = true;
                            opcionInvalida = false;
                        }
                        else if (salirString.equals("S") || salirString.equals("s")){
                            System.out.println("\n    Elige otra contraseña:\n");
                            opcionInvalida = false;
                        }
                        else 
                            System.out.println("\n    Solo puedes usar S / N. Vuelve a intentarlo.\n");
                    }
                }
            }
            else contrasenaCompletada = true;
        }
        
        if (salirOpcion == false){
            CDominio.crearUsuario(nombreUsuario, nombreContrasena);
            System.out.println("\n    Contraseña valida, usuario Creado.\n");
            ControladorPresentacion.usuarioInvitado = false;
            ControladorPresentacion.nombreUsuario = nombreUsuario;
            ControladorPresentacion.puntuacionTotal = CDominio.getPuntuacionUsuario();
            ControladorPresentacion.fechaCreacion = CDominio.getFechaCreacion();
        }
        else {
            System.out.println("\n    Usuario NO creado.\n");
        }
        
        System.out.println("    Volviendo al MenÃº Principal.\n");
        this.limpiarPantalla();
    }
    
    /*   MENU GENERAL DE GESTION DE USUARIO   */
    private void gestionUsuario(){
        int opcion = 0;
        if(usuarioInvitado) {
            opcion = this.menuUsuarioInvitado(opcion);
            if (opcion == 1) this.logIn();
            else if (opcion == 2) this.crearUsuario();
        }
        else {
            opcion = this.menuUsuarioLogueado(opcion);
            if (opcion == 1) this.logOut();
            else if(opcion == 2) {
                CDominio.toggleApareceRanking();
            }
            else if (opcion == 3) {

                System.out.print("      > Confirma tu contraseña: ");
                Scanner in = new Scanner(System.in);
                String auxContrasena = in.nextLine();

                if (CDominio.contrasenaValida(nombreUsuario,auxContrasena) == false) {
                    System.out.println("\n  La contraseña no es correcta. No se borrara el usuario.\n");
                }
                else {
                    System.out.println("\n  La contraseña es correcta. El usuario ha sido eliminado.\n");
                    usuarioInvitado = true;
                    CDominio.borrarUsuario();
                }
            }
        }
    }
    
    /*   MENU DE GESTION DE USUARIO INVITADO   */
    private int menuUsuarioInvitado(int opcion){
        this.limpiarPantalla();
        System.out.println("    ###################################");
        System.out.println("    #        MENU USUARIO GUEST       #");
        System.out.println("    ###################################");
        datosUsuario();
        System.out.println("    ###################################");
        System.out.println("    #                                 #");
        System.out.println("    #   1) Login                      #");
        System.out.println("    #   2) Registrarse                #");
        System.out.println("    #   3) Volver                     #");
        System.out.println("    #                                 #");
        System.out.println("    ###################################");
        opcion = leerOpcion(3);
        
        return opcion;
    }
    
    /*   MENU DE GESTION DE USUARIO LOGUEADO   */
    private int menuUsuarioLogueado(int opcion){
        this.limpiarPantalla();
        System.out.println("    ###################################");
        System.out.println("    #       MENU USUARIO LOGUEADO     #");
        System.out.println("    ###################################");
        datosUsuario();
        System.out.println("    ###################################");
        //System.out.print("    # (Eres "+nombreUsuario);
        //calcularEspaciosParaMenu("    # (Eres ",nombreUsuario);
        System.out.println("    #                                 #");
        System.out.println("    #   1) LogOut                     #");
        if (CDominio.getApareceRanking())
            System.out.println("    #   2) No aparecer en Ranking     #");
        else
            System.out.println("    #   2) Si aparecer en Ranking     #");
        System.out.println("    #   3) Borrar Usuario             #");
        System.out.println("    #   4) Salir                      #");
        System.out.println("    #                                 #");
        System.out.println("    ###################################");
        opcion = leerOpcion(4);
        
        return opcion;
    }
    
    private void calcularEspaciosParaMenu(String s1, String s2){
        int i = "    ###################################".length();
        int j = s1.length();
        int e = s2.length();
        if (i > j+e) {
            int aux = i - (j+e) - 1;
            for (int k = 0; k < aux; ++k){
                System.out.print(" ");
            }
            System.out.print("#");
        }
        System.out.print("\n");
    }
    
    /*   MENU JUEGO   */
    
    private void menuJuegoGeneral(){
        int opcionJuego = 0;
        int opcionPartida = 0;
        if (usuarioInvitado == true) {
            opcionJuego = menuJuegoInvitado();
            if (opcionJuego == 1) {
                opcionPartida = partidaNueva();
                if (opcionPartida == 1) crearTableroManual();
                else if (opcionPartida == 2) crearTableroRandom();
                else if (opcionPartida == 3) seleccionarTablero();
            }
        }
        else {
            opcionJuego = menuJuegoLogueado();
            if (opcionJuego == 1) {
                opcionPartida = partidaNueva();
                if (opcionPartida == 1) crearTableroManual();
                else if (opcionPartida == 2) crearTableroRandom();
                else if (opcionPartida == 3) seleccionarTablero();
            }
            //else if (opcionJuego == 2) cargarPartida();
        }
    }
    
    private int menuJuegoInvitado(){
        this.limpiarPantalla();
        System.out.println("    ###################################");
        System.out.println("    #         MENU JUEGO GUEST        #");
        System.out.println("    ###################################");
        datosUsuario();
        System.out.println("    ###################################");
        System.out.println("    #                                 #");
        System.out.println("    #   1) Partida Nueva              #");
        System.out.println("    #   2) Volver                     #");
        System.out.println("    #                                 #");
        System.out.println("    ###################################");
        
        opcion = leerOpcion(2);
        
        return opcion;
    }
    
    private int menuJuegoLogueado(){
        this.limpiarPantalla();
        System.out.println("    ###################################");
        System.out.println("    #        MENU JUEGO LOGUEADO      #");
        System.out.println("    ###################################");
        datosUsuario();
        System.out.println("    ###################################");
        System.out.println("    #                                 #");
        System.out.println("    #   1) Partida Nueva              #");
        System.out.println("    #   2) Cargar Partida             #");
        System.out.println("    #   3) Volver                     #");
        System.out.println("    #                                 #");
        System.out.println("    ###################################");
        
        opcion = leerOpcion(3);
        
        return opcion;
    }
    
    private int partidaNueva(){
        this.limpiarPantalla();
        System.out.println("    ###################################");
        System.out.println("    #           PARTIDA NUEVA         #");
        System.out.println("    ###################################");
        datosUsuario();
        System.out.println("    ###################################");
        System.out.println("    #                                 #");
        System.out.println("    #   1) Crear Tablero Manual       #");
        System.out.println("    #   2) Crear Tablero Random *     #");
        System.out.println("    #   3) Seleccionar Tablero        #");
        System.out.println("    #   4) Volver                     #");
        System.out.println("    #            * puede no funcionar #");
        System.out.println("    ###################################");
        
        opcion = leerOpcion(4);
        
        return opcion;
        
    }
    
    private void crearTableroManual(){
        this.limpiarPantalla();
        System.out.println("    ###################################");
        System.out.println("    #       CREAR TABLERO MANUAL      #");
        System.out.println("    ###################################");
        datosUsuario();
        System.out.println("    ###################################\n");
        
        int tamanoTablero, numeroCasillas, valor;
        String nombreTablero = "";
        boolean nombreValido = false;
        Scanner in = new Scanner(System.in);
        
        boolean tableroValido = false;
        
        while (tableroValido == false) {

            while(nombreValido == false) {
                System.out.print("    > Nombre del tablero: ");
                nombreTablero = in.nextLine();
                if (CDominio.nombreTableroValido(nombreTablero)) nombreValido = true;
                else System.out.println("    Nombre del talbero inválido.");
            }
            System.out.print("    > Tamaño del tablero: ");
            tamanoTablero = in.nextInt();

            CDominio.crearTablero(nombreTablero, tamanoTablero);

            int [][] tableroJuego = new int[tamanoTablero][tamanoTablero];  

            System.out.println("    ###################################");
            System.out.println("    #              INDICE             #");
            System.out.println("    ###################################");
            System.out.println("    # > -1 = Casilla no usable        #");
            System.out.println("    # >  0 = CASILLA USABLE           #");
            System.out.println("    # >  OTRO VALOR = Valor (fijo)    #");
            System.out.println("    ###################################");

            for (int i = 0; i < tamanoTablero; ++i){
                for (int j = 0; j < tamanoTablero; ++j) {
                    System.out.print("\n    > Valor de la casilla ["+i+"]["+j+"]: ");
                    tableroJuego[i][j] = in.nextInt();
                    CDominio.crearCasilla(tableroJuego[i][j],i,j);
                }
            }
            
            System.out.println("   > Validando el tablero...");
            
            if (CDominio.resolverTablero() == true) {
                System.out.println("   > Tablero válido.");
                tableroValido = true;
            }
            
            else System.out.println("   > Tablero inválido.");
            
        }
        
        //dibujarSolucionDelTablero(CDominio.getSolucion(), CDominio.getTablero().getTamano());
        
        if (usuarioInvitado == false) {
            CDominio.setNombreCreador();
            boolean guardarTablero = false;
            boolean opcionInvalida = true;
            while (opcionInvalida) {
                System.out.println("    ¿Quieres guardar el tablero? (S/N)\n");
                System.out.print("      > (S/N): ");
                in = new Scanner(System.in);
                String salirString = in.nextLine();
                if (salirString.equals("N") || salirString.equals("n")) {
                    guardarTablero = true;
                    opcionInvalida = false;
                }
                else if (salirString.equals("S") || salirString.equals("s")){
                    guardarTablero = true;
                    opcionInvalida = false;
                }
                else 
                    System.out.println("\n    Solo puedes usar S / N. Vuelve a intentarlo.\n");
            }
            if (guardarTablero == true) {
                CDominio.guardarTableroNuevo();
            }
            
            System.out.println("   > Empezamos a jugar (WIP)");
            
        }
        CDominio.dibujarSolucion();
        System.out.println("   > Empezamos a jugar (WIP)");
        
    }
    
    private void seleccionarTablero(){
        System.out.println("    ###################################");
        System.out.println("    #      SELECCION DE TABLERO       #");
        System.out.println("    ###################################");
        System.out.println();
        
        boolean nombreValido = false;
        Scanner in = new Scanner(System.in);
        boolean nombreCompletado = false;
        boolean salirOpcion = false;
        boolean opcionInvalida = true;
        
        System.out.println("    Introduce el nombre del tablero:");
        while (!nombreCompletado && !salirOpcion) {
            System.out.print("      > Nombre del tablero: ");
            in = new Scanner(System.in);
            nombreTablero = in.nextLine();
            if (CDominio.nombreTableroExistente(nombreTablero) == false) {
                System.out.println("\n    Ese nombre no existe.\n");
                opcionInvalida = true;
                if (!salirOpcion) {
                    while (opcionInvalida) {
                        System.out.println("    ¿Quieres intentarlo otra vez? (S/N)\n");
                        System.out.print("      > ");
                        in = new Scanner(System.in);
                        String salirString = in.nextLine();
                        if (salirString.equals("N") || salirString.equals("n")) {
                            salirOpcion = true;
                            opcionInvalida = false;
                        }
                        else if (salirString.equals("S") || salirString.equals("s")){
                            opcionInvalida = false;
                        }
                        else 
                            System.out.println("\n    Solo puedes usar S / N. Vuelve a intentarlo.\n");
                    }
                }
            }
            else nombreCompletado = true;
            CDominio.dibujarSolucion();
        }
        
        System.out.println("\n    Nombre del tablero valido.\n");
        
        CDominio.cargarTablero(nombreTablero);
        
        System.out.println("Solo para ver si está bien, el tablero cargado es: ");
        System.out.println(CDominio.getTablero().getNombreTablero());
        CDominio.getTablero().dibujarTablero();
        
        dibujarSolucionDelTablero(CDominio.getTablero().retornaSolucion(),CDominio.getTamano());
        
        System.out.println("   > Empezamos a jugar (WIP)");
        
    }
    
    private void crearTableroRandom(){
        System.out.print("   > Tamaño del tablero random (entre 2 y 6): ");
        Scanner in = new Scanner(System.in);
        int tamRand = in.nextInt();
        System.out.print("\n");;
        System.out.print("   > Nombre del tablero random: ");
        in = new Scanner(System.in);
        String nomTabRand = in.nextLine();
        System.out.print("\n   > Generando tablero random...");
        CDominio.crearTableroRandom(tamRand, nomTabRand);
        System.out.print("\n   > Tablero random generado.\n");
        dibujarTablero(CDominio.getVectorTablero(), CDominio.getTamano());
        
        if (usuarioInvitado == false) {
            CDominio.setNombreCreador();
            boolean guardarTablero = false;
            boolean opcionInvalida = true;
            while (opcionInvalida) {
                System.out.println("    ¿Quieres guardar el tablero? (S/N)\n");
                System.out.print("      > (S/N): ");
                in = new Scanner(System.in);
                String salirString = in.nextLine();
                if (salirString.equals("N") || salirString.equals("n")) {
                    guardarTablero = true;
                    opcionInvalida = false;
                }
                else if (salirString.equals("S") || salirString.equals("s")){
                    guardarTablero = true;
                    opcionInvalida = false;
                }
                else 
                    System.out.println("\n    Solo puedes usar S / N. Vuelve a intentarlo.\n");
            }
            if (guardarTablero == true) {
                CDominio.guardarTableroNuevo();
            }
        }
        
        CDominio.dibujarSolucion();
        
        System.out.println("   > Empezamos a jugar (WIP)");
        
    }
    
    private void dibujarTablero(int[][] sol, int t){
        System.out.print("\n");
        for (int i = 0; i < t; ++i) {
            System.out.print("    ");
            for (int j = 0; j < t; ++j) {
                int auxMaxCol = maxDecCol(j, sol);
                int auxCalcul = calculEspais(sol[i][j],auxMaxCol);
                if (sol[i][j] >= 0) System.out.print(sol[i][j]);
                else System.out.print("X");
                for (int e = 0; e < auxCalcul;++e){
                    System.out.print(" ");
                }
            }
            System.out.print("\n");
        }
    }
    
    /*   Mierda diversa   */
    
    private void printNombreSuperGuay(){
        
        System.out.println("    ####    ####    ####    ############        ############    ############    ############");
        System.out.println("    ####    ####    ####    ############        ############    ############    ############");
        System.out.println("    ####    ####    ####    ####    ########    ####    ####        ####        ####    ####");
        System.out.println("    ####    ####    ####    ####    ########    ####    ####        ####        ####    ####");
        System.out.println("    ############    ####    ####        ####    ####    ####        ####        ####    ####");
        System.out.println("    ############    ####    ####        ####    ############        ####        ####    ####");
        System.out.println("    ####    ####    ####    ####    ########    ############        ####        ####    ####");
        System.out.println("    ####    ####    ####    ####    ########    ####    ####        ####        ####    ####");
        System.out.println("    ####    ####    ####    ############        ####    ####        ####        ############");
        System.out.println("    ####    ####    ####    ############        ####    ####        ####        ############");
        
    }
        
    private void inicioSuperGuay(){
        limpiarPantalla();
        printNombreSuperGuay();
        try {
            Thread.sleep (1000);
        } catch (Exception e) {
            // Mensaje en caso de que falle
        }
    }
    
    private void dibujarSolucionDelTablero(int[][] sol, int t) {
        System.out.print("\n");
        for (int i = 0; i < t; ++i) {
            System.out.print("    ");
            for (int j = 0; j < t; ++j) {
                int auxMaxCol = maxDecCol(j, sol);
                int auxCalcul = calculEspais(sol[i][j],auxMaxCol);
                System.out.print(sol[i][j]);
                for (int e = 0; e < auxCalcul;++e){
                    System.out.print(" ");
                }
            }
            System.out.print("\n");
        }
    }
    private int calculEspais (int i, int max){
        int aux = 0;
        if (i < 10) aux = 1;
        else if (i < 100) aux = 2;
        else aux = 3;
        //System.out.println("i = "+i+" max = "+max+" aux = "+aux);
        return (2 + (max - aux));
    }
    
    /*  PRE:
        POST:
    */
    
        private int maxDecCol (int i, int[][] sol) {
        int max = 1;
        int auxTamano = sol.length;
        for (int j = 0; j < auxTamano; ++j) {
            if (sol[j][i] > 9 && sol[j][i] < 99 && max < 2) max = 2;
            else if (sol[j][i] > 99) max = 3;
        }
        return max;
    }
}

