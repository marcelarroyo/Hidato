/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Presentacion;

import Dominio.ControladorDominio;
//import Dominio.Partida.ControladorPartida;
import Dominio.Estructuras.TableroHidato;
import Dominio.Partida.ControladorPartida;
import java.awt.Color;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.util.LinkedList;
import java.util.Timer;
import java.util.TimerTask;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;

/**
 *
 * @author raul
 */
public class JugarPrueba extends javax.swing.JFrame {
    
    private static final ControladorDominio CDominio = ControladorDominio.getInstance();
    private static final ControladorPartida CPartida = ControladorPartida.getInstance();
    
    int[][] taulellEnters;
    
    String tiempo, user, tiempoAcabado;
    int horas, minutos, segundos, puntuacion, movimientos;
    TableroHidato tablero;
    javax.swing.JTextField caselles[][], seleccionada;
    String[] argus;
    static int tiempoCargado;

    /**
     * Creates new form JugarPrueba
     */
    
    public void empiezaElTiempo() {
        
        horas = 0;
        minutos = 0;
        segundos = 0;
        if (tiempoCargado > 0) {
            horas += tiempoCargado/3600;
            tiempoCargado %= 3600;
            minutos += tiempoCargado/60;
            tiempoCargado %= 60;
            segundos += tiempoCargado;
        }
        tiempo = horas+":"+minutos+":"+segundos;
        
        jTiempo.setText(tiempo);
        
        class ActualizaTiempo extends TimerTask {
            public void run() {
                ++segundos;
                if (segundos == 60) {
                    segundos = 0;
                    ++minutos;
                    if (minutos == 60) {
                        minutos = 0;
                        ++horas;
                    }
                }
                if (segundos > 9) {
                    if (minutos > 9) {
                        tiempo = horas+":"+minutos+":"+segundos;
                        jTiempo.setText(tiempo);
                    }
                    else {
                        tiempo = horas+":0"+minutos+":"+segundos;
                        jTiempo.setText(tiempo);
                    }
                }
                else {
                    if (minutos > 9) {
                        tiempo = horas+":"+minutos+":0"+segundos;
                        jTiempo.setText(tiempo);
                    }
                    else {
                        tiempo = horas+":0"+minutos+":0"+segundos;
                        jTiempo.setText(tiempo);
                    }
                }
            }
        }

        Timer timer = new Timer();
        timer.schedule(new ActualizaTiempo(), 0, 1000);
        
    }
    
    public void cargarUsuario() {
        if (CDominio.getInvitado()) user = "invitado";
        else user = CDominio.getNombreUsuario();
        jNombreUsuario.setText(user);
    }
    
    public void cargarTablero() {
        
        //CDominio.crearTableroRandom(5, "tablerito");
        
        //tablero = CDominio.getTablero();
        
        //tablero.dibujarTablero();
        String movs = Integer.toString(CPartida.getMovimientos());
        jMovimientos.setText(movs);
        
        caselles = new javax.swing.JTextField[CPartida.getTamano()][CPartida.getTamano()];
        
        taulell.setAlignmentX(CENTER_ALIGNMENT);
        taulell.setAlignmentY(CENTER_ALIGNMENT);
        
        int numNoUsables = 0;
        
        for (int i = 0; i < CPartida.getTamano(); ++i) {
            for (int j = 0; j < CPartida.getTamano(); ++j) {
                if (CPartida.getUsabilidad(i, j) == false) {
                    ++numNoUsables;
                    caselles[i][j] = new javax.swing.JTextField("X");
                    caselles[i][j].setBackground(Color.red);
                    caselles[i][j].setVisible(true);
                    caselles[i][j].setMinimumSize(new java.awt.Dimension(35, 35));
                    caselles[i][j].setMaximumSize(new java.awt.Dimension(35, 35));
                    caselles[i][j].setPreferredSize(new java.awt.Dimension(35, 35));
                    caselles[i][j].setBounds(taulell.getX()+(j*35), taulell.getY()+(i*35), 35, 35);
                    caselles[i][j].setBorder(javax.swing.BorderFactory.createLineBorder(Color.black, 2));
                    caselles[i][j].setEditable(false);
                    caselles[i][j].setHorizontalAlignment(SwingConstants.CENTER);
                    taulell.add(caselles[i][j]);
                }
                else if (CPartida.getPrefijada(i, j)) {
                    caselles[i][j] = new javax.swing.JTextField(String.valueOf(CPartida.getValor(i, j)));
                    caselles[i][j].setBackground(Color.cyan);
                    caselles[i][j].setVisible(true);
                    caselles[i][j].setMinimumSize(new java.awt.Dimension(35, 35));
                    caselles[i][j].setMaximumSize(new java.awt.Dimension(35, 35));
                    caselles[i][j].setPreferredSize(new java.awt.Dimension(35, 35));
                    caselles[i][j].setBounds(taulell.getX()+(j*35), taulell.getY()+(i*35), 35, 35);
                    caselles[i][j].setBorder(javax.swing.BorderFactory.createLineBorder(Color.black, 2));
                    caselles[i][j].setEditable(false);
                    caselles[i][j].setHorizontalAlignment(SwingConstants.CENTER);
                    taulell.add(caselles[i][j]);
                }
                else {
                    caselles[i][j] = new javax.swing.JTextField(String.valueOf(CPartida.getValor(i, j)));
                    if (caselles[i][j].getText().equals("0")) caselles[i][j].setBackground(Color.lightGray);
                    else caselles[i][j].setBackground(Color.gray);
                    caselles[i][j].setVisible(true);
                    caselles[i][j].setMinimumSize(new java.awt.Dimension(35, 35));
                    caselles[i][j].setMaximumSize(new java.awt.Dimension(35, 35));
                    caselles[i][j].setPreferredSize(new java.awt.Dimension(35, 35));
                    caselles[i][j].setBounds(taulell.getX()+(j*35), taulell.getY()+(i*35), 35, 35);
                    caselles[i][j].setBorder(javax.swing.BorderFactory.createLineBorder(Color.black, 2));
                    caselles[i][j].setEditable(false);
                    caselles[i][j].setHorizontalAlignment(SwingConstants.CENTER);
                    taulell.add(caselles[i][j]);
                    
                    caselles[i][j].addMouseListener(new java.awt.event.MouseListener() {

                        @Override
                        public void mouseClicked(MouseEvent e) {
                            
                            modificarSeleccionada();
                            
                            //listener para saber cual estoy tocando
                            for (int i = 0;i < caselles.length; ++i) {
                                for (int j = 0; j < caselles.length; ++j) {
                                    if (caselles[i][j].equals(e.getComponent())) {
                                        seleccionada = caselles[i][j];
                                    }
                                }
                            }
                            
                            seleccionada.setEditable(true);
                            seleccionada.selectAll();
                        }

                        @Override
                        public void mousePressed(MouseEvent e) {
                            
                        }

                        @Override
                        public void mouseReleased(MouseEvent e) {
                            
                        }

                        @Override
                        public void mouseEntered(MouseEvent e) {
                            
                            e.getComponent().setBackground(new java.awt.Color(200, 200, 200, 128));
                            setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.HAND_CURSOR));
                            
                        }

                        @Override
                        public void mouseExited(MouseEvent e) {
                            setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.DEFAULT_CURSOR));
                            javax.swing.JTextField aux = new javax.swing.JTextField();
                            for (int i = 0;i < caselles.length; ++i) {
                                for (int j = 0; j < caselles.length; ++j) {
                                    if (caselles[i][j].equals(e.getComponent())) {
                                        aux = caselles[i][j];
                                    }
                                }
                            }
                            if (aux.getText().equals("0")) aux.setBackground(Color.lightGray);
                            else aux.setBackground(Color.gray);
                        }
                        
                    });
                    
                    caselles[i][j].addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                            modificarSeleccionada();
                        }
                    });
                    
                }
            }
        }
        
        int max = (caselles.length * caselles.length) - numNoUsables;
        
        for (int i = 0; i < caselles.length; ++i) {
            for (int j = 0; j < caselles.length; ++j) {
                if (caselles[i][j].getText().equals("1")) {
                    caselles[i][j].setBackground(Color.GREEN);
                }
                else if (caselles[i][j].getText().equals(String.valueOf(max))) {
                    caselles[i][j].setBackground(Color.GREEN);
                }
            }
        }
        
        taulell.repaint();
    }
    
    public void modificarSeleccionada() {
        int ii = 0;
        int jj = 0;
        if (seleccionada != null) {
            for (int i = 0;i < caselles.length; ++i) {
                for (int j = 0; j < caselles.length; ++j) {
                    if (caselles[i][j].equals(seleccionada)) {
                        ii = i;
                        jj = j;
                    }
                }
            }
            seleccionada.setEditable(false);
            try {
                int valor = Integer.parseInt(seleccionada.getText());
                if (valor < 2 && valor != 0) throw new NumberFormatException();
                if (valor != 0) {
                    seleccionada.setText(String.valueOf(valor));
                    CPartida.setValor(valor, ii, jj);
                    seleccionada.setBackground(Color.gray);
                    StringBuilder sb = new StringBuilder();
                    String movs = Integer.toString(CPartida.getMovimientos());
                    jMovimientos.setText(movs);
                }
                else {
                    seleccionada.setText(String.valueOf(valor));
                    CPartida.setValor(valor, ii, jj);
                    seleccionada.setBackground(Color.lightGray);
                    StringBuilder sb = new StringBuilder();
                    String movs = Integer.toString(CPartida.getMovimientos());
                    jMovimientos.setText(movs);
                }
            }
            catch (NumberFormatException exc) {
                for (int i = 0;i < caselles.length; ++i) {
                    for (int j = 0; j < caselles.length; ++j) {
                        if (caselles[i][j].equals(seleccionada)) {
                            ii = i;
                            jj = j;
                        }
                    }
                }
                seleccionada.setText(String.valueOf(CPartida.getValor(ii, jj)));
                if (seleccionada.getText().equals("0")) seleccionada.setBackground(Color.lightGray);
                else seleccionada.setBackground(Color.gray);
            }
        }
    }
    
    private static void inicializar(String opcion, String partida) {
        if ("Continuar".equals(opcion)) { //vamos a continuar una partida ya guardada
            tiempoCargado = CPartida.getTiempo(CDominio.getNombreUsuario(), partida);
            System.out.println("TIEMPO ACUMULADO: " + tiempoCargado);
            CPartida.cargarPartida(CDominio.getNombreUsuario(),partida);
        }
        else if ("Nueva".equals(opcion)) {
            CDominio.cargarTablero(partida);
            CPartida.iniciarPartida(CDominio.getTablero());
        }
    }
    
    public JugarPrueba() {
        initComponents();
        setLocationRelativeTo(null);
        setResizable(false);
        setTitle("JUGAR");
        cargarUsuario();
        empiezaElTiempo();
        cargarTablero();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jNombreUsuario = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jMovimientos = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jTiempo = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        taulell = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextPane1 = new javax.swing.JTextPane();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextPane2 = new javax.swing.JTextPane();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTextPane3 = new javax.swing.JTextPane();
        jPanel7 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jButton4 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jPanel8 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        jScrollPane5 = new javax.swing.JScrollPane();
        jTextPane4 = new javax.swing.JTextPane();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Noto Sans", 1, 48)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("JUEGO");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 969, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel2.setFont(new java.awt.Font("Noto Sans", 1, 18)); // NOI18N
        jLabel2.setText("Usuario:");

        jNombreUsuario.setFont(new java.awt.Font("Noto Sans", 1, 18)); // NOI18N
        jNombreUsuario.setText("nombreUsuario");

        jLabel6.setFont(new java.awt.Font("Noto Sans", 1, 18)); // NOI18N
        jLabel6.setText("Movimientos:");

        jMovimientos.setFont(new java.awt.Font("Noto Sans", 1, 18)); // NOI18N
        jMovimientos.setText("0");

        jLabel12.setFont(new java.awt.Font("Noto Sans", 1, 18)); // NOI18N
        jLabel12.setText("Tiempo:");

        jTiempo.setFont(new java.awt.Font("Noto Sans", 1, 18)); // NOI18N
        jTiempo.setText("00:00:00");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jNombreUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(172, 172, 172)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jMovimientos)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel12)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jTiempo)
                .addGap(33, 33, 33))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jNombreUsuario)
                    .addComponent(jLabel6)
                    .addComponent(jMovimientos)
                    .addComponent(jLabel12)
                    .addComponent(jTiempo))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel8.setFont(new java.awt.Font("Noto Sans", 1, 18)); // NOI18N
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setText("TABLERO");

        javax.swing.GroupLayout taulellLayout = new javax.swing.GroupLayout(taulell);
        taulell.setLayout(taulellLayout);
        taulellLayout.setHorizontalGroup(
            taulellLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 461, Short.MAX_VALUE)
        );
        taulellLayout.setVerticalGroup(
            taulellLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 451, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(taulell, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(taulell, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel6.setPreferredSize(new java.awt.Dimension(494, 255));

        jButton1.setFont(new java.awt.Font("Noto Sans", 1, 14)); // NOI18N
        jButton1.setText("PISTA 1");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setFont(new java.awt.Font("Noto Sans", 1, 14)); // NOI18N
        jButton2.setText("PISTA 2");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setFont(new java.awt.Font("Noto Sans", 1, 14)); // NOI18N
        jButton3.setText("RENDIRSE");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Noto Sans", 1, 18)); // NOI18N
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel9.setText("AYUDAS");

        jScrollPane1.setViewportView(jTextPane1);
        jScrollPane1.setBorder(javax.swing.BorderFactory.createEmptyBorder());
        jTextPane1.setBorder(javax.swing.BorderFactory.createEmptyBorder());

        jTextPane1.remove(jScrollPane1);
        jTextPane1.setBackground(new java.awt.Color(0,0,0,0));
        jTextPane1.setEditable(false);

        jTextPane1.setText("Te dice si el tablero tiene solución en su estado actual.");

        jTextPane1.setMinimumSize(jTextPane1.getSize());
        jTextPane1.setMaximumSize(jTextPane1.getSize());
        jTextPane1.setPreferredSize(jTextPane1.getSize());

        jScrollPane2.setViewportView(jTextPane2);
        jScrollPane2.setBorder(javax.swing.BorderFactory.createEmptyBorder());
        jTextPane2.setBorder(javax.swing.BorderFactory.createEmptyBorder());

        jTextPane2.remove(jScrollPane1);
        jTextPane2.setBackground(new java.awt.Color(0,0,0,0));
        jTextPane2.setEditable(false);

        jTextPane2.setText("Te pone una casilla en una posición válida (si el tablero tiene solución).");

        jTextPane2.setMinimumSize(jTextPane1.getSize());
        jTextPane2.setMaximumSize(jTextPane1.getSize());
        jTextPane2.setPreferredSize(jTextPane1.getSize());

        jScrollPane3.setViewportView(jTextPane3);
        jScrollPane3.setBorder(javax.swing.BorderFactory.createEmptyBorder());
        jTextPane3.setBorder(javax.swing.BorderFactory.createEmptyBorder());

        jTextPane3.remove(jScrollPane1);
        jTextPane3.setBackground(new java.awt.Color(0,0,0,0));
        jTextPane3.setEditable(false);

        jTextPane3.setText("Te enseña la solución y se acaba la partida.");

        jTextPane3.setMinimumSize(jTextPane1.getSize());
        jTextPane3.setMaximumSize(jTextPane1.getSize());
        jTextPane3.setPreferredSize(jTextPane1.getSize());

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 336, Short.MAX_VALUE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)
                        .addComponent(jScrollPane1))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)
                        .addComponent(jScrollPane2)))
                .addContainerGap())
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(11, 11, 11)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel7.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel7.setPreferredSize(new java.awt.Dimension(225, 264));

        jLabel10.setFont(new java.awt.Font("Noto Sans", 1, 18)); // NOI18N
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel10.setText("PARTIDA");

        jButton4.setFont(new java.awt.Font("Noto Sans", 1, 18)); // NOI18N
        jButton4.setText("GUARDAR");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton7.setFont(new java.awt.Font("Noto Sans", 1, 18)); // NOI18N
        jButton7.setText("ACABAR");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        jButton8.setFont(new java.awt.Font("Noto Sans", 1, 18)); // NOI18N
        jButton8.setText("VOLVER");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel10)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jPanel8.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel8.setPreferredSize(new java.awt.Dimension(160, 264));

        jLabel11.setFont(new java.awt.Font("Noto Sans", 1, 18)); // NOI18N
        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel11.setText("INFORMACIÓN");

        jTextPane4.setOpaque(false);
        jScrollPane5.setViewportView(jTextPane4);
        jScrollPane5.setBorder(javax.swing.BorderFactory.createEmptyBorder());
        jTextPane4.setBorder(javax.swing.BorderFactory.createEmptyBorder());

        jTextPane4.remove(jScrollPane1);
        jTextPane4.setBackground(new java.awt.Color(0,0,0,0));
        jTextPane4.setEditable(false);

        jTextPane4.setText("Pulsa en una casilla y escribe su valor.");

        jTextPane4.setMinimumSize(jTextPane1.getSize());
        jTextPane4.setMaximumSize(jTextPane1.getSize());
        jTextPane4.setPreferredSize(jTextPane1.getSize());

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, 237, Short.MAX_VALUE)
                    .addComponent(jScrollPane5))
                .addContainerGap())
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel11)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 192, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, 263, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(59, 59, 59))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel8, 250, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel7, 250, 250, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        jMenu1.setText("File");

        jMenuItem1.setText("Salir");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem1);

        jMenuBar1.add(jMenu1);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        
        modificarSeleccionada();
        
        // SE DA LA PISTA2 //
        
        /*
        boolean ayudaEjecutada;
        ayudaEjecutada = CDominio.ayuda2(CPartida.getTablero());
        if(ayudaEjecutada)
            jTextPane4.setText("Se ha colocado una casilla aleatoria para la solucion actual.");
        else
            jTextPane4.setText("El tablero no se puede resolver");
        //CPartida.ayudaActivada();
        */
        
        CPartida.setSumaraPuntos(false);
        
        taulellEnters = new int [caselles.length][caselles.length];
        
        for (int i = 0; i < caselles.length; ++i) {
            for (int j = 0; j < caselles.length; ++j) {
                if (caselles[i][j].getText().equals("X"))
                    taulellEnters[i][j] = -1;
                else
                    taulellEnters[i][j] = Integer.parseInt(caselles[i][j].getText());
            }
        }
        
        if (CDominio.ayuda1Enteros(taulellEnters)) {
        
            taulellEnters = CDominio.ayuda2Enteros(taulellEnters);

            boolean diferencia = false;
            String valor = "0";

            for (int i = 0; i < caselles.length; ++i) {
                for (int j = 0; j < caselles.length; ++j) {
                    if (taulellEnters[i][j] != -1) {
                        valor = String.valueOf(taulellEnters[i][j]);
                        if (caselles[i][j].getText().equals(valor) == false) {
                            jTextPane4.setText("añado la casilla "+valor+".");
                            diferencia = true;
                            caselles[i][j].setText(valor);
                            caselles[i][j].setBackground(Color.gray);
                        }
                    }
                }
            }
        }
        else {
            jTextPane4.setText("No se puede poner ninguna casilla");
        }
        
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        
        modificarSeleccionada();
        
        // SE RESUELVE EL TABLERO Y SE BLOQUEA TODO //
        
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        // TODO add your handling code here:
        modificarSeleccionada();
        if (mirarTodasPuestas()) {
            if (mirarCaminoHastaUltima()) {
                jTextPane4.setText("El Hidato es correcto :)");
                jButton1.setEnabled(false);
                jButton2.setEnabled(false);
                jButton3.setEnabled(false);
                jButton4.setEnabled(false);
                jButton7.setEnabled(false);
                int tiempoTotal = horas*3600 + minutos*60 + segundos;
                if (!CDominio.getInvitado()) CPartida.acabarPartida(CDominio.getNombreUsuario(), tiempoTotal);    
            }
            else {
                jTextPane4.setText("No se puede solucionar con esos valores.");
            }
        }
        else {
            jTextPane4.setText("No estan todas las casillas puestas o hay valores repetidos o inválidos.");
        }
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
        
        modificarSeleccionada();
        if (!CDominio.getInvitado()) {
            int tiempoAcumulado = horas*3600 + minutos*60 + segundos;
            try {
                CPartida.guardar(CDominio.getNombreUsuario(), tiempoAcumulado);
                MenuPrincipal.main(null);
                this.dispose();
            } catch (IOException ex) {
                Logger.getLogger(JugarPrueba.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else {
            jTextPane4.setText("No puedes guardar una partida en modo invitado");
        }
        
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        // TODO add your handling code here:
        // AQUI SE PREGUNTA SI REALMENTE QUIERE SALIR Y SE SALE //s  
        
        javax.swing.JLabel texto = new javax.swing.JLabel("¿Estás seguro que quieres volver?");
        javax.swing.JLabel texto2 = new javax.swing.JLabel("Si sales todos tus avances serán eliminados.");
        javax.swing.JPanel panellPopUp = new javax.swing.JPanel();
        
        panellPopUp.add(texto);
        panellPopUp.add(texto2);
        
        int op = JOptionPane.showConfirmDialog(null, panellPopUp, "CONFIRMACIÓN", JOptionPane.OK_CANCEL_OPTION, JOptionPane.CANCEL_OPTION);
        
        if (op == JOptionPane.OK_OPTION) {
            MenuPrincipal.main(null);
            this.dispose();
        }
        else this.setEnabled(true);
        
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        
        modificarSeleccionada();
        
        CPartida.setSumaraPuntos(false);
        
        // SE DA LA PISTA1 //
        /*
        if(CDominio.ayuda1(CPartida.getTablero())){
            jTextPane4.setText("El tablero se puede resolver");
        }
        else{
            jTextPane4.setText("El tablero no se puede resolver");
        }
        //CPartida.ayudaActivada();
        */
        
        taulellEnters = new int [caselles.length][caselles.length];
        
        for (int i = 0; i < caselles.length; ++i) {
            for (int j = 0; j < caselles.length; ++j) {
                if (caselles[i][j].getText().equals("X"))
                    taulellEnters[i][j] = -1;
                else
                    taulellEnters[i][j] = Integer.parseInt(caselles[i][j].getText());
            }
        }
        
        boolean b = CDominio.ayuda1Enteros(taulellEnters);
        
        if (b) {
            jTextPane4.setText("El tablero tiene solución");
        }
        else jTextPane4.setText("El tablero no tiene solución");
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        // TODO add your handling code here:
        
        javax.swing.JLabel texto = new javax.swing.JLabel("¿Estás seguro que quieres salir?");
        javax.swing.JLabel texto2 = new javax.swing.JLabel("Si sales todos tus avances serán eliminados.");
        javax.swing.JPanel panellPopUp = new javax.swing.JPanel();
        
        panellPopUp.add(texto);
        panellPopUp.add(texto2);
        
        int op = JOptionPane.showConfirmDialog(null, panellPopUp, "CONFIRMACIÓN", JOptionPane.OK_CANCEL_OPTION, JOptionPane.CANCEL_OPTION);
        
        if (op == JOptionPane.OK_OPTION) {
            System.exit(0);
        }
        else this.setEnabled(true);
        
    }//GEN-LAST:event_jMenuItem1ActionPerformed
    
    public boolean mirarTodasPuestas() {
        
        int numNoUsables = 0;
        
        for (int i = 0; i < caselles.length; ++i) {
            for (int j = 0; j < caselles.length; ++j) {
                if (caselles[i][j].getText().equals("X")) ++numNoUsables;
            }
        }
        
        LinkedList<Integer> llistaValors = new LinkedList<>();
        int valor = 0;
        
        for (int i = 0; i < caselles.length; ++i) {
            for (int j = 0; j < caselles.length; ++j) {
                if (caselles[i][j].getText().equals("X") == false) {
                    valor = Integer.parseInt(caselles[i][j].getText());
                    if (valor > ((caselles.length * caselles.length) - numNoUsables)) return false;
                    if (llistaValors.contains(valor)) return false;
                    else llistaValors.add(valor);
                }
            }
        }
        
        if (llistaValors.size() != ((caselles.length * caselles.length) - numNoUsables)) return false;
        
        return true;
    }
    
    public boolean mirarCaminoHastaUltima() {
        int numNoUsables = 0;
        
        for (int i = 0; i < caselles.length; ++i) {
            for (int j = 0; j < caselles.length; ++j) {
                if (caselles[i][j].getText().equals("X")) ++numNoUsables;
            }
        }
        
        int vMax = (caselles.length*caselles.length) - numNoUsables;
        
        for (int x = 1; x < vMax; ++x) {
            
            int posX = 0, posY = 0;
            // X = j;
            // Y = i;
            
            for (int i = 0; i < caselles.length; ++i) {
                for (int j = 0; j < caselles.length; ++j) {
                    if (caselles[i][j].getText().equals(String.valueOf(x))) {
                        posX = j;
                        posY = i;
                    }
                }
            }
            
            boolean arriba = (posY - 1) >= 0;
            boolean abajo = (posY + 1) < caselles.length;
            boolean derecha = (posX + 1) < caselles.length;
            boolean izquierda = (posX - 1) >= 0;
            
            int auxX = 0, auxY = 0;
            boolean trobat = false;
            
            if (arriba) {
                auxX = posX;
                auxY = posY -1;
                if (caselles[auxY][auxX].getText().equals(String.valueOf(x+1))) {
                    trobat = true;
                }
                if (derecha && (trobat == false)) {
                    auxX = posX +1;
                    auxY = posY -1;
                    if (caselles[auxY][auxX].getText().equals(String.valueOf(x+1))) {
                        trobat = true;
                    }
                }
                if (izquierda && (trobat == false)) {
                    auxX = posX -1;
                    auxY = posY -1;
                    if (caselles[auxY][auxX].getText().equals(String.valueOf(x+1))) {
                        trobat = true;
                    }
                }
            }
            if (abajo && (trobat == false)) {
                auxX = posX;
                auxY = posY +1;
                if (caselles[auxY][auxX].getText().equals(String.valueOf(x+1))) {
                    trobat = true;
                }
                if (derecha && (trobat == false)) {
                    auxX = posX +1;
                    auxY = posY +1;
                    if (caselles[auxY][auxX].getText().equals(String.valueOf(x+1))) {
                        trobat = true;
                    }
                }
                if (izquierda && (trobat == false)) {
                    auxX = posX -1;
                    auxY = posY +1;
                    if (caselles[auxY][auxX].getText().equals(String.valueOf(x+1))) {
                        trobat = true;
                    }
                }
            }
            if (derecha && (trobat == false)) {
                auxX = posX +1;
                auxY = posY;
                if (caselles[auxY][auxX].getText().equals(String.valueOf(x+1))) {
                    trobat = true;
                }
            }
            if (izquierda && (trobat == false)) {
                auxX = posX -1;
                auxY = posY;
                if (caselles[auxY][auxX].getText().equals(String.valueOf(x+1))) {
                    trobat = true;
                }
            }
            if (trobat == false) return false;
        }
        
        return true;
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(JugarPrueba.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(JugarPrueba.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(JugarPrueba.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(JugarPrueba.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                inicializar(args[0], args[1]);
                new JugarPrueba().setVisible(true);
                
                /*
                System.out.println("Argumentos de JugarPrueba");
                inicializar(args[0], args[1]);
                for (int i = 0; i < 2; ++i) System.out.printf(args[i] + " ");
                System.out.println("Argumentos de JugarPrueba");
                */
            }
            
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JLabel jMovimientos;
    private javax.swing.JLabel jNombreUsuario;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JTextPane jTextPane1;
    private javax.swing.JTextPane jTextPane2;
    private javax.swing.JTextPane jTextPane3;
    private javax.swing.JTextPane jTextPane4;
    private javax.swing.JLabel jTiempo;
    private javax.swing.JPanel taulell;
    // End of variables declaration//GEN-END:variables
}
