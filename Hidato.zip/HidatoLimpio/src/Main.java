/**
 *
 * @author Hamid Latif
 */
//Clase main
import Dominio.Algoritmos;
import Dominio.Algoritmos3;
import Dominio.Algoritmos4;
import Dominio.AlgoritmosMios;
import Dominio.ControladorDominio;
import Dominio.Estructuras.PairString;
import Dominio.Estructuras.TableroHidato;
import Dominio.Estructuras.UsuarioHidato;
import Dominio.Partida.ControladorPartida;
import Persistencia.ControladorDatosTablero;
import Persistencia.ControladorPartidasGuardadas;
import Presentacion.ControladorPresentacion;
import Presentacion.MenuPrincipal;
import java.io.IOException;

public class Main {
	public static void main(String[] args) throws IOException {
            MenuPrincipal.main(args); 
            
            
            /*
            ControladorPartidasGuardadas CPG = new ControladorPartidasGuardadas();
            TableroHidato t = null;
            int tiradas = CPG.getTiradas("tablero", "Hamid");
            int tiempo = CPG.getTiempo("tablero", "Hamid");
            boolean sumara = CPG.getSumara("tablero", "Hamid");
            //t = CPG.cargarPartida("tablero", "Hamid");
            
            System.out.println("Tiradas: " + tiradas);
            System.out.println("Tiempo: " +  tiempo);
            System.out.printf("Sumara: ");
            if (sumara) System.out.printf("si");
            else System.out.printf("no");
            System.out.println();
            /*System.out.println("Nombre del tablero: " + t.getNombreTablero());
            System.out.println("Tablero:");
            for (int i = 0; i < t.getTamano(); ++i) {
                for (int j = 0; j < t.getTamano(); ++j) {
                    System.out.printf(t.getValor(i, j) + " ");
                }
                System.out.println();
            }
            System.out.println();
            for (int i = 0; i < t.getTamano(); ++i) {
                for (int j = 0; j < t.getTamano(); ++j) {
                    if (t.getValor(i, j) > 0) {
                        if (t.getPrefijada(i, j)) System.out.println("La casilla con valor " + t.getValor(i, j) + " es Prefijada");
                        else System.out.println("La casilla con valor " + t.getValor(i, j) + " NO es Prefijada");
                    }
                }
            }
            
            
            
            
            ControladorPartidasGuardadas CPG = new ControladorPartidasGuardadas();
            TableroHidato t = new TableroHidato("tablero", 6);
            t.setValor(24, 0, 4);
            t.setValor(18, 1, 0);
            t.setValor(16, 1, 1);
            t.setValor(20, 1, 2);
            t.setValor(23, 1, 3);
            t.setValor(12, 2, 2);
            t.setValor(29, 2, 3);
            t.setValor(30, 2, 4);
            t.setValor(27, 2, 5);
            t.setValor(14, 3, 0);
            t.setValor(5, 3, 3);
            t.setValor(31, 3, 5);
            t.setValor(7, 4, 1);
            t.setValorUser(22, 0, 0);
            t.setValor(36, 4, 2);
            t.setValor(3, 4, 5);
            t.setValor(9, 5, 0);
            t.setValor(34, 5, 3);
            t.setValor(1, 5, 4);
            CPG.guardarPartida(t, "Hamid", 10, 250, false);
            String[] s = CPG.nombresGuardadasTodos();
            System.out.println("Nombres de tableros con partidas guardadas que tienen los jugadores");
            for (int i = 0; i < s.length; ++i) {
                System.out.printf(s[i] + " ");
            }
            
            
            
            
            /*
            PairString[] p = CDT.nombreTableros();
            System.out.println(p.getSecond() + " " + p.getSecond());
            ControladorDominio CD = new ControladorDominio();
            CD.crearTablero("tablero", 4);
            CD.crearCasilla(1, 0, 0);
            CD.crearCasilla(0, 0, 1);
            CD.crearCasilla(0, 0, 2);
            CD.crearCasilla(0, 0, 3);
            CD.crearCasilla(0, 1, 0);
            CD.crearCasilla(0, 1, 1);
            CD.crearCasilla(0, 1, 2);
            CD.crearCasilla(0, 1, 3);
            CD.crearCasilla(0, 2, 0);
            CD.crearCasilla(0, 2, 1);
            CD.crearCasilla(0, 2, 2);
            CD.crearCasilla(0, 2, 3);
            CD.crearCasilla(0, 3, 0);
            CD.crearCasilla(0, 3, 1);
            CD.crearCasilla(0, 3, 2);
            CD.crearCasilla(16, 3, 3);
            CD.guardarTablero();
            
            
            AlgoritmosMios a = new AlgoritmosMios();
            TableroHidato t = new TableroHidato("tablero", 6);
            t.setValor(24, 0, 4);
            t.setValor(18, 1, 0);
            t.setValor(16, 1, 1);
            t.setValor(20, 1, 2);
            t.setValor(23, 1, 3);
            t.setValor(12, 2, 2);
            t.setValor(29, 2, 3);
            t.setValor(30, 2, 4);
            t.setValor(27, 2, 5);
            t.setValor(14, 3, 0);
            t.setValor(5, 3, 3);
            t.setValor(31, 3, 5);
            t.setValor(7, 4, 1);
            t.setValor(36, 4, 2);
            t.setValor(3, 4, 5);
            t.setValor(9, 5, 0);
            t.setValor(34, 5, 3);
            t.setValor(1, 5, 4);
            a.resolver(t, true);
            t.getSolucion();
            /*
            TableroHidato t = new TableroHidato("tablero", 7);
            t.setValor(41, 0, 2);
            t.setValor(47, 0, 5);
            t.setValor(34, 1, 3);
            t.setValor(31, 2, 0);
            t.setValor(-1, 2, 1);
            t.setValor(33, 2, 2);
            t.setValor(35, 2, 3);
            t.setValor(11, 2, 5);
            t.setValor(9, 2, 6);
            t.setValor(20, 3, 2);
            t.setValor(-1, 4, 2);
            t.setValor(25, 5, 2);
            t.setValor(1, 5, 4);
            t.setValor(3, 5, 5);
            t.setValor(23, 6, 0);
            t.setValor(24, 6, 1);
            t.setValor(27, 6, 2);
            t.setValor(2, 6, 4);
            t.dibujarTablero();
            //a.resolver(t, true);
            //t.getSolucion();
            a.calcularDificultad(t);
            t.getDificultad();
            */
        }
}
