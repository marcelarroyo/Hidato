package Compartidas;

/**
 *
 * @author Marc Barrio Ruiz
 */
import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import java.util.Collections;
import java.util.Comparator;

public class Ranking {
    protected List<Fila> Ranking;
    
    
   /*CREADORAS RANKING */
    
    
    /*  PRE: -
        POST: Se crea un objeto Ranking.
    */
    public Ranking(){
        Ranking = new ArrayList<>();
    }
    
    
    /* CONSULTORAS RANKING */
    
    
    /*  PRE: -
        POST: Retorna la fila del ranking amb nombreUsuario especificat als parametres si no existeix
              retorna una fila buida.
    */
    public Fila getFila(String nombreUsuario){
        ListIterator<Fila> RankingIt = Ranking.listIterator();
        Fila ret = new Fila();
        Fila tmp;
        boolean found = false;
        while(found == false && RankingIt.hasNext()){
                tmp = RankingIt.next();
                if(tmp.getNombre().equals(nombreUsuario)){
                    ret = tmp;
                    found = true;
            }  
        }
        return ret;
    }
    
    /*  PRE: "posicio" ha de ser un nombre entre 1 i size del ranking.
        POST: Retorna la Fila que esta a la posicio "posicio".
    */
    public Fila getFilapos(int posicio){
        Fila ret = new Fila();
        ListIterator<Fila> RankingIt = Ranking.listIterator(posicio-1);
        ret = RankingIt.next();
        return ret;
    }
    
    /*  PRE: -
        POST: Retorna la mida del ranking.
    */
    public int getSize(){
        return Ranking.size();
    }
    
    
    /* MODIFICADORAS RANKING */
    
    
    //Comparator Sort
    static class PuntComparator implements Comparator<Fila> {

        @Override
        public int compare(Fila o1, Fila o2) {
            int ret;
            ret = o2.getPuntuacion() - o1.getPuntuacion();
            return ret;            
        }
        
    }
    
    
    /*  PRE: -
        POST: Se inserta una fila en el Ranking en la posiciÃ³n ordenada segÃºn un criterio descendente de puntuacion.
    */
    public void insertarFila(Fila f){
        //Ranking.add(f);
        if(Ranking.isEmpty()){
            Ranking.add(f);
        }
        else{
            ListIterator<Fila> RankingIt = Ranking.listIterator(Ranking.size());
            boolean done = false;
            Fila tmp;
            while(RankingIt.hasPrevious() && done == false){
                tmp = RankingIt.previous();
                if(tmp.getPuntuacion() > f.getPuntuacion() || RankingIt.previousIndex() == -1){
                    RankingIt.add(f);
                    done = true;
                    //Collections.swap(Ranking,RankingIt.nextIndex() , RankingIt.nextIndex() - 1);
                }
                /*else{
                    Ranking.add(f);
                    done = true;
                }*/
            }
            Collections.sort(Ranking, new PuntComparator());
        }
    }
    
    /*  PRE: -
        POST: Borra la fila que contÃ© el nombreUsuario especificat als parametres.
    */
    public void borrarFila(String nombreUsuario){
        ListIterator<Fila> RankingIt = Ranking.listIterator();
        boolean done = false;
        while(done == false && RankingIt.hasNext()){
            if(RankingIt.next().getNombre().equals(nombreUsuario)){
                RankingIt.remove();
                done = true;
            }
        }
    }
    
    /*  PRE: El nombreUsuario de la Fila del parametre ha d'existir al Ranking.
        POST: La fila del Ranking amb nom igual a la fila del parÃ metre son substituits
              significant que l'usuari ha quedat actualitzat.
    */
    public void actualizarUsuario(Fila f){
        ListIterator<Fila> RankingIt = Ranking.listIterator();
        boolean done = false;
        Fila tmp;
        while(done == false && RankingIt.hasNext()){
            tmp = RankingIt.next();
            if(tmp.getNombre().equals(f.getNombre())){
                borrarFila(tmp.getNombre());
                insertarFila(f);
                done = true;
            }
        }
    }
    
    public boolean existeUsuario(String nombreUsuario){
        ListIterator<Fila> RankingIt = Ranking.listIterator();
        boolean done = false;
        while(done == false && RankingIt.hasNext()){
            if(RankingIt.next().getNombre().equals(nombreUsuario)){
                done = true;
            }
        }
        return done;
    }
    

}
