package Compartidas;

import java.util.*;
/**
 *
 * @author daniel.ferreira.balta
 */

public class Casilla 
{
                                    // DESCRIPCION                                          VALORES POSIBLES O POR DEFECTO(D)
    private int cordX;              // Numero de fila                                       [0 .. N]
    private int cordY;              // Numero de columna                                    [0 .. N]
    private int valor;              // Valor asignado por el programa o usuario.            [1 .. N]
    protected boolean prefijada;      // Si es una casilla "inicial" o puesta por el usuario. [D: TRUE]
    private HashSet<Integer> candidatos;// Contiene los posibles candidatos para una casilla

    public Casilla()
    {
        cordX = -1;
        cordY = -1;
        valor = 0;
        prefijada = false;
        candidatos = new HashSet<>();
    }
        
    public Casilla(int x, int y)
    {
        cordX = x;
        cordY = y;
        valor = 0;
        prefijada = false;
        candidatos = new HashSet<>();
    }
    
    public Casilla(int x, int y, int val)
    {
        cordX = x;
        cordY = y;
        valor = val;
        prefijada = true;
        candidatos = new HashSet<>();
    }
    
    public Casilla(int val)
    {
        cordX = -1;
        cordY = -1;
        valor = val;
        prefijada = true;
        candidatos = new HashSet<>();
    }
    
    public void copy(Casilla c)
    {
        cordX = c.getX();
        cordY = c.getY();
        valor = c.getValor();
        prefijada = c.isPrefijada();
        candidatos = new HashSet<>();
        candidatos.addAll(c.getCandidatos());
    }
        
    public int getX()
    {
        return cordX;
    }
    
    public int getY()
    {
        return cordY;
    }
   
        
    public int getValor()
    {
        return valor;
    }
    
    public int getNumCan()
    {
        return candidatos.size();
    }
    
    public HashSet<Integer> getCandidatos()
    {
        return candidatos;
    }
    
    public int getFirst()
    {
        if(candidatos.iterator().hasNext()){
            return candidatos.iterator().next();
        }
        return -1;
    }
        
    public boolean isPrefijada()
    {
        return prefijada;
    }
    
    public boolean contains(int can)
    {
        return candidatos.contains(can);
    }
    
    
    public void setX(int x)
    {
        cordX = x;
    }
    

    public void setY(int y)
    {
        cordY = y;
    }
    
    
    public void setValor(int x)
    {
        valor = x;
    }
    
    public void setCandidatos(HashSet<Integer> can)
    {
        candidatos.clear();
        candidatos.addAll(can);
    }
    
    public boolean initCan(int N)
    {
        if(candidatos.isEmpty())
        {
            for(int i = 0; i < N; ++i) candidatos.add(i+1);
            return true;
        }
        return false;
    }
    
    public void setPrefijada()
    {
        prefijada = true;
    }
    
    public void setCan(int sol)
    {
        candidatos.clear();
        candidatos.add(sol);
    }
    
    public boolean delCan(int can)
    {
        return candidatos.remove(can);
    }
    
    public boolean isUnique()
    {
        return (candidatos.size() == 1);
    }
    
    public boolean delSetCan(HashSet<Integer> can)
    {
        return candidatos.removeAll(can);
    }
    
    public boolean retainAll(HashSet<Integer> can)
    {
        return candidatos.retainAll(can);
    }
    
    public boolean equals(HashSet<Integer> can)
    {
        return candidatos.equals(can);
    }
}
