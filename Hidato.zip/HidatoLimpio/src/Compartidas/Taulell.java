package Compartidas;
 
public class Taulell {
                                        // DESCRIPCION                                          VALORES POSIBLES O POR DEFECTO(D)
    protected int N;                      // Tamany del taulell
    protected Casilla[][] taulell;        // Vector de caselles que conforma el taulell
 
    //Constructors
    public Taulell (){
        this.N = 0;
        this.taulell = new Casilla[0][0];
    };
   
    public Taulell (int N){
       this.N = N;
       this.taulell = new Casilla[N][N];
        for(int i = 0; i < N; i++){
            for(int j = 0; j < N; j++){
                taulell[i][j] = new Casilla(i,j);
            }
        }
    };
   
    //Consultors
    public int getN(){
        return N;
    }
     
    public int getValor(int i, int j){
        return taulell[i][j].getValor();
    }
    
    public Casilla getCasilla (int i, int j){
        return taulell[i][j];
    }
   
    
    //Modificadors
    public void setValor(int i, int j, int valor){
        taulell[i][j].setValor(valor);
    }
    
    public void copiaTaulell (Taulell tCopia) {
        if(tCopia.getN() == this.N) {
            for(int i = 0; i < N; i++){
                for(int j = 0; j < N; j++){
                    taulell[i][j].copy(tCopia.getCasilla(i,j));
                }
            }
        }
    }
    //Testing
    public void imprimeixTaulell(){
         for(int i = 0; i < N; i++){
            for(int j = 0; j < N; j++){
                System.out.print(taulell[i][j].getValor() + " ");
            }
            System.out.println();
        }
    }
}
